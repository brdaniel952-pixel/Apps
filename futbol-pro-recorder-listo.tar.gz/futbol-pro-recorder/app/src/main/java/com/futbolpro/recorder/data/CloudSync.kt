package com.futbolpro.recorder.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.widget.Toast
import com.futbolpro.recorder.App
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID

data class CPlayer(var name: String = "", var number: String = "", var photo: String? = null, var position: String = "", var birth: String = "")
data class CScorer(var player: String = "", var teamGid: String = "", var goals: Int = 0)
data class CEvent(var type: String = "GOAL", var teamGid: String = "", var player: String = "", var minute: Int = 0)
data class CFixture(
    var id: Long = 0, var round: Int = 1, var homeGid: String = "", var awayGid: String = "", var played: Boolean = false,
    var events: List<CEvent> = emptyList(), var homePens: Int = -1, var awayPens: Int = -1, var videoUrl: String = "", var date: Long = 0L, var walkoverGid: String = ""
)
data class CTournament(
    var name: String = "", var winPts: Int = 3, var drawPts: Int = 1, var penRounds: Int = 3,
    var startDate: Long = 0L, var intervalDays: Int = 7, var nextId: Long = 1,
    var teamGids: List<String> = emptyList(), var fixtures: List<CFixture> = emptyList(),
    var scorersMode: String = "auto", var manualScorers: List<CScorer> = emptyList()
)

/**
 * Sincronización con Firebase (Firestore). Todos leen; solo los teléfonos admin (código en la colección "admins") escriben.
 * Si la app no tiene google-services.json, todo esto queda apagado y la app funciona igual en modo local.
 */
object CloudSync {
    private val gson = Gson()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val main = Handler(Looper.getMainLooper())
    private var lastPull = 0L

    fun enabled(ctx: Context): Boolean = try { FirebaseApp.getApps(ctx).isNotEmpty() } catch (_: Throwable) { false }
    private fun sp(c: Context) = c.getSharedPreferences("cloud", Context.MODE_PRIVATE)
    private fun toast(ctx: Context, msg: String) { main.post { Toast.makeText(ctx.applicationContext, msg, Toast.LENGTH_LONG).show() } }

    // ---------- identificadores globales de equipos (iguales en todos los teléfonos) ----------
    private fun gidMap(c: Context): MutableMap<String, String> = try {
        gson.fromJson(sp(c).getString("gids", "{}"), object : TypeToken<MutableMap<String, String>>() {}.type) ?: mutableMapOf()
    } catch (_: Exception) { mutableMapOf() }

    private fun saveGids(c: Context, m: Map<String, String>) { sp(c).edit().putString("gids", gson.toJson(m)).apply() }

    fun gidOf(c: Context, t: TeamEntity): String {
        val m = gidMap(c)
        m[t.id.toString()]?.let { return it }
        val g = if (t.name in setOf("Deportivo Maracaibo", "Atlético Zuliano", "Deportivo AD", "Estudiantes de Trujillo"))
            "def_" + t.name.lowercase().replace(Regex("[^a-z]"), "") else UUID.randomUUID().toString()
        m[t.id.toString()] = g; saveGids(c, m)
        return g
    }

    fun gidFor(c: Context, id: Long): String {
        val m = gidMap(c)
        m[id.toString()]?.let { return it }
        val g = UUID.randomUUID().toString(); m[id.toString()] = g; saveGids(c, m)
        return g
    }

    fun setGid(c: Context, id: Long, gid: String) { val m = gidMap(c); m[id.toString()] = gid; saveGids(c, m) }
    fun localIdOf(c: Context, gid: String): Long? = gidMap(c).entries.firstOrNull { it.value == gid }?.key?.toLongOrNull()

    // ---------- imágenes pequeñas dentro de los documentos ----------
    private fun encodeImage(ctx: Context, uri: String?, max: Int, png: Boolean): String? {
        if (uri == null) return null
        return try {
            val u = Uri.parse(uri)
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / (s * 2) >= max && o.outHeight / (s * 2) >= max) s *= 2
            val bmp = ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s }) } ?: return null
            val k = max.toFloat() / maxOf(bmp.width, bmp.height)
            val out = if (k < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt().coerceAtLeast(1), (bmp.height * k).toInt().coerceAtLeast(1), true) else bmp
            val bos = ByteArrayOutputStream()
            out.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 80, bos)
            Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
        } catch (_: Exception) { null }
    }

    private fun decodeImage(ctx: Context, b64: String?, dir: String): String? {
        if (b64.isNullOrEmpty()) return null
        return try {
            val f = File(File(ctx.filesDir, dir).apply { mkdirs() }, "c_${b64.length}_${b64.hashCode()}.img")
            if (!f.exists()) f.writeBytes(Base64.decode(b64, Base64.NO_WRAP))
            Uri.fromFile(f).toString()
        } catch (_: Exception) { null }
    }

    // ---------- sesión anónima: cada teléfono tiene un código ----------
    suspend fun uid(): String? {
        val auth = FirebaseAuth.getInstance()
        auth.currentUser?.let { return it.uid }
        return auth.signInAnonymously().await().user?.uid
    }

    // ---------- subir ----------
    suspend fun pushTeam(ctx: Context, t: TeamEntity) {
        val app = ctx.applicationContext
        uid()
        val players = Players.parse(t.playersJson).map { CPlayer(it.name, it.number, encodeImage(app, it.photo, 120, false), it.position, it.birth) }
        val data = hashMapOf<String, Any>(
            "name" to t.name, "shortName" to t.shortName, "color" to t.primaryColor,
            "badge" to (encodeImage(app, t.badgeUri, 192, true) ?: ""),
            "players" to gson.toJson(players),
            "pw" to (Auth.passHash(app, t.id) ?: "")
        )
        FirebaseFirestore.getInstance().collection("teams").document(gidOf(app, t)).set(data).await()
    }

    suspend fun deleteTeam(ctx: Context, localId: Long) {
        uid()
        FirebaseFirestore.getInstance().collection("teams").document(gidFor(ctx.applicationContext, localId)).delete().await()
    }

    private fun toCloud(app: Context, t: Tournament) = CTournament(
        t.name, t.winPts, t.drawPts, t.penRounds, t.startDate, t.intervalDays, t.nextId,
        t.teamIds.map { gidFor(app, it) },
        t.fixtures.map { f ->
            CFixture(f.id, f.round, gidFor(app, f.homeId), gidFor(app, f.awayId), f.played,
                f.events.map { CEvent(it.type, gidFor(app, it.teamId), it.player, it.minute) }, f.homePens, f.awayPens, f.videoUrl, f.date,
                if (f.walkoverWinner != 0L) gidFor(app, f.walkoverWinner) else "")
        },
        scorersMode = t.scorersMode,
        manualScorers = t.manualScorers.map { CScorer(it.player, gidFor(app, it.teamId), it.goals) }
    )

    private fun fromCloud(app: Context, c: CTournament): Tournament {
        fun id(g: String) = localIdOf(app, g)
        val t = Tournament(c.name, c.teamGids.mapNotNull { id(it) }.toMutableList(), mutableListOf(), c.winPts, c.drawPts, c.penRounds, c.startDate, c.intervalDays, c.nextId)
        for (f in c.fixtures) {
            val h = id(f.homeGid) ?: continue
            val a = id(f.awayGid) ?: continue
            t.fixtures.add(Fixture(
                id = f.id, round = f.round, homeId = h, awayId = a, played = f.played,
                events = f.events.mapNotNull { e -> id(e.teamGid)?.let { FEvent(e.type, it, e.player, e.minute) } }.toMutableList(),
                homePens = f.homePens, awayPens = f.awayPens, videoUrl = f.videoUrl, date = f.date,
                walkoverWinner = if (f.walkoverGid.isNotEmpty()) (id(f.walkoverGid) ?: 0L) else 0L
            ))
        }
        t.scorersMode = c.scorersMode
        t.manualScorers = c.manualScorers.mapNotNull { sc -> id(sc.teamGid)?.let { ManualScorer(sc.player, it, sc.goals) } }.toMutableList()
        return t
    }

    suspend fun pushCopa(ctx: Context) {
        val app = ctx.applicationContext
        uid()
        val json = gson.toJson(toCloud(app, TournamentStore.get(app)))
        FirebaseFirestore.getInstance().collection("fp").document("copa").set(hashMapOf("json" to json, "updatedAt" to System.currentTimeMillis())).await()
    }

    suspend fun pushAll(ctx: Context): String {
        if (!enabled(ctx)) return "La nube no está configurada"
        val app = ctx.applicationContext
        val dao = (app as App).db.teams()
        dao.getAll().forEach { pushTeam(app, it) }
        pushCopa(app)
        return "Todo publicado en la nube"
    }

    // ---------- bajar ----------
    suspend fun pull(ctx: Context): String {
        if (!enabled(ctx)) return "La nube no está configurada"
        val app = ctx.applicationContext
        val fs = FirebaseFirestore.getInstance()
        val dao = (app as App).db.teams()
        val snap = fs.collection("teams").get().await()
        val local = dao.getAll()
        for (doc in snap.documents) {
            val gid = doc.id
            val name = doc.getString("name") ?: continue
            val short = doc.getString("shortName") ?: name.take(3).uppercase()
            val color = doc.getString("color") ?: "#1E88E5"
            val badge = decodeImage(app, doc.getString("badge"), "badges")
            val players = try {
                gson.fromJson(doc.getString("players") ?: "[]", Array<CPlayer>::class.java).map { Player(it.name, it.number, decodeImage(app, it.photo, "players"), it.position, it.birth) }
            } catch (_: Exception) { emptyList() }
            val existing = local.firstOrNull { gidOf(app, it) == gid }
            if (existing != null) {
                dao.update(existing.copy(name = name, shortName = short, primaryColor = color, badgeUri = badge ?: existing.badgeUri, playersJson = Players.toJson(players)))
            } else {
                val nid = dao.insert(TeamEntity(name = name, shortName = short, badgeUri = badge, primaryColor = color, playersJson = Players.toJson(players)))
                setGid(app, nid, gid)
            }
            doc.getString("pw")?.takeIf { it.isNotEmpty() }?.let { Auth.setHash(app, gid, it) }
        }
        Auth.ensureDefaults(app, dao.getAll())
        val cd = fs.collection("fp").document("copa").get().await()
        cd.getString("json")?.let { j -> TournamentStore.replace(app, fromCloud(app, gson.fromJson(j, CTournament::class.java))) }
        lastPull = System.currentTimeMillis()
        return "Sincronizado con la nube"
    }

    /** Baja los datos si pasaron más de 60 s desde la última vez. */
    fun pullAsync(ctx: Context, force: Boolean = false, done: (String) -> Unit = {}) {
        if (!enabled(ctx)) return
        if (!force && System.currentTimeMillis() - lastPull < 60_000) return
        scope.launch {
            val msg = try { uid(); pull(ctx) } catch (e: Exception) { "No se pudo sincronizar: ${e.message}" }
            main.post { done(msg) }
        }
    }

    fun pushCopaAsync(ctx: Context) {
        if (!enabled(ctx) || !Auth.isAdmin(ctx)) return
        scope.launch { try { pushCopa(ctx) } catch (e: Exception) { toast(ctx, "No se pudo publicar en la nube: ${e.message}") } }
    }

    fun pushTeamAsync(ctx: Context, t: TeamEntity) {
        if (!enabled(ctx) || !Auth.canEdit(ctx, t.id)) return
        scope.launch { try { pushTeam(ctx, t) } catch (e: Exception) { toast(ctx, "No se pudo publicar el equipo: ${e.message}") } }
    }

    fun deleteTeamAsync(ctx: Context, id: Long) {
        if (!enabled(ctx)) return
        scope.launch { try { deleteTeam(ctx, id) } catch (_: Exception) {} }
    }

    fun pushAllAsync(ctx: Context, done: (String) -> Unit) {
        scope.launch {
            val msg = try { pushAll(ctx) } catch (e: Exception) { "No se pudo publicar: ${e.message}" }
            main.post { done(msg) }
        }
    }

    fun myCodeAsync(done: (String) -> Unit) {
        scope.launch { val u = try { uid() } catch (e: Exception) { null }; main.post { done(u ?: "No se pudo obtener el código (¿internet o acceso anónimo activado?)") } }
    }

    fun addAdminAsync(code: String, done: (String) -> Unit) {
        scope.launch {
            val msg = try {
                uid()
                FirebaseFirestore.getInstance().collection("admins").document(code.trim()).set(hashMapOf("added" to System.currentTimeMillis())).await()
                "Listo: ese teléfono ya es admin en la nube"
            } catch (e: Exception) { "No se pudo agregar (solo un admin puede): ${e.message}" }
            main.post { done(msg) }
        }
    }
}
