package com.futbolpro.recorder.ui.settings

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.futbolpro.recorder.data.Prefs
import com.futbolpro.recorder.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val b = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(b.root)
        val prefs = Prefs(this)
        b.spDefRes.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("720p", "1080p", "4K"))
        b.spDefFps.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("30", "60"))
        b.spDefRes.setSelection(listOf("720p","1080p","4K").indexOf(prefs.defaultResolution).coerceAtLeast(0))
        b.spDefFps.setSelection(if (prefs.defaultFps == 60) 1 else 0)
        b.etDefHalf.setText(prefs.defaultHalfMinutes.toString())
        b.btnSaveSettings.setOnClickListener {
            prefs.defaultResolution = b.spDefRes.selectedItem.toString()
            prefs.defaultFps = b.spDefFps.selectedItem.toString().toInt()
            prefs.defaultHalfMinutes = b.etDefHalf.text.toString().toIntOrNull() ?: 45
            Toast.makeText(this, "Ajustes guardados", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
