package com.futbolpro.recorder.ui.login

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.futbolpro.recorder.App
import com.futbolpro.recorder.R
import com.futbolpro.recorder.data.Auth
import com.futbolpro.recorder.data.TeamEntity
import com.futbolpro.recorder.databinding.ActivityLoginBinding
import com.futbolpro.recorder.ui.MainActivity
import com.futbolpro.recorder.ui.cup.CupUi
import com.futbolpro.recorder.ui.teams.TeamEditActivity
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {
    private lateinit var b: ActivityLoginBinding
    private lateinit var ui: CupUi
    private var retried = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(b.root)
        ui = CupUi(this)
        b.btnNewTeamLogin.setOnClickListener { startActivity(Intent(this, TeamEditActivity::class.java)) }
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    private fun load() {
        lifecycleScope.launch {
            var teams = (application as App).db.teams().getAll()
            if (teams.isEmpty() && !retried) { retried = true; delay(1200); teams = (application as App).db.teams().getAll() }
            Auth.ensureDefaults(this@LoginActivity, teams)
            val cur = Auth.currentTeamId(this@LoginActivity)
            if (cur >= 0 && teams.any { it.id == cur }) { goMain(); return@launch }
            render(teams)
        }
    }

    private fun goMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun render(teams: List<TeamEntity>) {
        b.listContainer.removeAllViews()
        if (teams.isEmpty()) {
            b.listContainer.addView(ui.tv("Aún no hay equipos. Crea el primero abajo.", 14f, Color.parseColor("#8E8E93")))
            return
        }
        teams.forEach { t ->
            val row = ui.row()
            row.isClickable = true; com.futbolpro.recorder.util.Fx.press(row)
            row.addView(ui.badge(t, 48))
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = ui.dp(14) } }
            col.addView(ui.tv(t.name, 17f, Color.WHITE, true, 0f, Gravity.START))
            col.addView(ui.tv(if (t.id in Auth.admins(this)) "${t.shortName} · Admin" else t.shortName, 12f, Color.parseColor("#8E8E93"), false, 0f, Gravity.START))
            row.addView(col)
            row.addView(android.widget.ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(ui.dp(22), ui.dp(22)); setImageResource(R.drawable.ic_chevron_right)
                imageTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#8E8E93"))
            })
            row.setOnClickListener { askPassword(t) }
            b.listContainer.addView(row)
        }
    }

    private fun askPassword(t: TeamEntity) {
        val et = EditText(this).apply { hint = "Contraseña"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        val box = LinearLayout(this).apply { setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0); addView(et, LinearLayout.LayoutParams(-1, -2)) }
        AlertDialog.Builder(this).setTitle("Entrar como ${t.name}").setView(box)
            .setPositiveButton("Entrar") { _, _ ->
                if (Auth.check(this, t.id, et.text.toString())) { Auth.login(this, t.id); goMain() }
                else Toast.makeText(this, "Contraseña incorrecta", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancelar", null).show()
    }
}
