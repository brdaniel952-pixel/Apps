package com.futbolpro.recorder.util

import android.annotation.SuppressLint
import android.view.MotionEvent
import android.view.View

object Fx {
    /** Efecto al tocar: la tarjeta se achica un poquito. */
    @SuppressLint("ClickableViewAccessibility")
    fun press(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false
        }
    }

    /** Entrada suave: aparece y sube un poco. */
    fun enter(v: View, index: Int) {
        v.alpha = 0f
        v.translationY = 10f
        v.animate().alpha(1f).translationY(0f).setStartDelay((index.coerceIn(0, 10) * 40).toLong()).setDuration(220).start()
    }
}
