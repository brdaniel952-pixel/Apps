package com.futbolpro.recorder.ui.cup

import android.app.DatePickerDialog
import android.content.Intent
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.futbolpro.recorder.App
import com.futbolpro.recorder.data.*
import com.futbolpro.recorder.databinding.ActivityTournamentBinding
import kotlinx.coroutines.launch

class TournamentActivity : AppCompatActivity() {
    private lateinit var b: ActivityTournamentBinding
    private lateinit var t: Tournament
    private lateinit var ui: CupUi
    private var teams: Map<Long, TeamEntity> = emptyMap()
    private var tab = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityTournamentBinding.inflate(layoutInflater)
        setContentView(b.root)
        ui = CupUi(this)
        t = TournamentStore.get(this)
        b.tabTable.setOnClickListener { tab = 0; render() }
        b.tabScorers.setOnClickListener { tab = 1; render() }
        b.tabFixtures.setOnClickListener { tab = 2; render() }
        b.btnCupMore.setOnClickListener { more() }
        b.btnCupTeams.setOnClickListener { pickTeams() }
        b.btnCupGen.setOnClickListener { generate() }
        b.btnCupAdd.setOnClickListener { addFixture() }
        if (!Auth.isAdmin(this)) {
            listOf<android.view.View>(b.btnCupMore, b.btnCupTeams, b.btnCupGen, b.btnCupAdd).forEach { it.visibility = android.view.View.GONE }
        }
    }

    override fun onResume() {
        super.onResume()
        t = TournamentStore.get(this)
        CloudSync.pullAsync(this) { t = TournamentStore.get(this); render() }
        lifecycleScope.launch {
            teams = (application as App).db.teams().getAll().associateBy { it.id }
            render()
        }
    }

    private fun save() { TournamentStore.save(this); render() }

    private fun render() {
        b.tvCupName.text = t.name
        val sel = Color.parseColor("#2F6BFF")
        listOf(b.tabTable, b.tabScorers, b.tabFixtures).forEachIndexed { i, v ->
            v.setBackgroundColor(if (i == tab) sel else Color.TRANSPARENT)
            v.background?.let { }
        }
        b.content.removeAllViews()
        when (tab) { 0 -> renderTable(); 1 -> renderScorers(); else -> renderFixtures() }
    }

    private fun renderTable() {
        val rows = TournamentStore.standings(t)
        if (rows.isEmpty()) { empty("Agrega equipos a la copa con el botón Equipos."); return }
        val h = ui.row()
        val g = Color.parseColor("#8FA3C8")
        h.addView(ui.tv("#", 11f, g, true, 0.6f)); h.addView(ui.tv("EQUIPO", 11f, g, true, 3.4f, Gravity.START))
        listOf("PJ", "G", "E", "P", "DG", "PTS").forEachIndexed { i, s -> h.addView(ui.tv(s, 11f, g, true, if (i == 5) 0.9f else 0.7f)) }
        b.content.addView(h)
        rows.forEachIndexed { i, r ->
            val tm = teams[r.teamId]
            val row = ui.row()
            val posColor = when (i) { 0 -> "#FFC94D"; 1 -> "#C9D1E3"; 2 -> "#D9955A"; 3 -> "#7FB8FF"; else -> "#FFFFFF" }
            row.addView(ui.tv("${i + 1}°", 14f, Color.parseColor(posColor), true, 0.6f))
            val name = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 3.4f) }
            name.addView(ui.badge(tm, 28))
            name.addView(ui.tv(tm?.name ?: "?", 14f, Color.WHITE, true, 0f, Gravity.START).apply { setPadding(ui.dp(8), 0, 0, 0); maxLines = 1 })
            row.addView(name)
            listOf(r.pj, r.g, r.e, r.p, r.dg).forEach { row.addView(ui.tv(it.toString(), 13f, Color.parseColor("#CFD8EA"), false, 0.7f)) }
            row.addView(ui.tv(r.pts.toString(), 16f, Color.WHITE, true, 0.9f))
            b.content.addView(row)
        }
        b.content.addView(ui.tv("Victoria ${t.winPts} pts · Empate ${t.drawPts} pt · Los puntos se calculan solos con los partidos jugados", 11f, Color.parseColor("#8FA3C8")).apply { setPadding(0, ui.dp(8), 0, 0) })
    }

    private fun renderScorers() {
        val list = TournamentStore.scorers(t)
        if (list.isEmpty()) { empty("Aún no hay goles con nombre de jugador."); return }
        list.forEachIndexed { i, s ->
            val tm = teams[s.teamId]
            val row = ui.row()
            row.addView(ui.tv("${i + 1}", 15f, if (i == 0) Color.parseColor("#FFC94D") else Color.WHITE, true).apply { layoutParams = LinearLayout.LayoutParams(ui.dp(28), -2) })
            row.addView(ui.photo(Players.photoOf(tm, s.player), 46))
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = ui.dp(12) } }
            col.addView(ui.tv(s.player, 16f, Color.WHITE, true, 0f, Gravity.START))
            col.addView(ui.tv(tm?.name ?: "?", 12f, Color.parseColor("#8FA3C8"), false, 0f, Gravity.START))
            row.addView(col)
            row.addView(ui.badge(tm, 26))
            row.addView(ui.tv(s.goals.toString(), 24f, Color.WHITE, true).apply { setPadding(ui.dp(14), 0, 0, 0) })
            b.content.addView(row)
        }
    }

    private fun renderFixtures() {
        if (t.fixtures.isEmpty()) { empty("No hay partidos. Usa Calendario (automático) o Partido (manual)."); return }
        t.fixtures.groupBy { it.round }.toSortedMap().forEach { (round, list) ->
            val d0 = list.firstOrNull { it.date > 0 }?.date
            b.content.addView(ui.header("FECHA $round" + if (d0 != null) "  ·  " + SimpleDateFormat("EEE d MMM", Locale("es")).format(Date(d0)).uppercase() else ""))
            list.forEach { f ->
                val h = teams[f.homeId]; val a = teams[f.awayId]
                val row = ui.row()
                row.addView(ui.badge(h, 30))
                row.addView(ui.tv(h?.shortName ?: "?", 15f, Color.WHITE, true, 1f))
                val mid = if (f.played) "${f.homeGoals()} - ${f.awayGoals()}" else "vs"
                row.addView(ui.tv(mid, 20f, if (f.played) Color.WHITE else Color.parseColor("#8FA3C8"), true, 1.1f))
                row.addView(ui.tv(a?.shortName ?: "?", 15f, Color.WHITE, true, 1f))
                row.addView(ui.badge(a, 30))
                if (f.videoUrl.isNotBlank()) row.addView(ui.tv("VIDEO", 10f, Color.parseColor("#4DA3FF"), true).apply { setPadding(ui.dp(8), 0, 0, 0) })
                row.isClickable = true
                row.setOnClickListener { startActivity(Intent(this, FixtureActivity::class.java).putExtra("fixtureId", f.id)) }
                b.content.addView(row)
            }
        }
    }

    private fun empty(msg: String) {
        b.content.addView(ui.tv(msg, 14f, Color.parseColor("#9FB2DA")).apply { setPadding(0, ui.dp(30), 0, ui.dp(16)) })
        if (Auth.isAdmin(this)) b.content.addView(ui.btn("Crear torneo") { wizard() })
    }

    // ---------- Asistente: nombre, equipos, formato y fechas. La app arma todo el calendario ----------
    private fun wizard() {
        if (t.fixtures.any { it.played }) {
            AlertDialog.Builder(this).setTitle("Crear torneo nuevo").setMessage("Ya hay partidos jugados. Un torneo nuevo borra los partidos y resultados actuales. ¿Continuar?")
                .setPositiveButton("Continuar") { _, _ -> wizardName() }.setNegativeButton("Cancelar", null).show()
        } else wizardName()
    }

    private fun wizardName() {
        input("Nombre del torneo", t.name, false) { name ->
            val all = teams.values.toList()
            if (all.size < 2) { Toast.makeText(this, "Necesitas al menos 2 equipos creados", Toast.LENGTH_LONG).show(); return@input }
            val checked = BooleanArray(all.size) { true }
            AlertDialog.Builder(this).setTitle("¿Qué equipos juegan?")
                .setMultiChoiceItems(all.map { it.name }.toTypedArray(), checked) { _, i, v -> checked[i] = v }
                .setPositiveButton("Siguiente") { _, _ ->
                    val ids = all.filterIndexed { i, _ -> checked[i] }.map { it.id }
                    if (ids.size < 2) { Toast.makeText(this, "Elige al menos 2 equipos", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                    AlertDialog.Builder(this).setTitle("Formato")
                        .setItems(arrayOf("Todos contra todos (solo ida)", "Ida y vuelta")) { _, f -> wizardDate(name.ifBlank { "Copa" }, ids, f == 1) }.show()
                }.setNegativeButton("Cancelar", null).show()
        }
    }

    private fun wizardDate(name: String, ids: List<Long>, doubleRound: Boolean) {
        val cal = Calendar.getInstance()
        DatePickerDialog(this, { _, y, m, d ->
            val c = Calendar.getInstance().apply { set(y, m, d, 12, 0, 0); set(Calendar.MILLISECOND, 0) }
            val labels = arrayOf("Una fecha cada semana", "Una fecha cada 2 semanas", "Una fecha cada día", "Una fecha cada 3 días")
            val days = intArrayOf(7, 14, 1, 3)
            AlertDialog.Builder(this).setTitle("¿Cada cuánto se juega una fecha?").setItems(labels) { _, i ->
                val nt = Tournament(name = name, teamIds = ids.toMutableList(), winPts = t.winPts, drawPts = t.drawPts, penRounds = t.penRounds,
                    startDate = c.timeInMillis, intervalDays = days[i])
                TournamentStore.generate(nt, doubleRound)
                TournamentStore.replace(this, nt)
                t = nt
                tab = 2; save()
                Toast.makeText(this, "Torneo creado: ${nt.fixtures.size} partidos en ${nt.fixtures.maxOfOrNull { it.round } ?: 0} fechas", Toast.LENGTH_LONG).show()
            }.show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).apply { setTitle("¿Cuándo empieza la primera fecha?") }.show()
    }

    private fun pickTeams() {
        val all = teams.values.toList()
        if (all.isEmpty()) { Toast.makeText(this, "Primero crea equipos en la sección Equipos", Toast.LENGTH_LONG).show(); return }
        val checked = BooleanArray(all.size) { all[it].id in t.teamIds }
        AlertDialog.Builder(this).setTitle("Equipos de la copa")
            .setMultiChoiceItems(all.map { it.name }.toTypedArray(), checked) { _, i, v -> checked[i] = v }
            .setPositiveButton("Guardar") { _, _ ->
                t.teamIds = all.filterIndexed { i, _ -> checked[i] }.map { it.id }.toMutableList()
                save()
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun generate() {
        if (t.teamIds.size < 2) { Toast.makeText(this, "Elige al menos 2 equipos (botón Equipos)", Toast.LENGTH_LONG).show(); return }
        AlertDialog.Builder(this).setTitle("Calendario automático")
            .setMessage("Se crean todos los cruces. Los partidos ya jugados no se tocan; los pendientes se reemplazan.")
            .setItems(arrayOf("Solo ida", "Ida y vuelta")) { _, i ->
                TournamentStore.generate(t, i == 1); tab = 2; save()
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun addFixture() {
        val ids = if (t.teamIds.size >= 2) t.teamIds.toList() else teams.keys.toList()
        if (ids.size < 2) { Toast.makeText(this, "Necesitas al menos 2 equipos", Toast.LENGTH_LONG).show(); return }
        val names = ids.map { teams[it]?.name ?: "?" }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0) }
        val sh = Spinner(this).apply { adapter = ArrayAdapter(this@TournamentActivity, android.R.layout.simple_spinner_dropdown_item, names) }
        val sa = Spinner(this).apply { adapter = ArrayAdapter(this@TournamentActivity, android.R.layout.simple_spinner_dropdown_item, names); setSelection(1) }
        val et = EditText(this).apply { hint = "Número de fecha"; setText((t.fixtures.maxOfOrNull { it.round } ?: 1).toString()); inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        box.addView(TextView(this).apply { text = "Local" }); box.addView(sh)
        box.addView(TextView(this).apply { text = "Visitante" }); box.addView(sa); box.addView(et)
        AlertDialog.Builder(this).setTitle("Agregar partido").setView(box)
            .setPositiveButton("Agregar") { _, _ ->
                val h = ids[sh.selectedItemPosition]; val a = ids[sa.selectedItemPosition]
                if (h == a) { Toast.makeText(this, "Elige equipos distintos", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                t.fixtures.add(Fixture(id = t.nextId++, round = et.text.toString().toIntOrNull() ?: 1, homeId = h, awayId = a))
                tab = 2; save()
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun more() {
        AlertDialog.Builder(this).setItems(arrayOf("Crear torneo nuevo (automático)", "Cambiar nombre de la copa", "Puntos por victoria y empate", "Penales por defecto", "Borrar toda la copa", "Compartir tabla y fechas (WhatsApp)")) { _, i ->
            when (i) {
                0 -> wizard()
                1 -> input("Nombre de la copa", t.name, false) { t.name = it.ifBlank { t.name }; save() }
                2 -> input("Puntos por victoria", t.winPts.toString(), true) { w ->
                    input("Puntos por empate", t.drawPts.toString(), true) { d -> t.winPts = w.toIntOrNull() ?: 3; t.drawPts = d.toIntOrNull() ?: 1; save() }
                }
                3 -> input("Penales por equipo (tanda)", t.penRounds.toString(), true) { t.penRounds = (it.toIntOrNull() ?: 3).coerceIn(1, 11); save() }
                5 -> shareText()
                else -> AlertDialog.Builder(this).setTitle("Borrar toda la copa").setMessage("Se borran partidos, goles y tarjetas. Los equipos se quedan.")
                    .setPositiveButton("Borrar") { _, _ -> TournamentStore.reset(this); t = TournamentStore.get(this); render() }
                    .setNegativeButton("Cancelar", null).show()
            }
        }.show()
    }

    /** Arma un mensaje con la tabla, los goleadores y las fechas para mandarlo por WhatsApp u otra app. */
    private fun shareText() {
        val fmt = SimpleDateFormat("EEE d MMM", Locale("es"))
        fun n(id: Long) = teams[id]?.shortName ?: "?"
        val sb = StringBuilder()
        sb.append("*${t.name}*\n\n*TABLA*\n")
        TournamentStore.standings(t).forEachIndexed { i, r ->
            sb.append("${i + 1}° ${teams[r.teamId]?.name ?: "?"} — ${r.pts} pts (PJ ${r.pj}, G ${r.g}, E ${r.e}, P ${r.p}, DG ${if (r.dg > 0) "+" else ""}${r.dg})\n")
        }
        val sc = TournamentStore.scorers(t).take(5)
        if (sc.isNotEmpty()) {
            sb.append("\n*GOLEADORES*\n")
            sc.forEachIndexed { i, s -> sb.append("${i + 1}. ${s.player} (${n(s.teamId)}) — ${s.goals}\n") }
        }
        if (t.fixtures.isNotEmpty()) {
            sb.append("\n*FECHAS*\n")
            t.fixtures.groupBy { it.round }.toSortedMap().forEach { (round, list) ->
                val d0 = list.firstOrNull { it.date > 0 }?.date
                sb.append("Fecha $round" + (if (d0 != null) " · " + fmt.format(Date(d0)) else "") + "\n")
                list.forEach { f -> sb.append(if (f.played) "  ${n(f.homeId)} ${f.homeGoals()} - ${f.awayGoals()} ${n(f.awayId)}\n" else "  ${n(f.homeId)} vs ${n(f.awayId)}\n") }
            }
        }
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, sb.toString()) }, "Compartir"))
    }

    private fun input(title: String, value: String, number: Boolean, ok: (String) -> Unit) {
        val et = EditText(this).apply { setText(value); if (number) inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        val box = LinearLayout(this).apply { setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0); addView(et, LinearLayout.LayoutParams(-1, -2)) }
        AlertDialog.Builder(this).setTitle(title).setView(box)
            .setPositiveButton("Aceptar") { _, _ -> ok(et.text.toString().trim()) }
            .setNegativeButton("Cancelar", null).show()
    }
}
