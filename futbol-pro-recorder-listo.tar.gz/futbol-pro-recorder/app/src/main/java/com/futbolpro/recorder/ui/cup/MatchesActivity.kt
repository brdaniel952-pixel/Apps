package com.futbolpro.recorder.ui.cup

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.futbolpro.recorder.App
import com.futbolpro.recorder.data.CloudSync
import com.futbolpro.recorder.data.Fixture
import com.futbolpro.recorder.data.TeamEntity
import com.futbolpro.recorder.data.TournamentStore
import com.futbolpro.recorder.databinding.ActivityMatchesBinding
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Lista de partidos jugados con su resultado y enlace de video (visible para todos). */
class MatchesActivity : AppCompatActivity() {
    private lateinit var b: ActivityMatchesBinding
    private lateinit var ui: CupUi

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMatchesBinding.inflate(layoutInflater)
        setContentView(b.root)
        ui = CupUi(this)
    }

    override fun onResume() {
        super.onResume()
        render()
        CloudSync.pullAsync(this) { render() }
    }

    private fun render() {
        lifecycleScope.launch {
            val teams: Map<Long, TeamEntity> = (application as App).db.teams().getAll().associateBy { it.id }
            val t = TournamentStore.get(this@MatchesActivity)
            val fmt = SimpleDateFormat("EEE d MMM", Locale("es"))
            val list = t.fixtures.filter { it.played || it.videoUrl.isNotBlank() }.sortedWith(compareByDescending<Fixture> { it.date }.thenByDescending { it.round })
            b.matchesContainer.removeAllViews()
            if (list.isEmpty()) {
                b.matchesContainer.addView(ui.tv("Todavía no hay partidos jugados.", 14f, Color.parseColor("#8E8E93")).apply { setPadding(0, ui.dp(30), 0, 0) })
                return@launch
            }
            for (f in list) {
                val h = teams[f.homeId]; val a = teams[f.awayId]
                val card = ui.row(true)
                val sub = (if (f.walkoverWinner != 0L) "W.O. · " else "") + "FECHA ${f.round}" + if (f.date > 0) " · " + fmt.format(Date(f.date)).uppercase() else ""
                card.addView(ui.tv(sub, 11f, Color.parseColor("#0A84FF"), true, 0f, Gravity.START))
                val line = LinearLayout(this@MatchesActivity).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, ui.dp(8), 0, ui.dp(8)) }
                line.addView(ui.badge(h, 34)); line.addView(ui.tv(h?.shortName ?: "?", 15f, Color.WHITE, true, 1f))
                line.addView(ui.tv(if (f.played) "${f.homeGoals()} - ${f.awayGoals()}" else "vs", 22f, Color.WHITE, true, 1.2f))
                line.addView(ui.tv(a?.shortName ?: "?", 15f, Color.WHITE, true, 1f)); line.addView(ui.badge(a, 34))
                card.addView(line)
                if (f.hasPens()) card.addView(ui.tv("Penales ${f.homePens} - ${f.awayPens}", 12f, Color.parseColor("#8E8E93")))
                val url = f.videoUrl.trim()
                val local = f.video
                if (url.isNotEmpty() || local != null) {
                    card.addView(ui.btn(if (url.isNotEmpty()) "Ver video" else "Ver video (este teléfono)") {
                        try {
                            if (url.isNotEmpty()) startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                            else startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(local), "video/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                        } catch (_: Exception) { Toast.makeText(this@MatchesActivity, "No se pudo abrir el video", Toast.LENGTH_SHORT).show() }
                    })
                } else card.addView(ui.tv("Sin video todavía", 12f, Color.parseColor("#8E8E93")))
                b.matchesContainer.addView(card)
            }
        }
    }
}
