package com.futbolpro.recorder.overlay

import android.content.Context
import android.graphics.*
import android.net.Uri
import android.util.AttributeSet
import android.view.View
import com.futbolpro.recorder.domain.MatchState
import com.futbolpro.recorder.domain.ScoreboardStyle
import com.futbolpro.recorder.domain.TimeFmt

class ScoreboardOverlayView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    var state: MatchState = MatchState()
        set(v) { field = v; invalidate() }
    var style: ScoreboardStyle = ScoreboardStyle()
        set(v) { field = v; invalidate() }

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
    private val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val homePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val awayPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var homeBmp: Bitmap? = null
    private var awayBmp: Bitmap? = null

    fun setBadges(home: String?, away: String?) {
        homeBmp = home?.let { loadBitmap(it) }
        awayBmp = away?.let { loadBitmap(it) }
        invalidate()
    }

    private fun loadBitmap(uriStr: String): Bitmap? = try {
        context.contentResolver.openInputStream(Uri.parse(uriStr))?.use { BitmapFactory.decodeStream(it) }
    } catch (_: Exception) { null }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s = state
        val st = style
        val w = width.toFloat().coerceAtLeast(1f)
        val h = height.toFloat().coerceAtLeast(1f)
        val baseH = 64f * st.scale
        val baseW = when (st.template) { "minimal" -> 520f; "bold" -> 700f; else -> 620f } * st.scale
        val cx = w * 0.5f
        val top = h * st.y
        val left = cx - baseW / 2f
        val rect = RectF(left, top, left + baseW, top + baseH)
        val radius = when (st.template) { "bold" -> 6f; "minimal" -> 18f; else -> 12f } * st.scale
        bgPaint.color = TimeFmt.parseColor(st.bgColor, 0xCC0B1D3A.toInt())
        bgPaint.alpha = (st.alpha * 255).toInt().coerceIn(40, 255)
        canvas.drawRoundRect(rect, radius, radius, bgPaint)

        val section = baseW / 6f
        homePaint.color = TimeFmt.parseColor(s.homeColor)
        awayPaint.color = TimeFmt.parseColor(s.awayColor)
        val sideW = section * 1.6f
        canvas.drawRoundRect(RectF(left, top, left + sideW, top + baseH), radius, radius, homePaint)
        canvas.drawRoundRect(RectF(left + baseW - sideW, top, left + baseW, top + baseH), radius, radius, awayPaint)
        // cover inner corners
        canvas.drawRect(RectF(left + sideW - radius, top, left + sideW, top + baseH), homePaint)
        canvas.drawRect(RectF(left + baseW - sideW, top, left + baseW - sideW + radius, top + baseH), awayPaint)

        textPaint.color = Color.WHITE
        textPaint.textAlign = Paint.Align.CENTER
        val nameSize = 22f * st.scale
        val scoreSize = 34f * st.scale
        val timeSize = 20f * st.scale
        val cy = top + baseH / 2f

        fun drawNameBadge(name: String, bmp: Bitmap?, xCenter: Float, areaLeft: Float, areaRight: Float) {
            var textX = xCenter
            if (st.showBadges && bmp != null) {
                val bsz = baseH * 0.65f
                val bx = if (xCenter < cx) areaLeft + 8f * st.scale else areaRight - bsz - 8f * st.scale
                val by = top + (baseH - bsz) / 2f
                canvas.drawBitmap(bmp, null, RectF(bx, by, bx + bsz, by + bsz), null)
                textX = if (xCenter < cx) bx + bsz + (areaRight - (bx + bsz)) / 2f else areaLeft + (bx - areaLeft) / 2f
            }
            textPaint.textSize = nameSize
            canvas.drawText(name, textX, cy - 2f * st.scale, textPaint)
        }
        drawNameBadge(s.homeShort.ifBlank { s.homeName.take(3).uppercase() }, homeBmp, left + sideW / 2f, left, left + sideW)
        drawNameBadge(s.awayShort.ifBlank { s.awayName.take(3).uppercase() }, awayBmp, left + baseW - sideW / 2f, left + baseW - sideW, left + baseW)

        // center score/time
        val centerLeft = left + sideW
        val centerRight = left + baseW - sideW
        val ccx = (centerLeft + centerRight) / 2f
        textPaint.textSize = scoreSize
        canvas.drawText("${s.homeScore} - ${s.awayScore}", ccx, cy - 2f * st.scale, textPaint)
        subPaint.textAlign = Paint.Align.CENTER
        subPaint.textSize = timeSize
        subPaint.color = Color.WHITE
        val periodTxt = s.period.label
        val timeTxt = "${TimeFmt.mmss(s.elapsedMs)}  $periodTxt"
        canvas.drawText(timeTxt, ccx, top + baseH - 10f * st.scale, subPaint)
    }
}
