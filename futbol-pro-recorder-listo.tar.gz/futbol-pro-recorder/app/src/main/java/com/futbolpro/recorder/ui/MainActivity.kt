package com.futbolpro.recorder.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.futbolpro.recorder.databinding.ActivityMainBinding
import com.futbolpro.recorder.ui.history.HistoryActivity
import com.futbolpro.recorder.ui.match.NewMatchActivity
import com.futbolpro.recorder.ui.scoreboard.ScoreboardConfigActivity
import com.futbolpro.recorder.ui.settings.SettingsActivity
import com.futbolpro.recorder.ui.teams.TeamsActivity

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnNewMatch.setOnClickListener { startActivity(Intent(this, NewMatchActivity::class.java)) }
        b.btnTeams.setOnClickListener { startActivity(Intent(this, TeamsActivity::class.java)) }
        b.btnScoreboard.setOnClickListener { startActivity(Intent(this, ScoreboardConfigActivity::class.java)) }
        b.btnHistory.setOnClickListener { startActivity(Intent(this, HistoryActivity::class.java)) }
        b.btnSettings.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
    }
}
