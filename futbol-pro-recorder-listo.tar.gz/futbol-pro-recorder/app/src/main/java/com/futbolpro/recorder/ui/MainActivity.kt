package com.futbolpro.recorder.ui

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import com.futbolpro.recorder.App
import com.futbolpro.recorder.data.Auth
import com.futbolpro.recorder.data.CloudSync
import com.futbolpro.recorder.ui.cup.MatchesActivity
import com.futbolpro.recorder.ui.login.LoginActivity
import com.futbolpro.recorder.ui.teams.TeamEditActivity
import kotlinx.coroutines.launch
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.futbolpro.recorder.databinding.ActivityMainBinding
import com.futbolpro.recorder.data.TournamentStore
import com.futbolpro.recorder.ui.cup.TournamentActivity
import com.futbolpro.recorder.ui.history.HistoryActivity
import com.futbolpro.recorder.ui.match.NewMatchActivity
import com.futbolpro.recorder.ui.scoreboard.ScoreboardConfigActivity
import com.futbolpro.recorder.ui.settings.SettingsActivity
import com.futbolpro.recorder.ui.teams.TeamsActivity

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnNewMatch.setOnClickListener { startActivity(Intent(this, NewMatchActivity::class.java)) }
        b.chipTeam.setOnClickListener { teamMenu() }
        com.futbolpro.recorder.util.Fx.press(b.btnNewMatch)
        com.futbolpro.recorder.util.Fx.press(b.chipTeam)
        b.btnMatches.setOnClickListener { startActivity(Intent(this, MatchesActivity::class.java)) }
        b.btnCup.setOnClickListener { startActivity(Intent(this, TournamentActivity::class.java)) }
        b.btnTeams.setOnClickListener { startActivity(Intent(this, TeamsActivity::class.java)) }
        b.btnScoreboard.setOnClickListener { startActivity(Intent(this, ScoreboardConfigActivity::class.java)) }
        b.btnHistory.setOnClickListener { startActivity(Intent(this, HistoryActivity::class.java)) }
        b.btnSettings.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
    }

    override fun onResume() {
        super.onResume()
        refreshHeader()
        CloudSync.pullAsync(this) { refreshHeader() }
    }

    private fun refreshHeader() {
        b.tvCupTitle.text = TournamentStore.get(this).name
        lifecycleScope.launch {
            val t = (application as App).db.teams().getById(Auth.currentTeamId(this@MainActivity))
            if (t == null) { goLogin(); return@launch }
            b.tvChipTeam.text = if (Auth.isAdmin(this@MainActivity)) "${t.shortName} · Admin" else t.shortName
            try { b.imgChipBadge.setImageURI(t.badgeUri?.let { Uri.parse(it) }) } catch (_: Exception) {}
        }
    }

    private fun goLogin() {
        Auth.logout(this)
        startActivity(Intent(this, LoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        finish()
    }

    private fun teamMenu() {
        val items = mutableListOf("Editar mi equipo y contraseña")
        if (Auth.isAdmin(this)) items.add("Dar o quitar admin a equipos")
        if (CloudSync.enabled(this)) {
            items.add("Sincronizar ahora"); items.add("Mi código de nube")
            if (Auth.isAdmin(this)) { items.add("Publicar todo en la nube"); items.add("Agregar admin por código") }
        }
        items.add("Cambiar de equipo")
        AlertDialog.Builder(this).setItems(items.toTypedArray()) { _, i ->
            when (items[i]) {
                "Editar mi equipo y contraseña" -> startActivity(Intent(this, TeamEditActivity::class.java).putExtra("teamId", Auth.currentTeamId(this)))
                "Dar o quitar admin a equipos" -> adminDialog()
                "Sincronizar ahora" -> CloudSync.pullAsync(this, true) { msg -> android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_LONG).show(); refreshHeader() }
                "Mi código de nube" -> CloudSync.myCodeAsync { code ->
                    AlertDialog.Builder(this).setTitle("Mi código de nube").setMessage(code)
                        .setPositiveButton("Copiar") { _, _ ->
                            (getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("codigo", code))
                        }.setNegativeButton("Cerrar", null).show()
                }
                "Publicar todo en la nube" -> CloudSync.pushAllAsync(this) { msg -> android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_LONG).show() }
                "Agregar admin por código" -> {
                    val et = android.widget.EditText(this).apply { hint = "Código del teléfono" }
                    val bx = android.widget.LinearLayout(this).apply { setPadding(60, 20, 60, 0); addView(et, android.widget.LinearLayout.LayoutParams(-1, -2)) }
                    AlertDialog.Builder(this).setTitle("Agregar admin").setView(bx)
                        .setPositiveButton("Agregar") { _, _ -> CloudSync.addAdminAsync(et.text.toString()) { msg -> android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_LONG).show() } }
                        .setNegativeButton("Cancelar", null).show()
                }
                else -> goLogin()
            }
        }.show()
    }

    private fun adminDialog() {
        lifecycleScope.launch {
            val teams = (application as App).db.teams().getAll()
            val admins = Auth.admins(this@MainActivity)
            val checked = BooleanArray(teams.size) { teams[it].id in admins }
            AlertDialog.Builder(this@MainActivity).setTitle("Equipos con permiso de admin")
                .setMultiChoiceItems(teams.map { it.name }.toTypedArray(), checked) { _, i, v -> checked[i] = v }
                .setPositiveButton("Guardar") { _, _ ->
                    val ids = teams.filterIndexed { i, _ -> checked[i] }.map { it.id }.toSet()
                    if (ids.isEmpty()) android.widget.Toast.makeText(this@MainActivity, "Debe quedar al menos un admin", android.widget.Toast.LENGTH_LONG).show()
                    else { Auth.setAdmins(this@MainActivity, ids); onResume() }
                }.setNegativeButton("Cancelar", null).show()
        }
    }
}
