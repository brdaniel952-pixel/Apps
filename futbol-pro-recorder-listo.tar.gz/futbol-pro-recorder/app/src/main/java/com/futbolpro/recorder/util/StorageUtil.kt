package com.futbolpro.recorder.util

import android.content.Context
import android.os.Environment
import android.os.StatFs
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

object StorageUtil {
    fun matchesDir(context: Context): File {
        val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "Matches")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }
    fun newVideoFile(context: Context): File {
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        return File(matchesDir(context), "match_$ts.mp4")
    }
    fun freeSpaceMb(context: Context): Long {
        val stat = StatFs(context.filesDir.absolutePath)
        return stat.availableBytes / (1024 * 1024)
    }
    fun formatDuration(sec: Long): String {
        val h = sec / 3600; val m = (sec % 3600) / 60; val s = sec % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
    }
}
