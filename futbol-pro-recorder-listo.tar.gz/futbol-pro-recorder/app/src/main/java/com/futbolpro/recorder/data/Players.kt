package com.futbolpro.recorder.data

import android.content.Context
import android.net.Uri
import com.google.gson.Gson
import com.google.gson.JsonParser
import java.io.File

/** Jugador de un equipo (se guarda como JSON dentro de TeamEntity.playersJson). */
data class Player(var name: String = "", var number: String = "", var photo: String? = null, var position: String = "", var birth: String = "")

object Players {
    private val gson = Gson()

    fun parse(json: String?): MutableList<Player> = try {
        JsonParser.parseString(json ?: "[]").asJsonArray.map { el ->
            if (el.isJsonPrimitive) Player(name = el.asString) else gson.fromJson(el, Player::class.java)
        }.toMutableList()
    } catch (_: Exception) { mutableListOf() }

    fun toJson(list: List<Player>): String = gson.toJson(list)

    fun names(t: TeamEntity?): List<String> = parse(t?.playersJson).map { it.name }.filter { it.isNotBlank() }

    fun photoOf(t: TeamEntity?, name: String): String? = parse(t?.playersJson).firstOrNull { it.name == name }?.photo

    /** Copia la foto a la carpeta de la app para que no se pierda. */
    fun copyPhoto(ctx: Context, src: Uri): Uri? = try {
        val dir = File(ctx.filesDir, "players").apply { mkdirs() }
        val f = File(dir, "p_${System.currentTimeMillis()}.img")
        ctx.contentResolver.openInputStream(src)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        Uri.fromFile(f)
    } catch (_: Exception) { null }
}
