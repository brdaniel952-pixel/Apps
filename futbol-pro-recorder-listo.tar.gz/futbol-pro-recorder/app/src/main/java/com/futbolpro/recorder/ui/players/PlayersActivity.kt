package com.futbolpro.recorder.ui.players

import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.futbolpro.recorder.App
import com.futbolpro.recorder.R
import com.futbolpro.recorder.data.Player
import com.futbolpro.recorder.data.Players
import com.futbolpro.recorder.data.TeamEntity
import com.futbolpro.recorder.databinding.ActivityPlayersBinding
import kotlinx.coroutines.launch

class PlayersActivity : AppCompatActivity() {
    private lateinit var b: ActivityPlayersBinding
    private var team: TeamEntity? = null
    private var list = mutableListOf<Player>()
    private var newPhoto: Uri? = null
    private var editIndex = -1

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val pickPhoto = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val copy = uri?.let { Players.copyPhoto(this, it) } ?: return@registerForActivityResult
        if (editIndex >= 0) {
            list[editIndex].photo = copy.toString(); persist(); render()
        } else {
            newPhoto = copy
            b.imgPhoto.imageTintList = null
            b.imgPhoto.setPadding(0, 0, 0, 0)
            b.imgPhoto.setImageURI(copy)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityPlayersBinding.inflate(layoutInflater)
        setContentView(b.root)
        val id = intent.getLongExtra("teamId", -1L)
        lifecycleScope.launch {
            team = (application as App).db.teams().getById(id)
            b.tvTeamTitle.text = team?.name ?: "Plantilla"
            list = Players.parse(team?.playersJson)
            render()
        }
        b.imgPhoto.outlineProvider = ViewOutlineProvider.BACKGROUND
        b.imgPhoto.clipToOutline = true
        b.imgPhoto.setOnClickListener { editIndex = -1; pickPhoto.launch("image/*") }
        b.btnAddPlayer.setOnClickListener {
            val n = b.etName.text.toString().trim()
            if (n.isEmpty()) { Toast.makeText(this, "Escribe el nombre", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            list.add(Player(n, b.etNumber.text.toString().trim(), newPhoto?.toString()))
            persist(); render()
            b.etName.setText(""); b.etNumber.setText(""); newPhoto = null
            b.imgPhoto.setImageResource(R.drawable.ic_camera)
            b.imgPhoto.setPadding(dp(16), dp(16), dp(16), dp(16))
            b.imgPhoto.imageTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#8E8E93"))
        }
    }

    private fun persist() {
        val t = team ?: return
        val updated = t.copy(playersJson = Players.toJson(list))
        team = updated
        lifecycleScope.launch { (application as App).db.teams().update(updated); com.futbolpro.recorder.data.CloudSync.pushTeamAsync(this@PlayersActivity, updated) }
    }

    private fun render() {
        b.listContainer.removeAllViews()
        list.forEachIndexed { i, p ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setBackgroundResource(R.drawable.bg_card); setPadding(dp(12), dp(10), dp(12), dp(10))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
                isClickable = true
            }
            val img = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
                setBackgroundResource(R.drawable.bg_dot); backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#2C2C2E"))
                outlineProvider = ViewOutlineProvider.BACKGROUND; clipToOutline = true; scaleType = ImageView.ScaleType.CENTER_CROP
            }
            if (p.photo != null) try { img.setImageURI(Uri.parse(p.photo)) } catch (_: Exception) {}
            else { img.setImageResource(R.drawable.ic_camera); img.imageTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#636366")); img.scaleType = ImageView.ScaleType.CENTER; }
            val texts = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(14) }
            }
            texts.addView(TextView(this).apply { text = p.name; setTextColor(Color.WHITE); textSize = 16f; typeface = android.graphics.Typeface.DEFAULT_BOLD })
            texts.addView(TextView(this).apply { text = listOfNotNull(p.number.takeIf { it.isNotBlank() }?.let { "N° $it" }, p.position.takeIf { it.isNotBlank() }, p.birth.takeIf { it.isNotBlank() }).joinToString(" · ").ifBlank { "Sin datos" }; setTextColor(Color.parseColor("#8E8E93")); textSize = 12f })
            val del = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)); setPadding(dp(8), dp(8), dp(8), dp(8))
                setImageResource(R.drawable.ic_close); imageTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#FF453A"))
                setOnClickListener {
                    AlertDialog.Builder(this@PlayersActivity).setTitle("Borrar ${p.name}").setMessage("¿Seguro?")
                        .setPositiveButton("Borrar") { _, _ -> list.removeAt(i); persist(); render() }
                        .setNegativeButton("Cancelar", null).show()
                }
            }
            row.addView(img); row.addView(texts); row.addView(del)
            row.setOnClickListener { edit(i) }
            b.listContainer.addView(row)
        }
        if (list.isEmpty()) b.listContainer.addView(TextView(this).apply { text = "Aún no hay jugadores. Agrega el primero arriba."; setTextColor(Color.parseColor("#8E8E93")) })
    }

    private fun edit(i: Int) {
        val p = list[i]
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val en = EditText(this).apply { setText(p.name); hint = "Nombre" }
        val enum = EditText(this).apply { setText(p.number); hint = "Número"; inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        val epos = EditText(this).apply { setText(p.position); hint = "Posición (portero, defensa, delantero...)" }
        val ebirth = EditText(this).apply {
            setText(p.birth); hint = "Fecha de nacimiento"; isFocusable = false
            setOnClickListener {
                val c = java.util.Calendar.getInstance()
                android.app.DatePickerDialog(this@PlayersActivity, { _, y, m, d -> setText("%02d/%02d/%d".format(d, m + 1, y)) },
                    c.get(java.util.Calendar.YEAR) - 18, c.get(java.util.Calendar.MONTH), c.get(java.util.Calendar.DAY_OF_MONTH)).show()
            }
        }
        box.addView(en); box.addView(enum); box.addView(epos); box.addView(ebirth)
        AlertDialog.Builder(this).setTitle("Editar jugador").setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                p.name = en.text.toString().trim().ifBlank { p.name }; p.number = enum.text.toString().trim()
                p.position = epos.text.toString().trim(); p.birth = ebirth.text.toString().trim(); persist(); render()
            }
            .setNeutralButton("Cambiar foto") { _, _ -> editIndex = i; pickPhoto.launch("image/*") }
            .setNegativeButton("Cancelar", null).show()
    }
}
