package com.futbolpro.recorder.ui.cup

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.futbolpro.recorder.App
import com.futbolpro.recorder.data.*
import com.futbolpro.recorder.databinding.ActivityFixtureBinding
import com.futbolpro.recorder.ui.recording.RecordingActivity
import kotlinx.coroutines.launch

class FixtureActivity : AppCompatActivity() {
    private lateinit var b: ActivityFixtureBinding
    private lateinit var ui: CupUi
    private lateinit var t: Tournament
    private var f: Fixture? = null
    private var home: TeamEntity? = null
    private var away: TeamEntity? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityFixtureBinding.inflate(layoutInflater)
        setContentView(b.root)
        ui = CupUi(this)
    }

    override fun onResume() {
        super.onResume()
        t = TournamentStore.get(this)
        val id = intent.getLongExtra("fixtureId", -1L)
        f = t.fixtures.firstOrNull { it.id == id }
        lifecycleScope.launch {
            val dao = (application as App).db.teams()
            home = f?.let { dao.getById(it.homeId) }
            away = f?.let { dao.getById(it.awayId) }
            render()
        }
    }

    private fun save() { TournamentStore.save(this); render() }

    private fun render() {
        val fx = f ?: run { finish(); return }
        val box = b.fixContainer
        box.removeAllViews()
        val white = Color.WHITE
        val gray = Color.parseColor("#8FA3C8")

        box.addView(ui.tv(t.name.uppercase() + " · FECHA ${fx.round}", 12f, Color.parseColor("#7FB8FF"), true).apply { letterSpacing = 0.1f; setPadding(0, 0, 0, ui.dp(10)) })

        val card = ui.row()
        fun side(tm: TeamEntity?): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            addView(ui.badge(tm, 64)); addView(ui.tv(tm?.name ?: "?", 14f, white, true).apply { setPadding(0, ui.dp(6), 0, 0) })
        }
        card.addView(side(home))
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        mid.addView(ui.tv("${fx.homeGoals()} - ${fx.awayGoals()}", 38f, white, true))
        if (fx.hasPens()) mid.addView(ui.tv("(${fx.homePens} - ${fx.awayPens} pen.)", 13f, gray))
        mid.addView(ui.tv(if (fx.played) "JUGADO" else "PENDIENTE", 11f, if (fx.played) Color.parseColor("#4CE0A0") else Color.parseColor("#FFC94D"), true).apply { setPadding(0, ui.dp(4), 0, 0) })
        card.addView(mid)
        card.addView(side(away))
        box.addView(card)

        val admin = Auth.isAdmin(this)
        if (admin) {
        val r1 = LinearLayout(this)
        r1.addView(ui.btn("Grabar partido", null, 1f) { record(fx) })
        r1.addView(ui.btn(if (fx.played) "Reabrir" else "Marcar jugado", Color.parseColor("#2B3A63"), 1f) { fx.played = !fx.played; save() })
        box.addView(r1)
        val r2 = LinearLayout(this)
        r2.addView(ui.btn("Cambiar fecha", Color.parseColor("#2B3A63"), 1f) { input("Número de fecha", fx.round.toString()) { fx.round = it.toIntOrNull() ?: fx.round; save() } })
        r2.addView(ui.btn("Penales", Color.parseColor("#2B3A63"), 1f) { pens(fx) })
        box.addView(r2)

        }

        box.addView(ui.header("EVENTOS DEL PARTIDO"))
        val evs = fx.events.sortedBy { it.minute }
        if (evs.isEmpty()) box.addView(ui.tv("Sin goles ni tarjetas todavía.", 13f, gray, false, 0f, Gravity.START))
        evs.forEach { e ->
            val row = ui.row()
            val tm = if (e.teamId == fx.homeId) home else away
            val (label, col) = when (e.type) {
                "GOAL" -> "GOL" to Color.parseColor("#4CE0A0")
                "YELLOW" -> "AMARILLA" to Color.parseColor("#FFD54A")
                else -> "ROJA" to Color.parseColor("#FF5C5C")
            }
            row.addView(ui.tv("${e.minute}'", 13f, gray, true).apply { layoutParams = LinearLayout.LayoutParams(ui.dp(40), -2) })
            row.addView(ui.tv(label, 12f, col, true).apply { layoutParams = LinearLayout.LayoutParams(ui.dp(78), -2); gravity = Gravity.START })
            row.addView(ui.tv("${e.player.ifBlank { "Sin nombre" }} (${tm?.shortName ?: "?"})", 14f, white, false, 1f, Gravity.START))
            if (admin) {
            row.addView(ui.tv("Borrar", 12f, Color.parseColor("#FF6B6B"), true))
            row.setOnClickListener {
                AlertDialog.Builder(this).setTitle("Borrar evento").setMessage("${label} de ${e.player.ifBlank { "Sin nombre" }}")
                    .setPositiveButton("Borrar") { _, _ -> fx.events.remove(e); save() }.setNegativeButton("Cancelar", null).show()
            }
            }
            box.addView(row)
        }
        if (admin) {
        val r3 = LinearLayout(this)
        r3.addView(ui.btn("+ Gol", Color.parseColor("#1E8F63"), 1f) { addEvent(fx, "GOAL") })
        r3.addView(ui.btn("+ Amarilla", Color.parseColor("#9A7B10"), 1f) { addEvent(fx, "YELLOW") })
        r3.addView(ui.btn("+ Roja", Color.parseColor("#B23A3A"), 1f) { addEvent(fx, "RED") })
        box.addView(r3)

        box.addView(ui.spacer(18))
        box.addView(ui.btn("Eliminar partido", Color.parseColor("#5A1F2A")) {
            AlertDialog.Builder(this).setTitle("Eliminar partido").setMessage("¿Seguro?")
                .setPositiveButton("Eliminar") { _, _ -> t.fixtures.remove(fx); TournamentStore.save(this); finish() }
                .setNegativeButton("Cancelar", null).show()
        })
            }
    }

    private fun record(fx: Fixture) {
        val prefs = Prefs(this)
        val h = home; val a = away
        if (h == null || a == null) return
        startActivity(Intent(this, RecordingActivity::class.java).apply {
            putExtra("fixtureId", fx.id)
            putExtra("homeTeamId", h.id); putExtra("awayTeamId", a.id)
            putExtra("homeName", h.name); putExtra("homeShort", h.shortName); putExtra("homeBadge", h.badgeUri); putExtra("homeColor", h.primaryColor)
            putExtra("awayName", a.name); putExtra("awayShort", a.shortName); putExtra("awayBadge", a.badgeUri); putExtra("awayColor", a.primaryColor)
            putExtra("competition", t.name)
            putExtra("resolution", prefs.defaultResolution); putExtra("fps", prefs.defaultFps)
            putExtra("halfMin", prefs.defaultHalfMinutes); putExtra("aspect", "full")
        })
    }

    private fun pens(fx: Fixture) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0) }
        val eh = EditText(this).apply { hint = "Penales de ${home?.shortName ?: "local"}"; inputType = android.text.InputType.TYPE_CLASS_NUMBER; if (fx.hasPens()) setText(fx.homePens.toString()) }
        val ea = EditText(this).apply { hint = "Penales de ${away?.shortName ?: "visita"}"; inputType = android.text.InputType.TYPE_CLASS_NUMBER; if (fx.hasPens()) setText(fx.awayPens.toString()) }
        box.addView(eh); box.addView(ea)
        AlertDialog.Builder(this).setTitle("Resultado de penales").setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                val h = eh.text.toString().toIntOrNull(); val a = ea.text.toString().toIntOrNull()
                if (h != null && a != null) { fx.homePens = h; fx.awayPens = a } else { fx.homePens = -1; fx.awayPens = -1 }
                save()
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun addEvent(fx: Fixture, type: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0) }
        val names = listOf(home?.name ?: "Local", away?.name ?: "Visita")
        val sp = Spinner(this).apply { adapter = ArrayAdapter(this@FixtureActivity, android.R.layout.simple_spinner_dropdown_item, names) }
        val ep = EditText(this).apply { hint = "Jugador (opcional)"; inputType = android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS }
        val em = EditText(this).apply { hint = "Minuto"; inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        val pick = ui.btn("Elegir de la plantilla", Color.parseColor("#2B3A63")) {
            val roster = Players.names(if (sp.selectedItemPosition == 0) home else away)
            if (roster.isEmpty()) android.widget.Toast.makeText(this, "Ese equipo aún no tiene jugadores", android.widget.Toast.LENGTH_SHORT).show()
            else AlertDialog.Builder(this).setItems(roster.toTypedArray()) { _, i -> ep.setText(roster[i]) }.show()
        }
        box.addView(sp); box.addView(ep); box.addView(em); box.addView(pick)
        val title = when (type) { "GOAL" -> "Agregar gol"; "YELLOW" -> "Tarjeta amarilla"; else -> "Tarjeta roja" }
        AlertDialog.Builder(this).setTitle(title).setView(box)
            .setPositiveButton("Agregar") { _, _ ->
                val team = if (sp.selectedItemPosition == 0) fx.homeId else fx.awayId
                fx.events.add(FEvent(type, team, ep.text.toString().trim(), em.text.toString().toIntOrNull() ?: 0))
                save()
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun input(title: String, value: String, ok: (String) -> Unit) {
        val et = EditText(this).apply { setText(value); inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        val box = LinearLayout(this).apply { setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0); addView(et, LinearLayout.LayoutParams(-1, -2)) }
        AlertDialog.Builder(this).setTitle(title).setView(box).setPositiveButton("Aceptar") { _, _ -> ok(et.text.toString().trim()) }.setNegativeButton("Cancelar", null).show()
    }
}
