package com.futbolpro.recorder.data

import android.content.Context
import com.google.gson.Gson
import java.io.File

/** Evento de un partido de la copa: GOAL, YELLOW o RED. */
data class FEvent(var type: String = "GOAL", var teamId: Long = 0, var player: String = "", var minute: Int = 0)

/** Goleador cargado a mano (modo manual). */
data class ManualScorer(var player: String = "", var teamId: Long = 0, var goals: Int = 0)

data class Fixture(
    var id: Long = 0,
    var round: Int = 1,
    var homeId: Long = 0,
    var awayId: Long = 0,
    var played: Boolean = false,
    var events: MutableList<FEvent> = mutableListOf(),
    var homePens: Int = -1,
    var awayPens: Int = -1,
    var video: String? = null,
    var videoUrl: String = "",
    var date: Long = 0L,
    var walkoverWinner: Long = 0L
) {
    fun homeGoals() = events.count { it.type == "GOAL" && it.teamId == homeId }
    fun awayGoals() = events.count { it.type == "GOAL" && it.teamId == awayId }
    fun hasPens() = homePens >= 0 && awayPens >= 0
}

data class Tournament(
    var name: String = "Copa Coca-Cola",
    var teamIds: MutableList<Long> = mutableListOf(),
    var fixtures: MutableList<Fixture> = mutableListOf(),
    var winPts: Int = 3,
    var drawPts: Int = 1,
    var penRounds: Int = 3,
    var startDate: Long = 0L,
    var intervalDays: Int = 7,
    var nextId: Long = 1,
    var scorersMode: String = "auto",
    var manualScorers: MutableList<ManualScorer> = mutableListOf()
)

data class StandRow(val teamId: Long, var pj: Int = 0, var g: Int = 0, var e: Int = 0, var p: Int = 0, var gf: Int = 0, var gc: Int = 0, var pts: Int = 0) {
    val dg get() = gf - gc
}

data class ScorerRow(val player: String, val teamId: Long, val goals: Int)

object TournamentStore {
    private val gson = Gson()
    private var cache: Tournament? = null
    private fun file(ctx: Context) = File(ctx.filesDir, "copa.json")

    fun get(ctx: Context): Tournament {
        cache?.let { return it }
        val t = try {
            val f = file(ctx)
            if (f.exists()) gson.fromJson(f.readText(), Tournament::class.java) else Tournament()
        } catch (_: Exception) { Tournament() }
        cache = t
        return t
    }

    /** Guarda en el teléfono y, si eres admin y la nube está lista, publica los cambios. */
    fun save(ctx: Context) {
        saveLocal(ctx)
        CloudSync.pushCopaAsync(ctx)
    }

    fun saveLocal(ctx: Context) {
        val t = cache ?: return
        try { file(ctx).writeText(gson.toJson(t)) } catch (_: Exception) {}
    }

    fun replace(ctx: Context, t: Tournament) { cache = t; saveLocal(ctx) }

    fun reset(ctx: Context) { cache = Tournament(); save(ctx) }

    /** Tabla de posiciones: los puntos salen SOLO de los partidos marcados como jugados. */
    fun standings(t: Tournament): List<StandRow> {
        val map = LinkedHashMap<Long, StandRow>()
        t.teamIds.forEach { map[it] = StandRow(it) }
        for (f in t.fixtures) {
            if (!f.played) continue
            val h = map.getOrPut(f.homeId) { StandRow(f.homeId) }
            val a = map.getOrPut(f.awayId) { StandRow(f.awayId) }
            val hg = f.homeGoals(); val ag = f.awayGoals()
            h.pj++; a.pj++
            h.gf += hg; h.gc += ag; a.gf += ag; a.gc += hg
            when {
                hg > ag -> { h.g++; a.p++; h.pts += t.winPts }
                hg < ag -> { a.g++; h.p++; a.pts += t.winPts }
                else -> { h.e++; a.e++; h.pts += t.drawPts; a.pts += t.drawPts }
            }
        }
        return map.values.sortedWith(compareByDescending<StandRow> { it.pts }.thenByDescending { it.dg }.thenByDescending { it.gf })
    }

    fun scorers(t: Tournament): List<ScorerRow> {
        if (t.scorersMode == "manual") {
            return t.manualScorers.filter { it.goals > 0 && it.player.isNotBlank() }.map { ScorerRow(it.player, it.teamId, it.goals) }
                .sortedWith(compareByDescending<ScorerRow> { it.goals }.thenBy { it.player })
        }
        val m = HashMap<Pair<Long, String>, Int>()
        for (f in t.fixtures) for (e in f.events) {
            if (e.type != "GOAL") continue
            val n = e.player.trim()
            if (n.isEmpty() || n.equals("Sin nombre", true)) continue
            val key = e.teamId to n
            m[key] = (m[key] ?: 0) + 1
        }
        return m.map { ScorerRow(it.key.second, it.key.first, it.value) }
            .sortedWith(compareByDescending<ScorerRow> { it.goals }.thenBy { it.player })
    }

    /** Genera exactamente [total] fechas: repite el todos-contra-todos (cambiando localía) hasta llegar al número pedido. */
    fun generateRounds(t: Tournament, total: Int) {
        t.fixtures.removeAll { !it.played }
        val ids = t.teamIds.toMutableList<Long?>()
        if (ids.size < 2) return
        if (ids.size % 2 == 1) ids.add(null)
        val n = ids.size
        val per = n - 1
        val list = ids.toMutableList()
        val base = mutableListOf<List<Pair<Long, Long>>>()
        for (r in 0 until per) {
            val round = mutableListOf<Pair<Long, Long>>()
            for (i in 0 until n / 2) {
                val a = list[i]; val b = list[n - 1 - i]
                if (a != null && b != null) round.add(if ((r + i) % 2 == 0) a to b else b to a)
            }
            base.add(round)
            list.add(1, list.removeAt(n - 1))
        }
        for (k in 0 until total) {
            val cycle = k / per
            for ((h, a) in base[k % per]) {
                val pair = if (cycle % 2 == 0) h to a else a to h
                t.fixtures.add(Fixture(id = t.nextId++, round = k + 1, homeId = pair.first, awayId = pair.second))
            }
        }
        if (t.startDate > 0) t.fixtures.forEach { if (it.date == 0L) it.date = t.startDate + (it.round - 1).toLong() * t.intervalDays * 86_400_000L }
    }

    /** Agrega [extra] fechas más, siguiendo el mismo ciclo de cruces del torneo. */
    fun appendRounds(t: Tournament, extra: Int) {
        val ids = t.teamIds.toMutableList<Long?>()
        if (ids.size < 2 || extra <= 0) return
        if (ids.size % 2 == 1) ids.add(null)
        val n = ids.size
        val per = n - 1
        val list = ids.toMutableList()
        val base = mutableListOf<List<Pair<Long, Long>>>()
        for (r in 0 until per) {
            val round = mutableListOf<Pair<Long, Long>>()
            for (i in 0 until n / 2) {
                val a = list[i]; val b = list[n - 1 - i]
                if (a != null && b != null) round.add(if ((r + i) % 2 == 0) a to b else b to a)
            }
            base.add(round)
            list.add(1, list.removeAt(n - 1))
        }
        val start = t.fixtures.maxOfOrNull { it.round } ?: 0
        for (k in start until start + extra) {
            val cycle = k / per
            for ((h, a) in base[k % per]) {
                val pair = if (cycle % 2 == 0) h to a else a to h
                val f = Fixture(id = t.nextId++, round = k + 1, homeId = pair.first, awayId = pair.second)
                if (t.startDate > 0) f.date = t.startDate + k.toLong() * t.intervalDays * 86_400_000L
                t.fixtures.add(f)
            }
        }
    }

    /** Calendario todos contra todos (método del círculo). Cada cruce de ida (y vuelta si se pide). */
    fun generate(t: Tournament, doubleRound: Boolean) {
        t.fixtures.removeAll { !it.played }
        val ids = t.teamIds.toMutableList<Long?>()
        if (ids.size < 2) return
        if (ids.size % 2 == 1) ids.add(null)
        val n = ids.size
        val rounds = n - 1
        val list = ids.toMutableList()
        val pairs = mutableListOf<Triple<Int, Long, Long>>()
        for (r in 0 until rounds) {
            for (i in 0 until n / 2) {
                val a = list[i]; val b = list[n - 1 - i]
                if (a != null && b != null) pairs.add(if ((r + i) % 2 == 0) Triple(r + 1, a, b) else Triple(r + 1, b, a))
            }
            list.add(1, list.removeAt(n - 1))
        }
        if (doubleRound) pairs.toList().forEach { pairs.add(Triple(it.first + rounds, it.third, it.second)) }
        for ((r, h, a) in pairs) {
            if (t.fixtures.any { it.homeId == h && it.awayId == a }) continue
            t.fixtures.add(Fixture(id = t.nextId++, round = r, homeId = h, awayId = a))
        }
        if (t.startDate > 0) t.fixtures.forEach { if (it.date == 0L) it.date = t.startDate + (it.round - 1).toLong() * t.intervalDays * 86_400_000L }
    }
}
