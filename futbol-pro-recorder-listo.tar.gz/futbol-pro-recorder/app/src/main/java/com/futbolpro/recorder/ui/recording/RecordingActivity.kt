package com.futbolpro.recorder.ui.recording

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PorterDuff
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraEffect
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.core.UseCaseGroup
import androidx.camera.effects.OverlayEffect
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.futbolpro.recorder.App
import com.futbolpro.recorder.R
import com.futbolpro.recorder.data.MatchEntity
import com.futbolpro.recorder.data.MatchEventEntity
import com.futbolpro.recorder.data.Prefs
import com.futbolpro.recorder.databinding.ActivityRecordingBinding
import com.futbolpro.recorder.domain.MatchEvent
import com.futbolpro.recorder.domain.MatchState
import com.futbolpro.recorder.domain.Period
import com.futbolpro.recorder.domain.ScoreboardStyle
import com.futbolpro.recorder.domain.TimeFmt
import com.futbolpro.recorder.overlay.ScoreboardRenderer
import com.futbolpro.recorder.util.Sfx
import com.google.gson.Gson
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*

class RecordingActivity : AppCompatActivity() {
    private lateinit var b: ActivityRecordingBinding
    private lateinit var state: MatchState
    @Volatile private var style: ScoreboardStyle = ScoreboardStyle()
    private lateinit var renderer: ScoreboardRenderer
    private val sfx = Sfx()
    private var recording: Recording? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var overlayEffect: OverlayEffect? = null
    private val effectThread = HandlerThread("overlay").also { it.start() }
    private val effectHandler = Handler(effectThread.looper)
    @Volatile private var bufRot = 0
    private var timerJob: Job? = null
    private var recStartMs: Long = 0L
    private var recBaseMs: Long = 0L
    private var recRunning = false
    private var recPaused = false
    private var outputUriString: String? = null
    private val events = mutableListOf<MatchEvent>()
    private val gson = Gson()

    private val permsLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res[Manifest.permission.CAMERA] == true) startCamera() else Toast.makeText(this, "Permiso de cámara requerido", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityRecordingBinding.inflate(layoutInflater)
        setContentView(b.root)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val prefs = Prefs(this)
        state = MatchState(
            homeName = intent.getStringExtra("homeName") ?: "LOCAL",
            awayName = intent.getStringExtra("awayName") ?: "VISITA",
            homeShort = intent.getStringExtra("homeShort") ?: "LOC",
            awayShort = intent.getStringExtra("awayShort") ?: "VIS",
            homeBadge = intent.getStringExtra("homeBadge"),
            awayBadge = intent.getStringExtra("awayBadge"),
            homeColor = intent.getStringExtra("homeColor") ?: "#1565C0",
            awayColor = intent.getStringExtra("awayColor") ?: "#C62828",
            competition = intent.getStringExtra("competition") ?: "",
            resolution = intent.getStringExtra("resolution") ?: prefs.defaultResolution,
            fps = intent.getIntExtra("fps", prefs.defaultFps),
            halfDurationMin = intent.getIntExtra("halfMin", prefs.defaultHalfMinutes)
        )
        style = prefs.loadStyle()
        renderer = ScoreboardRenderer(this)
        renderer.setBadges(state.homeBadge, state.awayBadge)

        b.previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        b.previewView.scaleType = PreviewView.ScaleType.FIT_CENTER

        setupControls()
        updateRecUi()
        ensurePermissions()
        startUiTicker()
    }

    private fun ensurePermissions() {
        val needed = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        val missing = needed.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) startCamera() else permsLauncher.launch(missing.toTypedArray())
    }

    private fun qualityFor(res: String): Quality = when (res) {
        "4K" -> Quality.UHD
        "720p" -> Quality.HD
        else -> Quality.FHD
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            cameraProvider = providerFuture.get()
            bindUseCases()
        }, ContextCompat.getMainExecutor(this))
    }

    @Suppress("DEPRECATION")
    private fun displayRotation(): Int = windowManager.defaultDisplay.rotation

    /** Dibuja el marcador sobre el buffer de la cámara (se ve en pantalla Y queda grabado en el video). */
    private fun drawOverlay(canvas: android.graphics.Canvas, bw: Int, bh: Int) {
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        val fw = bw.toFloat()
        val fh = bh.toFloat()
        canvas.save()
        val uw: Float
        val uh: Float
        when (bufRot) {
            90 -> { canvas.translate(0f, fh); canvas.rotate(-90f); uw = fh; uh = fw }
            180 -> { canvas.translate(fw, fh); canvas.rotate(180f); uw = fw; uh = fh }
            270 -> { canvas.translate(fw, 0f); canvas.rotate(90f); uw = fh; uh = fw }
            else -> { uw = fw; uh = fh }
        }
        renderer.draw(canvas, uw, uh, state, style)
        canvas.restore()
    }

    private fun bindUseCases() {
        val provider = cameraProvider ?: return
        try {
            provider.unbindAll()
            overlayEffect?.close()
            val rotation = displayRotation()
            val quality = qualityFor(state.resolution)
            val selector = QualitySelector.from(quality, FallbackStrategy.lowerQualityOrHigherThan(quality))
            val recorder = Recorder.Builder().setQualitySelector(selector).build()
            val vc = VideoCapture.withOutput(recorder)
            vc.targetRotation = rotation
            videoCapture = vc
            val preview = Preview.Builder().build()
            preview.targetRotation = rotation
            preview.surfaceProvider = b.previewView.surfaceProvider

            val eff = OverlayEffect(
                CameraEffect.PREVIEW or CameraEffect.VIDEO_CAPTURE, 0, effectHandler
            ) { t -> Log.e("Overlay", "Error en overlay", t) }
            eff.setOnDrawListener { frame ->
                drawOverlay(frame.overlayCanvas, frame.size.width, frame.size.height)
                true
            }
            overlayEffect = eff

            val gb = UseCaseGroup.Builder().addUseCase(preview).addUseCase(vc).addEffect(eff)
            b.previewView.viewPort?.let { gb.setViewPort(it) }
            val cam = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, gb.build())
            bufRot = cam.cameraInfo.getSensorRotationDegrees(rotation)
        } catch (e: Exception) {
            Toast.makeText(this, "Error iniciando cámara: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun View.tap(action: () -> Unit) = setOnClickListener { sfx.click(); action() }

    private fun flash(text: String, color: String, ms: Long = 5000) {
        state.flashText = text
        state.flashColor = color
        state.flashUntil = System.currentTimeMillis() + ms
    }

    private fun goalFx(short: String, color: String) {
        sfx.goal()
        flash("¡GOL!  $short", color, 6000)
    }

    private fun setupControls() {
        b.tvHomeShort.text = state.homeShort
        b.tvAwayShort.text = state.awayShort
        b.cardHome.backgroundTintList = ColorStateList.valueOf(TimeFmt.parseColor(state.homeColor))
        b.cardAway.backgroundTintList = ColorStateList.valueOf(TimeFmt.parseColor(state.awayColor))
        state.homeBadge?.let { try { b.ivHomeBadge.setImageURI(Uri.parse(it)) } catch (_: Exception) {} }
        state.awayBadge?.let { try { b.ivAwayBadge.setImageURI(Uri.parse(it)) } catch (_: Exception) {} }

        b.cardHome.tap { state.homeScore++; addEvent("GOAL_HOME", state.homeShort, null); goalFx(state.homeShort, state.homeColor) }
        b.cardAway.tap { state.awayScore++; addEvent("GOAL_AWAY", state.awayShort, null); goalFx(state.awayShort, state.awayColor) }
        b.btnHomeMinus.tap { if (state.homeScore > 0) state.homeScore-- }
        b.btnAwayMinus.tap { if (state.awayScore > 0) state.awayScore-- }
        b.btnTimerToggle.tap { if (state.running) pauseMatchTimer() else startMatchTimer(); updateTimerBtn() }
        b.btnAddMin.tap { state.elapsedMs += 60_000 }
        b.btnSubMin.tap { state.elapsedMs = (state.elapsedMs - 60_000).coerceAtLeast(0) }
        b.btnPeriod.tap { nextPeriod() }
        b.btnMore.tap { showMore() }
        b.btnPanel.setOnClickListener {
            val show = b.panel.visibility != View.VISIBLE
            b.panel.visibility = if (show) View.VISIBLE else View.GONE
            b.btnPanel.setImageResource(if (show) R.drawable.ic_chevron_right else R.drawable.ic_chevron_left)
        }
        b.btnRecStart.tap { startRecording() }
        b.btnRecPause.tap { togglePauseRecording() }
        b.btnRecStop.tap { stopRecording() }
        updateTimerBtn()
    }

    private fun updateTimerBtn() {
        b.btnTimerToggle.text = if (state.running) "Pausar" else "Iniciar"
        b.btnTimerToggle.setIconResource(if (state.running) R.drawable.ic_pause else R.drawable.ic_play)
    }

    private fun nextPeriod() {
        val half = state.halfDurationMin * 60_000L
        state.period = when (state.period) {
            Period.FIRST -> Period.HALF
            Period.HALF -> Period.SECOND
            Period.SECOND -> Period.EXTRA
            Period.EXTRA -> Period.FULL
            else -> Period.FIRST
        }
        when (state.period) {
            Period.HALF, Period.FULL -> { pauseMatchTimer(); updateTimerBtn() }
            Period.SECOND -> if (state.elapsedMs < half) state.elapsedMs = half
            Period.EXTRA -> if (state.elapsedMs < 2 * half) state.elapsedMs = 2 * half
            else -> {}
        }
        state.addedMinutes = 0
        b.btnPeriod.text = "Periodo: ${state.period.label}"
        sfx.whistle()
        addEvent("PERIOD", null, state.period.label)
        flash(
            when (state.period) {
                Period.HALF -> "DESCANSO"
                Period.FULL -> "FINAL DEL PARTIDO"
                else -> "COMIENZA ${state.period.label}"
            }, "#37474F", 5000
        )
    }

    private fun saveStyle(n: ScoreboardStyle) {
        style = n
        Prefs(this).saveStyle(n)
    }

    private fun showMore() {
        val items = arrayOf(
            "Tarjeta amarilla", "Tarjeta roja", "Cambio de jugador",
            "Tiempo añadido +1", "Quitar tiempo añadido", "Reiniciar cronómetro",
            if (sfx.enabled) "Silenciar sonidos" else "Activar sonidos",
            "Estilo del marcador", "Marcador más grande", "Marcador más pequeño", "Posición del marcador"
        )
        AlertDialog.Builder(this).setTitle("Más acciones").setItems(items) { _, i ->
            when (i) {
                0 -> promptTeamPlayer("YELLOW")
                1 -> promptTeamPlayer("RED")
                2 -> promptTeamPlayer("SUB")
                3 -> { state.addedMinutes++; flash("TIEMPO AÑADIDO  +${state.addedMinutes}'", "#37474F", 4000) }
                4 -> { state.addedMinutes = 0 }
                5 -> AlertDialog.Builder(this).setTitle("Reiniciar cronómetro").setMessage("¿Seguro?")
                    .setPositiveButton("Sí") { _, _ -> state.elapsedMs = 0 }
                    .setNegativeButton("No", null).show()
                6 -> { sfx.enabled = !sfx.enabled }
                7 -> {
                    val t = com.futbolpro.recorder.domain.ScoreboardTemplates.list
                    AlertDialog.Builder(this).setTitle("Estilo del marcador")
                        .setItems(t.map { it.second }.toTypedArray()) { _, k -> saveStyle(style.copy(template = t[k].first)) }.show()
                }
                8 -> saveStyle(style.copy(scale = (style.scale + 0.15f).coerceAtMost(2.5f)))
                9 -> saveStyle(style.copy(scale = (style.scale - 0.15f).coerceAtLeast(0.5f)))
                10 -> {
                    val p = com.futbolpro.recorder.domain.ScoreboardTemplates.positions
                    AlertDialog.Builder(this).setTitle("Posición del marcador")
                        .setItems(p.map { it.second }.toTypedArray()) { _, k -> saveStyle(style.copy(pos = p[k].first)) }.show()
                }
            }
        }.show()
    }

    private fun promptTeamPlayer(type: String) {
        val teams = arrayOf(state.homeShort, state.awayShort)
        val colors = arrayOf(state.homeColor, state.awayColor)
        AlertDialog.Builder(this).setTitle("Registrar $type").setItems(teams) { _, which ->
            addEvent(type, teams[which], null)
            when (type) {
                "YELLOW" -> flash("TARJETA AMARILLA  ${teams[which]}", "#F9A825")
                "RED" -> flash("TARJETA ROJA  ${teams[which]}", "#C62828")
                else -> flash("CAMBIO  ${teams[which]}", colors[which])
            }
            sfx.whistle()
        }.show()
    }

    private fun addEvent(type: String, team: String?, player: String?, note: String? = null) {
        val minute = TimeFmt.matchMinute(state.elapsedMs, state.addedMinutes)
        events.add(MatchEvent(type, minute, team, player, note))
    }

    private fun startMatchTimer() {
        if (state.running) return
        state.running = true
        timerJob?.cancel()
        timerJob = lifecycleScope.launch {
            var last = SystemClock.elapsedRealtime()
            while (isActive && state.running) {
                delay(200)
                val now = SystemClock.elapsedRealtime()
                state.elapsedMs += (now - last)
                last = now
            }
        }
    }

    private fun pauseMatchTimer() {
        state.running = false
        timerJob?.cancel()
    }

    private fun startUiTicker() {
        lifecycleScope.launch {
            while (isActive) {
                try {
                    val stat = StatFs(filesDir.absolutePath)
                    val freeMb = stat.availableBytes / (1024 * 1024)
                    val recElapsed = if (recRunning && !recPaused) recBaseMs + (SystemClock.elapsedRealtime() - recStartMs) else recBaseMs
                    b.tvRecTime.text = if (recRunning) "REC ${TimeFmt.mmss(recElapsed)}" else "REC 00:00"
                    b.tvStorage.text = "Libre: ${freeMb} MB"
                } catch (_: Exception) {}
                delay(1000)
            }
        }
    }

    private fun startRecording() {
        val vc = videoCapture ?: return Toast.makeText(this, "Cámara no lista", Toast.LENGTH_SHORT).show()
        if (recording != null) return Toast.makeText(this, "Ya hay una grabación activa", Toast.LENGTH_SHORT).show()
        val name = "match_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/FutbolProRecorder")
            }
        }
        val out = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(values).build()
        try {
            var pending = vc.output.prepareRecording(this, out)
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                pending = pending.withAudioEnabled()
            }
            recording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
                when (event) {
                    is VideoRecordEvent.Start -> {
                        recRunning = true; recPaused = false; recBaseMs = 0; recStartMs = SystemClock.elapsedRealtime()
                    }
                    is VideoRecordEvent.Pause -> {
                        if (recRunning && !recPaused) { recBaseMs += SystemClock.elapsedRealtime() - recStartMs; recPaused = true }
                    }
                    is VideoRecordEvent.Resume -> {
                        if (recRunning && recPaused) { recStartMs = SystemClock.elapsedRealtime(); recPaused = false }
                    }
                    is VideoRecordEvent.Finalize -> {
                        if (recRunning && !recPaused) recBaseMs += SystemClock.elapsedRealtime() - recStartMs
                        recRunning = false; recPaused = false
                        if (!event.hasError()) {
                            outputUriString = event.outputResults.outputUri?.toString()
                            saveMatchToDb(recBaseMs / 1000)
                            Toast.makeText(this, "Grabación guardada", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(this, "Error en grabación (${event.error})", Toast.LENGTH_LONG).show()
                        }
                        recording = null
                        updateRecUi()
                    }
                }
                updateRecUi()
            }
            sfx.whistle()
            Toast.makeText(this, "Grabando...", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo iniciar grabación: ${e.message}", Toast.LENGTH_LONG).show()
        }
        updateRecUi()
    }

    private fun togglePauseRecording() {
        val r = recording ?: return
        try {
            if (recPaused) r.resume() else r.pause()
        } catch (e: Exception) {
            Toast.makeText(this, "Pausa/reanudar no soportado: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun stopRecording() {
        val r = recording
        if (r == null) { finish(); return }
        try { r.stop() } catch (_: Exception) {}
    }

    private fun updateRecUi() {
        val rec = recording != null
        b.btnRecStart.isEnabled = !rec
        b.btnRecStart.alpha = if (rec) 0.4f else 1f
        b.btnRecPause.isEnabled = rec
        b.btnRecPause.alpha = if (rec) 1f else 0.4f
        b.btnRecPause.setImageResource(if (recPaused) R.drawable.ic_play else R.drawable.ic_pause)
        b.btnRecStop.setImageResource(if (rec) R.drawable.ic_stop else R.drawable.ic_close)
        b.dotRec.visibility = if (recRunning && !recPaused) View.VISIBLE else View.INVISIBLE
    }

    private fun saveMatchToDb(durationSec: Long) {
        val db = (application as App).db
        val summary = mapOf(
            "events" to events,
            "final" to "${state.homeScore}-${state.awayScore}",
            "competition" to state.competition
        )
        val m = MatchEntity(
            homeTeamId = null, awayTeamId = null,
            homeName = state.homeName, awayName = state.awayName,
            homeShort = state.homeShort, awayShort = state.awayShort,
            homeBadge = state.homeBadge, awayBadge = state.awayBadge,
            homeColor = state.homeColor, awayColor = state.awayColor,
            homeScore = state.homeScore, awayScore = state.awayScore,
            durationSec = durationSec,
            videoPath = outputUriString,
            competition = state.competition,
            summaryJson = gson.toJson(summary)
        )
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val id = db.matches().insert(m)
                events.forEach { ev ->
                    db.events().insert(
                        MatchEventEntity(
                            matchId = id, type = ev.type, minute = ev.minute,
                            team = ev.team, player = ev.player, note = ev.note, timestampMs = ev.ts
                        )
                    )
                }
            } catch (_: Exception) {}
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        timerJob?.cancel()
        try { recording?.stop() } catch (_: Exception) {}
        cameraProvider?.unbindAll()
        try { overlayEffect?.close() } catch (_: Exception) {}
        effectThread.quitSafely()
        sfx.release()
    }
}
