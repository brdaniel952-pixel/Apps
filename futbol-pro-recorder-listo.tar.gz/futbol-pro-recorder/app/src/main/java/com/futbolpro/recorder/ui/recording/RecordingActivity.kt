package com.futbolpro.recorder.ui.recording

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PorterDuff
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraEffect
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.core.UseCaseGroup
import androidx.camera.effects.OverlayEffect
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.futbolpro.recorder.App
import com.futbolpro.recorder.R
import com.futbolpro.recorder.data.MatchEntity
import com.futbolpro.recorder.data.MatchEventEntity
import com.futbolpro.recorder.data.FEvent
import com.futbolpro.recorder.data.Prefs
import com.futbolpro.recorder.data.TeamEntity
import com.futbolpro.recorder.data.TournamentStore
import com.futbolpro.recorder.databinding.ActivityRecordingBinding
import com.futbolpro.recorder.domain.MatchEvent
import com.futbolpro.recorder.domain.MatchState
import com.futbolpro.recorder.domain.Period
import com.futbolpro.recorder.domain.ScoreboardStyle
import com.futbolpro.recorder.domain.TimeFmt
import com.futbolpro.recorder.overlay.ScoreboardRenderer
import com.futbolpro.recorder.util.Sfx
import com.google.gson.Gson
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*

class RecordingActivity : AppCompatActivity() {
    private lateinit var b: ActivityRecordingBinding
    private lateinit var state: MatchState
    @Volatile private var style: ScoreboardStyle = ScoreboardStyle()
    private lateinit var renderer: ScoreboardRenderer
    private val sfx = Sfx()
    private var recording: Recording? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var overlayEffect: OverlayEffect? = null
    private val effectThread = HandlerThread("overlay").also { it.start() }
    private val effectHandler = Handler(effectThread.looper)
    @Volatile private var bufRot = 0
    private var timerJob: Job? = null
    private var recStartMs: Long = 0L
    private var recBaseMs: Long = 0L
    private var recRunning = false
    private var recPaused = false
    private var outputUriString: String? = null
    private val events = mutableListOf<MatchEvent>()
    private var fixtureId: Long = -1
    private var homeTeamId: Long = -1
    private var awayTeamId: Long = -1
    private var rosterHome: List<String> = emptyList()
    private var rosterAway: List<String> = emptyList()
    private val gson = Gson()

    private val permsLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res[Manifest.permission.CAMERA] == true) startCamera() else Toast.makeText(this, "Permiso de cámara requerido", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityRecordingBinding.inflate(layoutInflater)
        setContentView(b.root)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val prefs = Prefs(this)
        state = MatchState(
            homeName = intent.getStringExtra("homeName") ?: "LOCAL",
            awayName = intent.getStringExtra("awayName") ?: "VISITA",
            homeShort = intent.getStringExtra("homeShort") ?: "LOC",
            awayShort = intent.getStringExtra("awayShort") ?: "VIS",
            homeBadge = intent.getStringExtra("homeBadge"),
            awayBadge = intent.getStringExtra("awayBadge"),
            homeColor = intent.getStringExtra("homeColor") ?: "#1565C0",
            awayColor = intent.getStringExtra("awayColor") ?: "#C62828",
            competition = intent.getStringExtra("competition") ?: "",
            resolution = intent.getStringExtra("resolution") ?: prefs.defaultResolution,
            fps = intent.getIntExtra("fps", prefs.defaultFps),
            halfDurationMin = intent.getIntExtra("halfMin", prefs.defaultHalfMinutes)
        )
        style = prefs.loadStyle()
        fixtureId = intent.getLongExtra("fixtureId", -1L)
        homeTeamId = intent.getLongExtra("homeTeamId", -1L)
        awayTeamId = intent.getLongExtra("awayTeamId", -1L)
        if (fixtureId >= 0) {
            style = style.copy(template = "cocacola")
            state.penRounds = TournamentStore.get(this).penRounds
            lifecycleScope.launch {
                val dao = (application as App).db.teams()
                rosterHome = rosterOf(dao.getById(homeTeamId))
                rosterAway = rosterOf(dao.getById(awayTeamId))
            }
        }
        renderer = ScoreboardRenderer(this)
        renderer.setBadges(state.homeBadge, state.awayBadge)

        b.previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        val aspect = intent.getStringExtra("aspect") ?: "full"
        b.previewView.scaleType = if (aspect == "full") PreviewView.ScaleType.FILL_CENTER else PreviewView.ScaleType.FIT_CENTER

        setupControls()
        updateRecUi()
        ensurePermissions()
        startUiTicker()
    }

    private fun ensurePermissions() {
        val needed = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        val missing = needed.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) startCamera() else permsLauncher.launch(missing.toTypedArray())
    }

    private fun qualityFor(res: String): Quality = when (res) {
        "4K" -> Quality.UHD
        "720p" -> Quality.HD
        else -> Quality.FHD
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            cameraProvider = providerFuture.get()
            bindUseCases()
        }, ContextCompat.getMainExecutor(this))
    }

    @Suppress("DEPRECATION")
    private fun displayRotation(): Int = windowManager.defaultDisplay.rotation

    /** Dibuja el marcador sobre el buffer de la cámara (se ve en pantalla Y queda grabado en el video). */
    private fun drawOverlay(canvas: android.graphics.Canvas, bw: Int, bh: Int) {
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        val fw = bw.toFloat()
        val fh = bh.toFloat()
        canvas.save()
        val uw: Float
        val uh: Float
        when (bufRot) {
            90 -> { canvas.translate(0f, fh); canvas.rotate(-90f); uw = fh; uh = fw }
            180 -> { canvas.translate(fw, fh); canvas.rotate(180f); uw = fw; uh = fh }
            270 -> { canvas.translate(fw, 0f); canvas.rotate(90f); uw = fh; uh = fw }
            else -> { uw = fw; uh = fh }
        }
        renderer.draw(canvas, uw, uh, state, style)
        canvas.restore()
    }

    private fun bindUseCases() {
        val provider = cameraProvider ?: return
        try {
            provider.unbindAll()
            overlayEffect?.close()
            val rotation = displayRotation()
            val quality = qualityFor(state.resolution)
            val selector = QualitySelector.from(quality, FallbackStrategy.lowerQualityOrHigherThan(quality))
            val aspectExtra = intent.getStringExtra("aspect") ?: "full"
            val recorder = Recorder.Builder().setQualitySelector(selector)
                .setAspectRatio(if (aspectExtra == "4:3") androidx.camera.core.AspectRatio.RATIO_4_3 else androidx.camera.core.AspectRatio.RATIO_16_9).build()
            val vc = VideoCapture.withOutput(recorder)
            vc.targetRotation = rotation
            videoCapture = vc
            val preview = Preview.Builder().build()
            preview.targetRotation = rotation
            preview.surfaceProvider = b.previewView.surfaceProvider

            val eff = OverlayEffect(
                CameraEffect.PREVIEW or CameraEffect.VIDEO_CAPTURE, 0, effectHandler
            ) { t -> Log.e("Overlay", "Error en overlay", t) }
            eff.setOnDrawListener { frame ->
                drawOverlay(frame.overlayCanvas, frame.size.width, frame.size.height)
                true
            }
            overlayEffect = eff

            val gb = UseCaseGroup.Builder().addUseCase(preview).addUseCase(vc).addEffect(eff)
            b.previewView.viewPort?.let { gb.setViewPort(it) }
            val cam = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, gb.build())
            bufRot = cam.cameraInfo.getSensorRotationDegrees(rotation)
        } catch (e: Exception) {
            Toast.makeText(this, "Error iniciando cámara: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun View.tap(action: () -> Unit) = setOnClickListener { sfx.click(); action() }

    private fun flash(text: String, color: String, ms: Long = 5000) {
        state.flashText = text
        state.flashColor = color
        state.flashUntil = System.currentTimeMillis() + ms
    }

    private fun goalFx(short: String, color: String) {
        sfx.goal()
        flash("¡GOL!  $short", color, 6000)
    }

    private fun setupControls() {
        b.tvHomeShort.text = state.homeShort
        b.tvAwayShort.text = state.awayShort
        b.cardHome.backgroundTintList = ColorStateList.valueOf(TimeFmt.parseColor(state.homeColor))
        b.cardAway.backgroundTintList = ColorStateList.valueOf(TimeFmt.parseColor(state.awayColor))
        state.homeBadge?.let { try { b.ivHomeBadge.setImageURI(Uri.parse(it)) } catch (_: Exception) {} }
        state.awayBadge?.let { try { b.ivAwayBadge.setImageURI(Uri.parse(it)) } catch (_: Exception) {} }

        b.cardHome.tap { onGoal(true) }
        b.cardAway.tap { onGoal(false) }
        b.btnHomeMinus.tap { undoGoal(true) }
        b.btnAwayMinus.tap { undoGoal(false) }
        b.btnPenGoal.tap { penKick(1) }
        b.btnPenMiss.tap { penKick(0) }
        b.btnPenUndo.tap { penUndo() }
        b.btnPenEnd.tap { state.penActive = false; b.penBar.visibility = View.GONE }
        b.btnTimerToggle.tap { if (state.running) pauseMatchTimer() else startMatchTimer(); updateTimerBtn() }
        b.btnAddMin.tap { state.elapsedMs += 60_000 }
        b.btnSubMin.tap { state.elapsedMs = (state.elapsedMs - 60_000).coerceAtLeast(0) }
        b.btnPeriod.tap { nextPeriod() }
        b.btnMore.tap { showMore() }
        b.btnPanel.setOnClickListener {
            val show = b.panel.visibility != View.VISIBLE
            b.panel.visibility = if (show) View.VISIBLE else View.GONE
            b.btnPanel.setImageResource(if (show) R.drawable.ic_chevron_right else R.drawable.ic_chevron_left)
        }
        b.btnRecStart.tap { startRecording() }
        b.btnRecPause.tap { togglePauseRecording() }
        b.btnRecStop.tap { stopRecording() }
        updateTimerBtn()
    }

    private fun rosterOf(t: TeamEntity?): List<String> = com.futbolpro.recorder.data.Players.names(t)

    /** Pide el nombre del jugador (si hay plantilla) y luego registra el evento. */
    private fun pickPlayer(roster: List<String>, title: String, done: (String?) -> Unit) {
        if (roster.isEmpty()) { done(null); return }
        var chosen = false
        val names = (roster + "Sin nombre").toTypedArray()
        AlertDialog.Builder(this).setTitle(title).setItems(names) { _, i ->
            chosen = true
            done(if (i < roster.size) roster[i] else null)
        }.setOnDismissListener { if (!chosen) done(null) }.show()
    }

    private fun onGoal(home: Boolean) {
        if (home) state.homeScore++ else state.awayScore++
        val short = if (home) state.homeShort else state.awayShort
        goalFx(short, if (home) state.homeColor else state.awayColor)
        val type = if (home) "GOAL_HOME" else "GOAL_AWAY"
        val roster = if (fixtureId >= 0) (if (home) rosterHome else rosterAway) else emptyList()
        pickPlayer(roster, "¿Quién anotó para $short?") { addEvent(type, short, it) }
    }

    private fun undoGoal(home: Boolean) {
        if (home && state.homeScore > 0) state.homeScore-- else if (!home && state.awayScore > 0) state.awayScore-- else return
        val i = events.indexOfLast { it.type == if (home) "GOAL_HOME" else "GOAL_AWAY" }
        if (i >= 0) events.removeAt(i)
    }

    // ---------- Tanda de penales ----------
    private fun startPenalties() {
        val opts = arrayOf("2 penales por equipo", "3 penales por equipo", "5 penales por equipo", "Otro número…")
        AlertDialog.Builder(this).setTitle("Tanda de penales").setItems(opts) { _, i ->
            when (i) {
                0 -> beginPen(2)
                1 -> beginPen(3)
                2 -> beginPen(5)
                else -> {
                    val et = android.widget.EditText(this)
                    et.inputType = android.text.InputType.TYPE_CLASS_NUMBER
                    et.hint = "Cantidad (1 a 11)"
                    AlertDialog.Builder(this).setTitle("Penales por equipo").setView(et)
                        .setPositiveButton("Empezar") { _, _ -> beginPen((et.text.toString().toIntOrNull() ?: 5).coerceIn(1, 11)) }
                        .setNegativeButton("Cancelar", null).show()
                }
            }
        }.show()
    }

    private fun beginPen(n: Int) {
        state.penRounds = n
        state.penHome.clear(); state.penAway.clear()
        state.penWinner = ""
        state.penActive = true
        b.penBar.visibility = View.VISIBLE
        sfx.whistle()
        flash("TANDA DE PENALES", "#37474F", 4000)
        updatePenTurn()
    }

    /** 1 = gana local, 2 = gana visita, 0 = sigue la tanda. */
    private fun penDecided(): Int {
        val n = state.penRounds
        val hk = state.penHome.size; val ak = state.penAway.size
        val hs = state.penHome.sum(); val aws = state.penAway.sum()
        if (hk <= n && ak <= n) {
            if (hs > aws + (n - ak)) return 1
            if (aws > hs + (n - hk)) return 2
            return 0
        }
        if (hk == ak && hs != aws) return if (hs > aws) 1 else 2
        return 0
    }

    private fun updatePenTurn() {
        val w = state.penWinner
        b.tvPenTurn.text = if (w.isNotBlank()) "Ganó $w" else "Turno: ${if (state.penHome.size <= state.penAway.size) state.homeShort else state.awayShort}"
    }

    private fun penKick(v: Int) {
        if (!state.penActive || state.penWinner.isNotBlank()) return
        if (state.penHome.size <= state.penAway.size) state.penHome.add(v) else state.penAway.add(v)
        val d = penDecided()
        if (d != 0) {
            state.penWinner = if (d == 1) state.homeShort else state.awayShort
            sfx.goal()
            flash("GANA ${state.penWinner} POR PENALES", if (d == 1) state.homeColor else state.awayColor, 8000)
        } else if (v == 1) sfx.goal()
        updatePenTurn()
    }

    private fun penUndo() {
        if (state.penWinner.isNotBlank()) state.penWinner = ""
        if (state.penAway.size < state.penHome.size) { if (state.penHome.isNotEmpty()) state.penHome.removeAt(state.penHome.size - 1) }
        else if (state.penAway.isNotEmpty()) state.penAway.removeAt(state.penAway.size - 1)
        updatePenTurn()
    }

    // ---------- Guardar resultado en la copa ----------
    private fun saveToFixture(): Boolean {
        if (fixtureId < 0) return false
        val t = TournamentStore.get(this)
        val f = t.fixtures.firstOrNull { it.id == fixtureId } ?: return false
        f.events.clear()
        fun minuteOf(m: String) = m.takeWhile { it.isDigit() }.toIntOrNull() ?: 0
        for (e in events) {
            val home = when (e.type) {
                "GOAL_HOME" -> true
                "GOAL_AWAY" -> false
                else -> e.team == state.homeShort
            }
            val type = when (e.type) { "GOAL_HOME", "GOAL_AWAY" -> "GOAL"; else -> e.type }
            if (type != "GOAL" && type != "YELLOW" && type != "RED") continue
            f.events.add(FEvent(type, if (home) f.homeId else f.awayId, e.player ?: "Sin nombre", minuteOf(e.minute)))
        }
        // El marcador manda: igualar los goles registrados con el marcador final
        fun fix(teamId: Long, goals: Int) {
            while (f.events.count { it.type == "GOAL" && it.teamId == teamId } < goals) f.events.add(FEvent("GOAL", teamId, "Sin nombre", 0))
            while (f.events.count { it.type == "GOAL" && it.teamId == teamId } > goals) {
                val i = f.events.indexOfLast { it.type == "GOAL" && it.teamId == teamId }
                f.events.removeAt(i)
            }
        }
        fix(f.homeId, state.homeScore); fix(f.awayId, state.awayScore)
        if (state.penHome.isNotEmpty() || state.penAway.isNotEmpty()) { f.homePens = state.penHome.sum(); f.awayPens = state.penAway.sum() }
        f.video = outputUriString ?: f.video
        f.played = true
        TournamentStore.save(this)
        return true
    }

    private fun updateTimerBtn() {
        b.btnTimerToggle.text = if (state.running) "Pausar" else "Iniciar"
        b.btnTimerToggle.setIconResource(if (state.running) R.drawable.ic_pause else R.drawable.ic_play)
    }

    private fun nextPeriod() {
        val half = state.halfDurationMin * 60_000L
        state.period = when (state.period) {
            Period.FIRST -> Period.HALF
            Period.HALF -> Period.SECOND
            Period.SECOND -> Period.EXTRA
            Period.EXTRA -> Period.FULL
            else -> Period.FIRST
        }
        when (state.period) {
            Period.HALF, Period.FULL -> { pauseMatchTimer(); updateTimerBtn() }
            Period.SECOND -> if (state.elapsedMs < half) state.elapsedMs = half
            Period.EXTRA -> if (state.elapsedMs < 2 * half) state.elapsedMs = 2 * half
            else -> {}
        }
        state.addedMinutes = 0
        b.btnPeriod.text = "Periodo: ${state.period.label}"
        sfx.whistle()
        addEvent("PERIOD", null, state.period.label)
        flash(
            when (state.period) {
                Period.HALF -> "DESCANSO"
                Period.FULL -> "FINAL DEL PARTIDO"
                else -> "COMIENZA ${state.period.label}"
            }, "#37474F", 5000
        )
    }

    private fun saveStyle(n: ScoreboardStyle) {
        style = n
        Prefs(this).saveStyle(n)
    }

    private fun showMore() {
        val items = arrayOf(
            "Tarjeta amarilla", "Tarjeta roja", "Cambio de jugador",
            "Tiempo añadido +1", "Quitar tiempo añadido", "Reiniciar cronómetro",
            if (sfx.enabled) "Silenciar sonidos" else "Activar sonidos",
            "Estilo del marcador", "Marcador más grande", "Marcador más pequeño", "Posición del marcador",
            "Tanda de penales"
        ) + (if (fixtureId >= 0) arrayOf("Guardar resultado en la copa") else emptyArray())
        AlertDialog.Builder(this).setTitle("Más acciones").setItems(items) { _, i ->
            when (i) {
                0 -> promptTeamPlayer("YELLOW")
                1 -> promptTeamPlayer("RED")
                2 -> promptTeamPlayer("SUB")
                3 -> { state.addedMinutes++; flash("TIEMPO AÑADIDO  +${state.addedMinutes}'", "#37474F", 4000) }
                4 -> { state.addedMinutes = 0 }
                5 -> AlertDialog.Builder(this).setTitle("Reiniciar cronómetro").setMessage("¿Seguro?")
                    .setPositiveButton("Sí") { _, _ -> state.elapsedMs = 0 }
                    .setNegativeButton("No", null).show()
                6 -> { sfx.enabled = !sfx.enabled }
                7 -> {
                    val t = com.futbolpro.recorder.domain.ScoreboardTemplates.list
                    AlertDialog.Builder(this).setTitle("Estilo del marcador")
                        .setItems(t.map { it.second }.toTypedArray()) { _, k -> saveStyle(style.copy(template = t[k].first)) }.show()
                }
                8 -> saveStyle(style.copy(scale = (style.scale + 0.15f).coerceAtMost(2.5f)))
                9 -> saveStyle(style.copy(scale = (style.scale - 0.15f).coerceAtLeast(0.5f)))
                11 -> if (saveToFixture()) Toast.makeText(this, "Resultado guardado en la copa", Toast.LENGTH_LONG).show()
                10 -> {
                    val p = com.futbolpro.recorder.domain.ScoreboardTemplates.positions
                    AlertDialog.Builder(this).setTitle("Posición del marcador")
                        .setItems(p.map { it.second }.toTypedArray()) { _, k -> saveStyle(style.copy(pos = p[k].first)) }.show()
                }
            }
        }.show()
    }

    private fun promptTeamPlayer(type: String) {
        val teams = arrayOf(state.homeShort, state.awayShort)
        val colors = arrayOf(state.homeColor, state.awayColor)
        AlertDialog.Builder(this).setTitle("Registrar $type").setItems(teams) { _, which ->
            val roster = if (fixtureId >= 0 && type != "SUB") (if (which == 0) rosterHome else rosterAway) else emptyList()
            pickPlayer(roster, "¿Quién? (${teams[which]})") { addEvent(type, teams[which], it) }
            when (type) {
                "YELLOW" -> flash("TARJETA AMARILLA  ${teams[which]}", "#F9A825")
                "RED" -> flash("TARJETA ROJA  ${teams[which]}", "#C62828")
                else -> flash("CAMBIO  ${teams[which]}", colors[which])
            }
            sfx.whistle()
        }.show()
    }

    private fun addEvent(type: String, team: String?, player: String?, note: String? = null) {
        val minute = TimeFmt.matchMinute(state.elapsedMs, state.addedMinutes)
        events.add(MatchEvent(type, minute, team, player, note))
    }

    private fun startMatchTimer() {
        if (state.running) return
        state.running = true
        timerJob?.cancel()
        timerJob = lifecycleScope.launch {
            var last = SystemClock.elapsedRealtime()
            while (isActive && state.running) {
                delay(200)
                val now = SystemClock.elapsedRealtime()
                state.elapsedMs += (now - last)
                last = now
            }
        }
    }

    private fun pauseMatchTimer() {
        state.running = false
        timerJob?.cancel()
    }

    private fun startUiTicker() {
        lifecycleScope.launch {
            while (isActive) {
                try {
                    val stat = StatFs(filesDir.absolutePath)
                    val freeMb = stat.availableBytes / (1024 * 1024)
                    val recElapsed = if (recRunning && !recPaused) recBaseMs + (SystemClock.elapsedRealtime() - recStartMs) else recBaseMs
                    b.tvRecTime.text = if (recRunning) "REC ${TimeFmt.mmss(recElapsed)}" else "REC 00:00"
                    b.tvStorage.text = "Libre: ${freeMb} MB"
                } catch (_: Exception) {}
                delay(1000)
            }
        }
    }

    private fun startRecording() {
        val vc = videoCapture ?: return Toast.makeText(this, "Cámara no lista", Toast.LENGTH_SHORT).show()
        if (recording != null) return Toast.makeText(this, "Ya hay una grabación activa", Toast.LENGTH_SHORT).show()
        val name = "match_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/FutbolProRecorder")
            }
        }
        val out = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(values).build()
        try {
            var pending = vc.output.prepareRecording(this, out)
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                pending = pending.withAudioEnabled()
            }
            recording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
                when (event) {
                    is VideoRecordEvent.Start -> {
                        recRunning = true; recPaused = false; recBaseMs = 0; recStartMs = SystemClock.elapsedRealtime()
                    }
                    is VideoRecordEvent.Pause -> {
                        if (recRunning && !recPaused) { recBaseMs += SystemClock.elapsedRealtime() - recStartMs; recPaused = true }
                    }
                    is VideoRecordEvent.Resume -> {
                        if (recRunning && recPaused) { recStartMs = SystemClock.elapsedRealtime(); recPaused = false }
                    }
                    is VideoRecordEvent.Finalize -> {
                        if (recRunning && !recPaused) recBaseMs += SystemClock.elapsedRealtime() - recStartMs
                        recRunning = false; recPaused = false
                        if (!event.hasError()) {
                            outputUriString = event.outputResults.outputUri?.toString()
                            saveMatchToDb(recBaseMs / 1000)
                            if (saveToFixture()) Toast.makeText(this, "Resultado guardado en la copa", Toast.LENGTH_LONG).show()
                            Toast.makeText(this, "Grabación guardada", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(this, "Error en grabación (${event.error})", Toast.LENGTH_LONG).show()
                        }
                        recording = null
                        updateRecUi()
                    }
                }
                updateRecUi()
            }
            sfx.whistle()
            Toast.makeText(this, "Grabando...", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo iniciar grabación: ${e.message}", Toast.LENGTH_LONG).show()
        }
        updateRecUi()
    }

    private fun togglePauseRecording() {
        val r = recording ?: return
        try {
            if (recPaused) r.resume() else r.pause()
        } catch (e: Exception) {
            Toast.makeText(this, "Pausa/reanudar no soportado: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun stopRecording() {
        val r = recording
        if (r == null) { finish(); return }
        try { r.stop() } catch (_: Exception) {}
    }

    private fun updateRecUi() {
        val rec = recording != null
        b.btnRecStart.isEnabled = !rec
        b.btnRecStart.alpha = if (rec) 0.4f else 1f
        b.btnRecPause.isEnabled = rec
        b.btnRecPause.alpha = if (rec) 1f else 0.4f
        b.btnRecPause.setImageResource(if (recPaused) R.drawable.ic_play else R.drawable.ic_pause)
        b.btnRecStop.setImageResource(if (rec) R.drawable.ic_stop else R.drawable.ic_close)
        b.dotRec.visibility = if (recRunning && !recPaused) View.VISIBLE else View.INVISIBLE
    }

    private fun saveMatchToDb(durationSec: Long) {
        val db = (application as App).db
        val summary = mapOf(
            "events" to events,
            "final" to "${state.homeScore}-${state.awayScore}",
            "competition" to state.competition
        )
        val m = MatchEntity(
            homeTeamId = null, awayTeamId = null,
            homeName = state.homeName, awayName = state.awayName,
            homeShort = state.homeShort, awayShort = state.awayShort,
            homeBadge = state.homeBadge, awayBadge = state.awayBadge,
            homeColor = state.homeColor, awayColor = state.awayColor,
            homeScore = state.homeScore, awayScore = state.awayScore,
            durationSec = durationSec,
            videoPath = outputUriString,
            competition = state.competition,
            summaryJson = gson.toJson(summary)
        )
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val id = db.matches().insert(m)
                events.forEach { ev ->
                    db.events().insert(
                        MatchEventEntity(
                            matchId = id, type = ev.type, minute = ev.minute,
                            team = ev.team, player = ev.player, note = ev.note, timestampMs = ev.ts
                        )
                    )
                }
            } catch (_: Exception) {}
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        timerJob?.cancel()
        try { recording?.stop() } catch (_: Exception) {}
        cameraProvider?.unbindAll()
        try { overlayEffect?.close() } catch (_: Exception) {}
        effectThread.quitSafely()
        sfx.release()
    }
}
