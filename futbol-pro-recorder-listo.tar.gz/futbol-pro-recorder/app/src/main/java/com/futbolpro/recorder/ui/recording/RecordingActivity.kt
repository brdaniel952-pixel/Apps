package com.futbolpro.recorder.ui.recording

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.*
import android.provider.MediaStore
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.futbolpro.recorder.App
import com.futbolpro.recorder.data.MatchEntity
import com.futbolpro.recorder.data.MatchEventEntity
import com.futbolpro.recorder.data.Prefs
import com.futbolpro.recorder.databinding.ActivityRecordingBinding
import com.futbolpro.recorder.domain.MatchEvent
import com.futbolpro.recorder.domain.MatchState
import com.futbolpro.recorder.domain.Period
import com.futbolpro.recorder.domain.TimeFmt
import com.google.gson.Gson
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*

class RecordingActivity : AppCompatActivity() {
    private lateinit var b: ActivityRecordingBinding
    private lateinit var state: MatchState
    private var recording: Recording? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var timerJob: Job? = null
    private var recStartMs: Long = 0L
    private var recBaseMs: Long = 0L
    private var recRunning = false
    private var recPaused = false
    private var outputUriString: String? = null
    private val events = mutableListOf<MatchEvent>()
    private val gson = Gson()

    private val permsLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res[Manifest.permission.CAMERA] == true) startCamera() else Toast.makeText(this, "Permiso de cámara requerido", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityRecordingBinding.inflate(layoutInflater)
        setContentView(b.root)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val prefs = Prefs(this)
        state = MatchState(
            homeName = intent.getStringExtra("homeName") ?: "LOCAL",
            awayName = intent.getStringExtra("awayName") ?: "VISITA",
            homeShort = intent.getStringExtra("homeShort") ?: "LOC",
            awayShort = intent.getStringExtra("awayShort") ?: "VIS",
            homeBadge = intent.getStringExtra("homeBadge"),
            awayBadge = intent.getStringExtra("awayBadge"),
            competition = intent.getStringExtra("competition") ?: "",
            resolution = intent.getStringExtra("resolution") ?: prefs.defaultResolution,
            fps = intent.getIntExtra("fps", prefs.defaultFps),
            halfDurationMin = intent.getIntExtra("halfMin", prefs.defaultHalfMinutes)
        )
        b.overlayView.state = state
        b.overlayView.style = prefs.loadStyle()
        b.overlayView.setBadges(state.homeBadge, state.awayBadge)

        setupControls()
        updateRecUi()
        ensurePermissions()
        startUiTicker()
    }

    private fun ensurePermissions() {
        val needed = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        val missing = needed.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) startCamera() else permsLauncher.launch(missing.toTypedArray())
    }

    private fun qualityFor(res: String): Quality = when (res) {
        "4K" -> Quality.UHD
        "720p" -> Quality.HD
        else -> Quality.FHD
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            cameraProvider = providerFuture.get()
            bindUseCases()
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindUseCases() {
        val provider = cameraProvider ?: return
        try {
            provider.unbindAll()
            val quality = qualityFor(state.resolution)
            val selector = QualitySelector.from(quality, FallbackStrategy.lowerQualityOrHigherThan(quality))
            val recorder = Recorder.Builder().setQualitySelector(selector).build()
            videoCapture = VideoCapture.withOutput(recorder)
            val preview = Preview.Builder().build().also {
                it.surfaceProvider = b.previewView.surfaceProvider
            }
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, videoCapture)
        } catch (e: Exception) {
            Toast.makeText(this, "Error iniciando cámara: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun setupControls() {
        b.btnHomePlus.setOnClickListener { state.homeScore++; addEvent("GOAL_HOME", state.homeShort, null); refreshOverlay() }
        b.btnHomeMinus.setOnClickListener { if (state.homeScore > 0) state.homeScore--; refreshOverlay() }
        b.btnAwayPlus.setOnClickListener { state.awayScore++; addEvent("GOAL_AWAY", state.awayShort, null); refreshOverlay() }
        b.btnAwayMinus.setOnClickListener { if (state.awayScore > 0) state.awayScore--; refreshOverlay() }
        b.btnTimerStart.setOnClickListener { startMatchTimer() }
        b.btnTimerPause.setOnClickListener { pauseMatchTimer() }
        b.btnTimerReset.setOnClickListener {
            AlertDialog.Builder(this).setTitle("Reiniciar cronómetro").setMessage("¿Seguro?")
                .setPositiveButton("Sí") { _, _ -> state.elapsedMs = 0; refreshOverlay() }
                .setNegativeButton("No", null).show()
        }
        b.btnAddMin.setOnClickListener { state.elapsedMs += 60_000; refreshOverlay() }
        b.btnSubMin.setOnClickListener { state.elapsedMs = (state.elapsedMs - 60_000).coerceAtLeast(0); refreshOverlay() }
        b.btnPeriod.setOnClickListener {
            state.period = when (state.period) {
                Period.FIRST -> Period.HALF
                Period.HALF -> Period.SECOND
                Period.SECOND -> Period.EXTRA
                Period.EXTRA -> Period.FULL
                else -> Period.FIRST
            }
            addEvent("PERIOD", null, state.period.label); refreshOverlay()
        }
        b.btnYellow.setOnClickListener { promptTeamPlayer("YELLOW") }
        b.btnRed.setOnClickListener { promptTeamPlayer("RED") }
        b.btnSub.setOnClickListener { promptTeamPlayer("SUB") }
        b.btnRecStart.setOnClickListener { startRecording() }
        b.btnRecPause.setOnClickListener { togglePauseRecording() }
        b.btnRecStop.setOnClickListener { stopRecording() }
    }

    private fun promptTeamPlayer(type: String) {
        val teams = arrayOf(state.homeShort, state.awayShort)
        AlertDialog.Builder(this).setTitle("Registrar $type").setItems(teams) { _, which ->
            addEvent(type, teams[which], null)
            Toast.makeText(this, "$type registrada", Toast.LENGTH_SHORT).show()
        }.show()
    }

    private fun addEvent(type: String, team: String?, player: String?, note: String? = null) {
        val minute = TimeFmt.matchMinute(state.elapsedMs, state.addedMinutes)
        events.add(MatchEvent(type, minute, team, player, note))
    }

    private fun refreshOverlay() {
        b.overlayView.state = state
        b.overlayView.invalidate()
    }

    private fun startMatchTimer() {
        if (state.running) return
        state.running = true
        timerJob?.cancel()
        timerJob = lifecycleScope.launch {
            var last = SystemClock.elapsedRealtime()
            while (isActive && state.running) {
                delay(200)
                val now = SystemClock.elapsedRealtime()
                state.elapsedMs += (now - last)
                last = now
                refreshOverlay()
            }
        }
    }

    private fun pauseMatchTimer() {
        state.running = false
        timerJob?.cancel()
        refreshOverlay()
    }

    private fun startUiTicker() {
        lifecycleScope.launch {
            while (isActive) {
                try {
                    val stat = StatFs(filesDir.absolutePath)
                    val freeMb = stat.availableBytes / (1024 * 1024)
                    val recElapsed = if (recRunning && !recPaused) recBaseMs + (SystemClock.elapsedRealtime() - recStartMs) else recBaseMs
                    b.tvRecTime.text = if (recRunning) "REC ${TimeFmt.mmss(recElapsed)}" else "REC 00:00"
                    b.tvStorage.text = "Libre: ${freeMb} MB"
                } catch (_: Exception) {}
                delay(1000)
            }
        }
    }

    private fun startRecording() {
        val vc = videoCapture ?: return Toast.makeText(this, "Cámara no lista", Toast.LENGTH_SHORT).show()
        if (recording != null) return Toast.makeText(this, "Ya hay una grabación activa", Toast.LENGTH_SHORT).show()
        val name = "match_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/FutbolProRecorder")
            }
        }
        val out = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(values).build()
        try {
            var pending = vc.output.prepareRecording(this, out)
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                pending = pending.withAudioEnabled()
            }
            recording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
                when (event) {
                    is VideoRecordEvent.Start -> {
                        recRunning = true; recPaused = false; recBaseMs = 0; recStartMs = SystemClock.elapsedRealtime()
                    }
                    is VideoRecordEvent.Pause -> {
                        if (recRunning && !recPaused) { recBaseMs += SystemClock.elapsedRealtime() - recStartMs; recPaused = true }
                    }
                    is VideoRecordEvent.Resume -> {
                        if (recRunning && recPaused) { recStartMs = SystemClock.elapsedRealtime(); recPaused = false }
                    }
                    is VideoRecordEvent.Finalize -> {
                        if (recRunning && !recPaused) recBaseMs += SystemClock.elapsedRealtime() - recStartMs
                        recRunning = false; recPaused = false
                        if (!event.hasError()) {
                            outputUriString = event.outputResults.outputUri?.toString()
                            saveMatchToDb(recBaseMs / 1000)
                            Toast.makeText(this, "Grabación guardada", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(this, "Error en grabación (${event.error})", Toast.LENGTH_LONG).show()
                        }
                        recording = null
                        updateRecUi()
                    }
                }
                updateRecUi()
            }
            Toast.makeText(this, "Grabando...", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo iniciar grabación: ${e.message}", Toast.LENGTH_LONG).show()
        }
        updateRecUi()
    }

    private fun togglePauseRecording() {
        val r = recording ?: return
        try {
            if (recPaused) { r.resume(); b.btnRecPause.text = "Pausar grabación" }
            else { r.pause(); b.btnRecPause.text = "Reanudar grabación" }
        } catch (e: Exception) {
            Toast.makeText(this, "Pausa/reanudar no soportado: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun stopRecording() {
        val r = recording
        if (r == null) { finish(); return }
        try { r.stop() } catch (_: Exception) {}
    }

    private fun updateRecUi() {
        b.btnRecStart.isEnabled = recording == null
        b.btnRecPause.isEnabled = recording != null
        b.btnRecStop.text = if (recording != null) "Finalizar" else "Salir"
        if (!recPaused) b.btnRecPause.text = "Pausar grabación"
    }

    private fun saveMatchToDb(durationSec: Long) {
        val db = (application as App).db
        val summary = mapOf(
            "events" to events,
            "final" to "${state.homeScore}-${state.awayScore}",
            "competition" to state.competition
        )
        val m = MatchEntity(
            homeTeamId = null, awayTeamId = null,
            homeName = state.homeName, awayName = state.awayName,
            homeShort = state.homeShort, awayShort = state.awayShort,
            homeBadge = state.homeBadge, awayBadge = state.awayBadge,
            homeColor = state.homeColor, awayColor = state.awayColor,
            homeScore = state.homeScore, awayScore = state.awayScore,
            durationSec = durationSec,
            videoPath = outputUriString,
            competition = state.competition,
            summaryJson = gson.toJson(summary)
        )
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val id = db.matches().insert(m)
                events.forEach { ev ->
                    db.events().insert(
                        MatchEventEntity(
                            matchId = id, type = ev.type, minute = ev.minute,
                            team = ev.team, player = ev.player, note = ev.note, timestampMs = ev.ts
                        )
                    )
                }
            } catch (_: Exception) {}
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        timerJob?.cancel()
        try { recording?.stop() } catch (_: Exception) {}
        cameraProvider?.unbindAll()
    }
}
