package com.futbolpro.recorder.ui.recording

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PorterDuff
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraEffect
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.core.UseCaseGroup
import androidx.camera.effects.OverlayEffect
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.futbolpro.recorder.App
import com.futbolpro.recorder.R
import com.futbolpro.recorder.data.MatchEntity
import com.futbolpro.recorder.data.MatchEventEntity
import com.futbolpro.recorder.data.FEvent
import com.futbolpro.recorder.data.Prefs
import com.futbolpro.recorder.data.TeamEntity
import com.futbolpro.recorder.data.TournamentStore
import com.futbolpro.recorder.databinding.ActivityRecordingBinding
import com.futbolpro.recorder.domain.MatchEvent
import com.futbolpro.recorder.domain.MatchState
import com.futbolpro.recorder.domain.Period
import com.futbolpro.recorder.domain.ScoreboardStyle
import com.futbolpro.recorder.domain.TimeFmt
import com.futbolpro.recorder.overlay.ScoreboardRenderer
import com.futbolpro.recorder.util.Sfx
import com.google.gson.Gson
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*

class RecordingActivity : AppCompatActivity() {
    private lateinit var b: ActivityRecordingBinding
    private lateinit var state: MatchState
    @Volatile private var style: ScoreboardStyle = ScoreboardStyle()
    private lateinit var renderer: ScoreboardRenderer
    private lateinit var sfx: Sfx
    private val bgScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val segments = mutableListOf<String>()
    private var recPrev = 0L
    private var varRestart = false
    private var varPlayer: android.media.MediaPlayer? = null
    private var varSpeed = 1f
    private var varPos = 0
    private var varVideoW = 0
    private var varVideoH = 0
    private var varSurfaceReady = false
    private var pendingVarUri: String? = null
    private val varHandler = Handler(Looper.getMainLooper())
    private var varTick: Runnable? = null
    private var preAlarmFired = false
    private var endAlarmFired = false
    private var addedMs = 0L
    private var alarmDialog: AlertDialog? = null
    private var recording: Recording? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var overlayEffect: OverlayEffect? = null
    private val effectThread = HandlerThread("overlay").also { it.start() }
    private val effectHandler = Handler(effectThread.looper)
    @Volatile private var bufRot = 0
    @Volatile private var vpAspect = 0f
    private var camera: androidx.camera.core.Camera? = null
    private var torchOn = false
    private var timerJob: Job? = null
    private var recStartMs: Long = 0L
    private var recBaseMs: Long = 0L
    private var recRunning = false
    private var recPaused = false
    private var outputUriString: String? = null
    private val events = mutableListOf<MatchEvent>()
    private var fixtureId: Long = -1
    private var homeTeamId: Long = -1
    private var awayTeamId: Long = -1
    private var rosterHome: List<String> = emptyList()
    private var rosterAway: List<String> = emptyList()
    private val gson = Gson()

    private val permsLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res[Manifest.permission.CAMERA] == true) startCamera() else Toast.makeText(this, "Permiso de cámara requerido", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityRecordingBinding.inflate(layoutInflater)
        setContentView(b.root)
        sfx = Sfx(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val prefs = Prefs(this)
        state = MatchState(
            homeName = intent.getStringExtra("homeName") ?: "LOCAL",
            awayName = intent.getStringExtra("awayName") ?: "VISITA",
            homeShort = intent.getStringExtra("homeShort") ?: "LOC",
            awayShort = intent.getStringExtra("awayShort") ?: "VIS",
            homeBadge = intent.getStringExtra("homeBadge"),
            awayBadge = intent.getStringExtra("awayBadge"),
            homeColor = intent.getStringExtra("homeColor") ?: "#1565C0",
            awayColor = intent.getStringExtra("awayColor") ?: "#C62828",
            competition = intent.getStringExtra("competition") ?: "",
            resolution = intent.getStringExtra("resolution") ?: prefs.defaultResolution,
            fps = intent.getIntExtra("fps", prefs.defaultFps),
            halfDurationMin = intent.getIntExtra("halfMin", prefs.defaultHalfMinutes)
        )
        style = prefs.loadStyle()
        fixtureId = intent.getLongExtra("fixtureId", -1L)
        homeTeamId = intent.getLongExtra("homeTeamId", -1L)
        awayTeamId = intent.getLongExtra("awayTeamId", -1L)
        if (fixtureId >= 0) {
            style = style.copy(template = "cocacola")
            state.penRounds = TournamentStore.get(this).penRounds
            lifecycleScope.launch {
                val dao = (application as App).db.teams()
                rosterHome = rosterOf(dao.getById(homeTeamId))
                rosterAway = rosterOf(dao.getById(awayTeamId))
            }
        }
        renderer = ScoreboardRenderer(this)
        renderer.setBadges(state.homeBadge, state.awayBadge)

        b.previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        val aspect = intent.getStringExtra("aspect") ?: "full"
        b.previewView.scaleType = if (aspect == "full") PreviewView.ScaleType.FILL_CENTER else PreviewView.ScaleType.FIT_CENTER

        setupControls()
        updateRecUi()
        ensurePermissions()
        startUiTicker()
    }

    private fun ensurePermissions() {
        val needed = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        val missing = needed.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) startCamera() else permsLauncher.launch(missing.toTypedArray())
    }

    private fun qualityFor(res: String): Quality = when (res) {
        "4K" -> Quality.UHD
        "720p" -> Quality.HD
        else -> Quality.FHD
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            cameraProvider = providerFuture.get()
            bindUseCases()
        }, ContextCompat.getMainExecutor(this))
    }

    @Suppress("DEPRECATION")
    private fun displayRotation(): Int = windowManager.defaultDisplay.rotation

    /** Dibuja el marcador sobre el buffer de la cámara (se ve en pantalla Y queda grabado en el video). */
    private fun drawOverlay(canvas: android.graphics.Canvas, bw: Int, bh: Int) {
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        val fw = bw.toFloat()
        val fh = bh.toFloat()
        canvas.save()
        val uw: Float
        val uh: Float
        when (bufRot) {
            90 -> { canvas.translate(0f, fh); canvas.rotate(-90f); uw = fh; uh = fw }
            180 -> { canvas.translate(fw, fh); canvas.rotate(180f); uw = fw; uh = fh }
            270 -> { canvas.translate(fw, 0f); canvas.rotate(90f); uw = fh; uh = fw }
            else -> { uw = fw; uh = fh }
        }
        // En "pantalla completa" el video se recorta (arriba/abajo) y el marcador debe dibujarse dentro de la parte visible
        var ox = 0f; var oy = 0f; var dw = uw; var dh = uh
        val va = vpAspect
        if (va > 0f) {
            val ba = uw / uh
            if (va > ba) { dh = uw / va; oy = (uh - dh) / 2f } else if (va < ba) { dw = uh * va; ox = (uw - dw) / 2f }
        }
        try {
            canvas.translate(ox, oy)
            renderer.draw(canvas, dw, dh, state, style)
        } catch (e: Exception) { Log.e("Overlay", "Error dibujando marcador", e) }
        canvas.restore()
    }

    private fun bindUseCases() {
        val provider = cameraProvider ?: return
        try {
            provider.unbindAll()
            overlayEffect?.close()
            val rotation = displayRotation()
            val quality = qualityFor(state.resolution)
            val selector = QualitySelector.from(quality, FallbackStrategy.lowerQualityOrHigherThan(quality))
            val aspectExtra = intent.getStringExtra("aspect") ?: "full"
            val dm = resources.displayMetrics
            val pw = b.previewView.width; val ph = b.previewView.height
            vpAspect = if (aspectExtra != "full") 0f
                else if (pw > 0 && ph > 0) maxOf(pw, ph).toFloat() / minOf(pw, ph)
                else maxOf(dm.widthPixels, dm.heightPixels).toFloat() / minOf(dm.widthPixels, dm.heightPixels)
            val recorder = Recorder.Builder().setQualitySelector(selector)
                .setAspectRatio(if (aspectExtra == "4:3") androidx.camera.core.AspectRatio.RATIO_4_3 else androidx.camera.core.AspectRatio.RATIO_16_9).build()
            val vc = VideoCapture.withOutput(recorder)
            vc.targetRotation = rotation
            videoCapture = vc
            val preview = Preview.Builder().build()
            preview.targetRotation = rotation
            preview.surfaceProvider = b.previewView.surfaceProvider

            val eff = OverlayEffect(
                CameraEffect.PREVIEW or CameraEffect.VIDEO_CAPTURE, 0, effectHandler
            ) { t -> Log.e("Overlay", "Error en overlay", t) }
            eff.setOnDrawListener { frame ->
                drawOverlay(frame.overlayCanvas, frame.size.width, frame.size.height)
                true
            }
            overlayEffect = eff

            val gb = UseCaseGroup.Builder().addUseCase(preview).addUseCase(vc).addEffect(eff)
            b.previewView.viewPort?.let { gb.setViewPort(it) }
            val cam = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, gb.build())
            bufRot = cam.cameraInfo.getSensorRotationDegrees(rotation)
            camera = cam
            b.btnTorch.visibility = if (cam.cameraInfo.hasFlashUnit()) View.VISIBLE else View.GONE
            if (torchOn) cam.cameraControl.enableTorch(true)
        } catch (e: Exception) {
            Toast.makeText(this, "Error iniciando cámara: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun View.tap(action: () -> Unit) = setOnClickListener { sfx.click(); action() }

    private fun flash(text: String, color: String, ms: Long = 5000, icon: String = "") {
        state.flashText = text
        state.flashColor = color
        state.flashIcon = icon
        state.flashStart = System.currentTimeMillis()
        state.flashUntil = state.flashStart + ms
    }

    private fun goalFx(short: String, color: String) {
        sfx.goal()
        flash("¡GOL!  $short", color, 6000, "goal")
    }

    private fun setupControls() {
        b.tvHomeShort.text = state.homeShort
        b.tvAwayShort.text = state.awayShort
        b.cardHome.backgroundTintList = ColorStateList.valueOf(TimeFmt.parseColor(state.homeColor))
        b.cardAway.backgroundTintList = ColorStateList.valueOf(TimeFmt.parseColor(state.awayColor))
        state.homeBadge?.let { try { b.ivHomeBadge.setImageURI(Uri.parse(it)) } catch (_: Exception) {} }
        state.awayBadge?.let { try { b.ivAwayBadge.setImageURI(Uri.parse(it)) } catch (_: Exception) {} }

        b.cardHome.tap { onGoal(true) }
        b.cardAway.tap { onGoal(false) }
        b.btnHomeMinus.tap { undoGoal(true) }
        b.btnAwayMinus.tap { undoGoal(false) }
        b.btnPenGoal.tap { penKick(1) }
        b.btnPenMiss.tap { penKick(0) }
        b.btnPenUndo.tap { penUndo() }
        b.btnPenEnd.tap { state.penActive = false; b.penBar.visibility = View.GONE }
        b.btnTimerToggle.tap { if (state.running) pauseMatchTimer() else startMatchTimer(); updateTimerBtn() }
        b.btnAddMin.tap { state.elapsedMs += 60_000 }
        b.btnSubMin.tap { state.elapsedMs = (state.elapsedMs - 60_000).coerceAtLeast(0) }
        b.btnPeriod.tap { nextPeriod() }
        b.btnMore.tap { showMore() }
        b.btnPenalties.tap { startPenalties() }
        b.btnVar.tap { openVar() }
        setupVar()
        b.btnPanel.setOnClickListener {
            val show = b.panel.visibility != View.VISIBLE
            b.panel.visibility = if (show) View.VISIBLE else View.GONE
            b.btnPanel.setImageResource(if (show) R.drawable.ic_chevron_right else R.drawable.ic_chevron_left)
        }
        b.btnTorch.setOnClickListener {
            torchOn = !torchOn
            camera?.cameraControl?.enableTorch(torchOn)
            b.btnTorch.imageTintList = android.content.res.ColorStateList.valueOf(if (torchOn) Color.parseColor("#FFD60A") else Color.WHITE)
            sfx.click()
        }
        b.btnRecStart.tap { startRecording() }
        b.btnRecPause.tap { togglePauseRecording() }
        b.btnRecStop.tap { stopRecording() }
        updateTimerBtn()
    }

    private fun rosterOf(t: TeamEntity?): List<String> = com.futbolpro.recorder.data.Players.names(t)

    /** Pide el nombre del jugador (si hay plantilla) y luego registra el evento. */
    private fun pickPlayer(roster: List<String>, title: String, done: (String?) -> Unit) {
        if (roster.isEmpty()) { done(null); return }
        var chosen = false
        val names = (roster + "Sin nombre").toTypedArray()
        AlertDialog.Builder(this).setTitle(title).setItems(names) { _, i ->
            chosen = true
            done(if (i < roster.size) roster[i] else null)
        }.setOnDismissListener { if (!chosen) done(null) }.show()
    }

    private fun onGoal(home: Boolean) {
        if (home) state.homeScore++ else state.awayScore++
        val short = if (home) state.homeShort else state.awayShort
        goalFx(short, if (home) state.homeColor else state.awayColor)
        val type = if (home) "GOAL_HOME" else "GOAL_AWAY"
        val roster = if (fixtureId >= 0) (if (home) rosterHome else rosterAway) else emptyList()
        pickPlayer(roster, "¿Quién anotó para $short?") { addEvent(type, short, it) }
    }

    private fun undoGoal(home: Boolean) {
        if (home && state.homeScore > 0) state.homeScore-- else if (!home && state.awayScore > 0) state.awayScore-- else return
        val i = events.indexOfLast { it.type == if (home) "GOAL_HOME" else "GOAL_AWAY" }
        if (i >= 0) events.removeAt(i)
    }

    // ---------- Tanda de penales ----------
    private fun startPenalties() {
        val opts = arrayOf("2 penales por equipo", "3 penales por equipo", "5 penales por equipo", "Otro número…")
        AlertDialog.Builder(this).setTitle("Tanda de penales").setItems(opts) { _, i ->
            when (i) {
                0 -> beginPen(2)
                1 -> beginPen(3)
                2 -> beginPen(5)
                else -> {
                    val et = android.widget.EditText(this)
                    et.inputType = android.text.InputType.TYPE_CLASS_NUMBER
                    et.hint = "Cantidad (1 a 11)"
                    AlertDialog.Builder(this).setTitle("Penales por equipo").setView(et)
                        .setPositiveButton("Empezar") { _, _ -> beginPen((et.text.toString().toIntOrNull() ?: 5).coerceIn(1, 11)) }
                        .setNegativeButton("Cancelar", null).show()
                }
            }
        }.show()
    }

    private fun beginPen(n: Int) {
        state.penRounds = n
        state.penHome.clear(); state.penAway.clear()
        state.penWinner = ""
        state.penActive = true
        b.penBar.visibility = View.VISIBLE
        sfx.whistle()
        flash("TANDA DE PENALES", "#37474F", 4000, "pen")
        updatePenTurn()
    }

    /** 1 = gana local, 2 = gana visita, 0 = sigue la tanda. */
    private fun penDecided(): Int {
        val n = state.penRounds
        val hk = state.penHome.size; val ak = state.penAway.size
        val hs = state.penHome.sum(); val aws = state.penAway.sum()
        if (hk <= n && ak <= n) {
            if (hs > aws + (n - ak)) return 1
            if (aws > hs + (n - hk)) return 2
            return 0
        }
        if (hk == ak && hs != aws) return if (hs > aws) 1 else 2
        return 0
    }

    private fun updatePenTurn() {
        val w = state.penWinner
        b.tvPenTurn.text = if (w.isNotBlank()) "Ganó $w" else "Turno: ${if (state.penHome.size <= state.penAway.size) state.homeShort else state.awayShort}"
    }

    private fun penKick(v: Int) {
        if (!state.penActive || state.penWinner.isNotBlank()) return
        if (state.penHome.size <= state.penAway.size) state.penHome.add(v) else state.penAway.add(v)
        val d = penDecided()
        if (d != 0) {
            state.penWinner = if (d == 1) state.homeShort else state.awayShort
            sfx.goal()
            flash("GANA ${state.penWinner} POR PENALES", if (d == 1) state.homeColor else state.awayColor, 8000, "pen")
        } else if (v == 1) sfx.penGoal() else sfx.penMiss()
        updatePenTurn()
    }

    private fun penUndo() {
        if (state.penWinner.isNotBlank()) state.penWinner = ""
        if (state.penAway.size < state.penHome.size) { if (state.penHome.isNotEmpty()) state.penHome.removeAt(state.penHome.size - 1) }
        else if (state.penAway.isNotEmpty()) state.penAway.removeAt(state.penAway.size - 1)
        updatePenTurn()
    }

    // ---------- Guardar resultado en la copa ----------
    private fun saveToFixture(): Boolean {
        if (fixtureId < 0) return false
        val t = TournamentStore.get(this)
        val f = t.fixtures.firstOrNull { it.id == fixtureId } ?: return false
        f.events.clear()
        fun minuteOf(m: String) = m.takeWhile { it.isDigit() }.toIntOrNull() ?: 0
        for (e in events) {
            val home = when (e.type) {
                "GOAL_HOME" -> true
                "GOAL_AWAY" -> false
                else -> e.team == state.homeShort
            }
            val type = when (e.type) { "GOAL_HOME", "GOAL_AWAY" -> "GOAL"; else -> e.type }
            if (type != "GOAL" && type != "YELLOW" && type != "RED") continue
            f.events.add(FEvent(type, if (home) f.homeId else f.awayId, e.player ?: "Sin nombre", minuteOf(e.minute)))
        }
        // El marcador manda: igualar los goles registrados con el marcador final
        fun fix(teamId: Long, goals: Int) {
            while (f.events.count { it.type == "GOAL" && it.teamId == teamId } < goals) f.events.add(FEvent("GOAL", teamId, "Sin nombre", 0))
            while (f.events.count { it.type == "GOAL" && it.teamId == teamId } > goals) {
                val i = f.events.indexOfLast { it.type == "GOAL" && it.teamId == teamId }
                f.events.removeAt(i)
            }
        }
        fix(f.homeId, state.homeScore); fix(f.awayId, state.awayScore)
        if (state.penHome.isNotEmpty() || state.penAway.isNotEmpty()) { f.homePens = state.penHome.sum(); f.awayPens = state.penAway.sum() }
        f.video = outputUriString ?: f.video
        f.played = true
        TournamentStore.save(this)
        return true
    }


    // ---------- Alarmas del tiempo reglamentario ----------
    private fun periodTargetMs(): Long {
        val half = state.halfDurationMin * 60_000L
        return when (state.period) { Period.FIRST -> half + addedMs; Period.SECOND -> 2 * half + addedMs; else -> -1L }
    }

    private fun checkPeriodAlarms() {
        val target = periodTargetMs()
        if (target <= 0L) return
        val remaining = target - state.elapsedMs
        if (remaining > 20_000L) { preAlarmFired = false; endAlarmFired = false; return }
        if (!preAlarmFired && remaining in 1..20_000L) { preAlarmFired = true; onPreAlarm() }
        if (!endAlarmFired && remaining <= 0L) { endAlarmFired = true; onEndAlarm() }
    }

    private fun onPreAlarm() {
        sfx.chime(); sfx.vibrate(longArrayOf(0, 300, 150, 300))
        flash("QUEDAN 20 SEGUNDOS", "#B26A00", 5000, "time")
        showAddTime("Quedan 20 segundos. ¿Agregar tiempo?")
    }

    private fun showAddTime(title: String) {
        alarmDialog?.dismiss()
        val mins = intArrayOf(1, 2, 3, 5, 10, 15)
        val labels = mins.map { "+$it min" }.toTypedArray() + "No agregar"
        alarmDialog = AlertDialog.Builder(this).setTitle(title).setItems(labels) { _, i -> if (i < mins.size) addTime(mins[i]) }.show()
    }

    private fun addTime(m: Int) {
        addedMs += m * 60_000L
        state.addedMinutes += m
        preAlarmFired = false; endAlarmFired = false
        flash("TIEMPO AÑADIDO  +${state.addedMinutes}'", "#37474F", 4000, "time")
        sfx.chime()
        try { recording?.resume() } catch (_: Exception) {}
        if (!state.running) { startMatchTimer(); updateTimerBtn() }
    }

    private fun onEndAlarm() {
        alarmDialog?.dismiss()
        pauseMatchTimer(); updateTimerBtn()
        try { recording?.pause() } catch (_: Exception) {}
        sfx.alarmStart(10)
        val first = state.period == Period.FIRST
        flash(if (first) "FIN DEL PRIMER TIEMPO" else "FIN DEL TIEMPO", "#B71C1C", 8000, "whistle")
        alarmDialog = AlertDialog.Builder(this)
            .setTitle(if (first) "Terminó el primer tiempo" else "Terminó el segundo tiempo")
            .setMessage("El cronómetro y la grabación están en pausa.")
            .setPositiveButton(if (first) "Ir al descanso" else "Terminar partido") { _, _ -> sfx.alarmStop(); if (first) nextPeriod() else finishRegulation() }
            .setNeutralButton("Agregar tiempo") { _, _ -> sfx.alarmStop(); showAddTime("¿Cuánto tiempo agregas?") }
            .setNegativeButton("Silenciar") { _, _ -> sfx.alarmStop() }
            .show()
    }

    private fun finishRegulation() {
        state.period = Period.FULL
        pauseMatchTimer(); updateTimerBtn()
        b.btnPeriod.text = "Periodo: ${state.period.label}"
        sfx.whistle()
        addEvent("PERIOD", null, state.period.label)
        flash("FINAL DEL PARTIDO", "#37474F", 5000, "whistle")
    }

    // ---------- Guardado final (une las partes si se usó el VAR) ----------
    private fun finishRecording() {
        val parts = segments.toList()
        val totalSec = recPrev / 1000
        if (parts.size > 1) Toast.makeText(this, "Uniendo las partes del video...", Toast.LENGTH_LONG).show()
        bgScope.launch {
            val merged = if (parts.size > 1) mergeSegments(parts) else parts.firstOrNull()
            outputUriString = merged ?: parts.firstOrNull()
            saveMatchToDb(totalSec)
            val saved = saveToFixture()
            runOnUiThread {
                if (parts.size > 1 && merged == null) Toast.makeText(this@RecordingActivity, "No se pudieron unir las partes: quedaron ${parts.size} videos en la galería", Toast.LENGTH_LONG).show()
                if (saved) Toast.makeText(this@RecordingActivity, "Resultado guardado en la copa", Toast.LENGTH_LONG).show()
                Toast.makeText(this@RecordingActivity, "Grabación guardada", Toast.LENGTH_SHORT).show()
            }
            segments.clear(); recPrev = 0L
        }
    }

    private fun mergeSegments(parts: List<String>): String? {
        var muxer: android.media.MediaMuxer? = null
        var pfd: android.os.ParcelFileDescriptor? = null
        var outUri: Uri? = null
        try {
            val name = "match_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}_completo"
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/FutbolProRecorder")
            }
            outUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
            pfd = contentResolver.openFileDescriptor(outUri, "rw") ?: return null
            muxer = android.media.MediaMuxer(pfd.fileDescriptor, android.media.MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val first = android.media.MediaExtractor()
            first.setDataSource(this, Uri.parse(parts[0]), null)
            var vFmt: android.media.MediaFormat? = null
            var aFmt: android.media.MediaFormat? = null
            for (i in 0 until first.trackCount) {
                val f = first.getTrackFormat(i)
                val mime = f.getString(android.media.MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") && vFmt == null) vFmt = f else if (mime.startsWith("audio/") && aFmt == null) aFmt = f
            }
            first.release()
            val vf = vFmt ?: return null
            if (vf.containsKey(android.media.MediaFormat.KEY_ROTATION)) muxer.setOrientationHint(vf.getInteger(android.media.MediaFormat.KEY_ROTATION))
            val vOut = muxer.addTrack(vf)
            val aOut = if (aFmt != null) muxer.addTrack(aFmt) else -1
            muxer.start()
            val buf = java.nio.ByteBuffer.allocate(4 * 1024 * 1024)
            val info = android.media.MediaCodec.BufferInfo()
            var offsetUs = 0L
            for (p in parts) {
                val ex = android.media.MediaExtractor()
                ex.setDataSource(this, Uri.parse(p), null)
                var vi = -1
                var ai = -1
                for (i in 0 until ex.trackCount) {
                    val mime = ex.getTrackFormat(i).getString(android.media.MediaFormat.KEY_MIME) ?: continue
                    if (mime.startsWith("video/") && vi < 0) vi = i else if (mime.startsWith("audio/") && ai < 0 && aOut >= 0) ai = i
                }
                if (vi >= 0) ex.selectTrack(vi)
                if (ai >= 0) ex.selectTrack(ai)
                var maxUs = 0L
                while (true) {
                    info.offset = 0
                    info.size = ex.readSampleData(buf, 0)
                    if (info.size < 0) break
                    val ti = ex.sampleTrackIndex
                    val st = ex.sampleTime
                    info.presentationTimeUs = st + offsetUs
                    info.flags = ex.sampleFlags
                    muxer.writeSampleData(if (ti == vi) vOut else aOut, buf, info)
                    if (st > maxUs) maxUs = st
                    ex.advance()
                }
                ex.release()
                offsetUs += maxUs + 33_000L
            }
            muxer.stop(); muxer.release(); muxer = null
            pfd.close(); pfd = null
            for (p in parts) try { contentResolver.delete(Uri.parse(p), null, null) } catch (_: Exception) {}
            return outUri.toString()
        } catch (e: Exception) {
            Log.e("Merge", "No se pudo unir", e)
            try { muxer?.release() } catch (_: Exception) {}
            try { pfd?.close() } catch (_: Exception) {}
            try { outUri?.let { contentResolver.delete(it, null, null) } } catch (_: Exception) {}
            return null
        }
    }

    // ---------- VAR: repetición dentro de la app, sin parar el partido ----------
    private fun setupVar() {
        b.varSurface.holder.addCallback(object : android.view.SurfaceHolder.Callback {
            override fun surfaceCreated(holder: android.view.SurfaceHolder) {
                varSurfaceReady = true
                pendingVarUri?.let { pendingVarUri = null; startVar(it) }
            }
            override fun surfaceChanged(holder: android.view.SurfaceHolder, format: Int, width: Int, height: Int) {}
            override fun surfaceDestroyed(holder: android.view.SurfaceHolder) { varSurfaceReady = false; releaseVar() }
        })
        b.btnVarPlay.tap { toggleVarPlay() }
        b.btnVarBack5.tap { varJump(-5000) }
        b.btnVarFwd5.tap { varJump(5000) }
        b.btnVarPrev.tap { varStep(-1) }
        b.btnVarNext.tap { varStep(1) }
        b.btnVarSpeed.tap {
            varSpeed = when (varSpeed) { 1f -> 0.5f; 0.5f -> 0.25f; else -> 1f }
            b.btnVarSpeed.text = if (varSpeed == 1f) "1x" else if (varSpeed == 0.5f) "0.5x" else "0.25x"
            applyVarSpeed()
        }
        b.btnVarClose.tap { closeVar() }
        b.varSeek.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: android.widget.SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) { varPos = p; varPlayer?.seekTo(p.toLong(), android.media.MediaPlayer.SEEK_CLOSEST) }
            }
            override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {}
        })
    }

    /** Cierra el archivo grabado hasta ahora, abre la repetición y sigue grabando en un archivo nuevo. */
    private fun openVar() {
        if (recording == null) { Toast.makeText(this, "Primero empieza a grabar para usar el VAR", Toast.LENGTH_LONG).show(); return }
        Toast.makeText(this, "VAR: preparando repetición...", Toast.LENGTH_SHORT).show()
        varRestart = true
        try { recording?.stop() } catch (e: Exception) { varRestart = false; Toast.makeText(this, "No se pudo abrir el VAR", Toast.LENGTH_SHORT).show() }
    }

    private fun showVar(uri: String) {
        b.varLayer.visibility = View.VISIBLE
        sfx.chime()
        if (varSurfaceReady) startVar(uri) else pendingVarUri = uri
    }

    private fun startVar(uri: String) {
        releaseVar()
        val mp = android.media.MediaPlayer()
        varPlayer = mp
        try {
            mp.setDisplay(b.varSurface.holder)
            mp.setDataSource(this, Uri.parse(uri))
            mp.setOnVideoSizeChangedListener { _, w, h -> varVideoW = w; varVideoH = h; fitVarSurface() }
            mp.setOnPreparedListener { p ->
                b.varSeek.max = p.duration
                varPos = (p.duration - 12_000).coerceAtLeast(0)
                p.seekTo(varPos.toLong(), android.media.MediaPlayer.SEEK_CLOSEST)
                p.start(); applyVarSpeed(); updateVarPlayBtn(); startVarTick()
            }
            mp.setOnCompletionListener { updateVarPlayBtn() }
            mp.setOnErrorListener { _, _, _ -> Toast.makeText(this, "No se pudo reproducir la repetición", Toast.LENGTH_LONG).show(); true }
            mp.prepareAsync()
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo abrir la repetición: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun fitVarSurface() {
        val cw = b.varLayer.width; val ch = b.varLayer.height
        if (cw == 0 || ch == 0 || varVideoW == 0 || varVideoH == 0) return
        val k = minOf(cw.toFloat() / varVideoW, ch.toFloat() / varVideoH)
        b.varSurface.layoutParams = android.widget.FrameLayout.LayoutParams((varVideoW * k).toInt(), (varVideoH * k).toInt(), android.view.Gravity.CENTER)
    }

    private fun applyVarSpeed() {
        val p = varPlayer ?: return
        try {
            val was = p.isPlaying
            p.playbackParams = p.playbackParams.setSpeed(varSpeed)
            if (!was) p.pause()
        } catch (_: Exception) {}
    }

    private fun toggleVarPlay() {
        val p = varPlayer ?: return
        try { if (p.isPlaying) p.pause() else { p.start(); applyVarSpeed() } } catch (_: Exception) {}
        updateVarPlayBtn()
    }

    private fun updateVarPlayBtn() {
        val playing = try { varPlayer?.isPlaying == true } catch (_: Exception) { false }
        b.btnVarPlay.text = if (playing) "Pausa" else "Reproducir"
        b.btnVarPlay.setIconResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
    }

    private fun varJump(ms: Int) {
        val p = varPlayer ?: return
        varPos = (varPos + ms).coerceIn(0, p.duration)
        p.seekTo(varPos.toLong(), android.media.MediaPlayer.SEEK_CLOSEST)
    }

    /** Avanza o retrocede un cuadro (según los FPS del partido). */
    private fun varStep(dir: Int) {
        val p = varPlayer ?: return
        try { if (p.isPlaying) p.pause() } catch (_: Exception) {}
        val frame = (1000f / state.fps.coerceAtLeast(1)).toInt().coerceAtLeast(16)
        varPos = (varPos + dir * frame).coerceIn(0, p.duration)
        p.seekTo(varPos.toLong(), android.media.MediaPlayer.SEEK_CLOSEST)
        updateVarPlayBtn()
    }

    private fun startVarTick() {
        varTick?.let { varHandler.removeCallbacks(it) }
        val r = object : Runnable {
            override fun run() {
                val p = varPlayer ?: return
                try {
                    if (p.isPlaying) varPos = p.currentPosition
                    b.varSeek.progress = varPos
                    b.tvVarTime.text = "${TimeFmt.mmss(varPos.toLong())} / ${TimeFmt.mmss(p.duration.toLong())}"
                } catch (_: Exception) {}
                b.tvVarLive.text = "Marcador actual:  ${state.homeShort} ${state.homeScore} - ${state.awayScore} ${state.awayShort}   ·   ${TimeFmt.mmss(state.elapsedMs)}"
                varHandler.postDelayed(this, 120)
            }
        }
        varTick = r
        varHandler.post(r)
    }

    private fun releaseVar() {
        varTick?.let { varHandler.removeCallbacks(it) }
        varTick = null
        try { varPlayer?.release() } catch (_: Exception) {}
        varPlayer = null
    }

    private fun closeVar() {
        releaseVar()
        pendingVarUri = null
        b.varLayer.visibility = View.GONE
    }

    private fun updateTimerBtn() {
        b.btnTimerToggle.text = if (state.running) "Pausar" else "Iniciar"
        b.btnTimerToggle.setIconResource(if (state.running) R.drawable.ic_pause else R.drawable.ic_play)
    }

    private fun nextPeriod() {
        val half = state.halfDurationMin * 60_000L
        state.period = when (state.period) {
            Period.FIRST -> Period.HALF
            Period.HALF -> Period.SECOND
            Period.SECOND -> Period.EXTRA
            Period.EXTRA -> Period.FULL
            else -> Period.FIRST
        }
        when (state.period) {
            Period.HALF, Period.FULL -> { pauseMatchTimer(); updateTimerBtn() }
            Period.SECOND -> if (state.elapsedMs < half) state.elapsedMs = half
            Period.EXTRA -> if (state.elapsedMs < 2 * half) state.elapsedMs = 2 * half
            else -> {}
        }
        state.addedMinutes = 0
        addedMs = 0L; preAlarmFired = false; endAlarmFired = false
        if (state.period == Period.SECOND) { try { recording?.resume() } catch (_: Exception) {} }
        b.btnPeriod.text = "Periodo: ${state.period.label}"
        sfx.whistle()
        addEvent("PERIOD", null, state.period.label)
        flash(
            when (state.period) {
                Period.HALF -> "DESCANSO"
                Period.FULL -> "FINAL DEL PARTIDO"
                else -> "COMIENZA ${state.period.label}"
            }, "#37474F", 5000, "whistle"
        )
    }

    private fun saveStyle(n: ScoreboardStyle) {
        style = n
        Prefs(this).saveStyle(n)
    }

    private fun showMore() {
        val items = arrayOf(
            "Tarjeta amarilla", "Tarjeta roja", "Cambio de jugador",
            "Tiempo añadido +1", "Quitar tiempo añadido", "Reiniciar cronómetro",
            if (sfx.enabled) "Silenciar sonidos" else "Activar sonidos",
            "Estilo del marcador", "Marcador más grande", "Marcador más pequeño", "Posición del marcador",
            "Tanda de penales"
        ) + (if (fixtureId >= 0) arrayOf("Guardar resultado en la copa") else emptyArray())
        AlertDialog.Builder(this).setTitle("Más acciones").setItems(items) { _, i ->
            when (i) {
                0 -> promptTeamPlayer("YELLOW")
                1 -> promptTeamPlayer("RED")
                2 -> promptTeamPlayer("SUB")
                3 -> { state.addedMinutes++; flash("TIEMPO AÑADIDO  +${state.addedMinutes}'", "#37474F", 4000, "time") }
                4 -> { state.addedMinutes = 0 }
                5 -> AlertDialog.Builder(this).setTitle("Reiniciar cronómetro").setMessage("¿Seguro?")
                    .setPositiveButton("Sí") { _, _ -> state.elapsedMs = 0 }
                    .setNegativeButton("No", null).show()
                6 -> { sfx.enabled = !sfx.enabled }
                7 -> {
                    val t = com.futbolpro.recorder.domain.ScoreboardTemplates.list
                    AlertDialog.Builder(this).setTitle("Estilo del marcador")
                        .setItems(t.map { it.second }.toTypedArray()) { _, k -> saveStyle(style.copy(template = t[k].first)) }.show()
                }
                8 -> saveStyle(style.copy(scale = (style.scale + 0.15f).coerceAtMost(2.5f)))
                9 -> saveStyle(style.copy(scale = (style.scale - 0.15f).coerceAtLeast(0.5f)))
                11 -> if (saveToFixture()) Toast.makeText(this, "Resultado guardado en la copa", Toast.LENGTH_LONG).show()
                10 -> {
                    val p = com.futbolpro.recorder.domain.ScoreboardTemplates.positions
                    AlertDialog.Builder(this).setTitle("Posición del marcador")
                        .setItems(p.map { it.second }.toTypedArray()) { _, k -> saveStyle(style.copy(pos = p[k].first)) }.show()
                }
            }
        }.show()
    }

    private fun promptTeamPlayer(type: String) {
        val teams = arrayOf(state.homeShort, state.awayShort)
        val colors = arrayOf(state.homeColor, state.awayColor)
        AlertDialog.Builder(this).setTitle("Registrar $type").setItems(teams) { _, which ->
            val roster = if (fixtureId >= 0 && type != "SUB") (if (which == 0) rosterHome else rosterAway) else emptyList()
            pickPlayer(roster, "¿Quién? (${teams[which]})") { addEvent(type, teams[which], it) }
            when (type) {
                "YELLOW" -> flash("TARJETA AMARILLA  ${teams[which]}", "#F9A825", 5000, "yellow")
                "RED" -> flash("TARJETA ROJA  ${teams[which]}", "#C62828", 5000, "red")
                else -> flash("CAMBIO  ${teams[which]}", colors[which], 5000, "sub")
            }
            sfx.card()
        }.show()
    }

    private fun addEvent(type: String, team: String?, player: String?, note: String? = null) {
        val minute = TimeFmt.matchMinute(state.elapsedMs, state.addedMinutes)
        events.add(MatchEvent(type, minute, team, player, note))
    }

    private fun startMatchTimer() {
        if (state.running) return
        state.running = true
        timerJob?.cancel()
        timerJob = lifecycleScope.launch {
            var last = SystemClock.elapsedRealtime()
            while (isActive && state.running) {
                delay(200)
                val now = SystemClock.elapsedRealtime()
                state.elapsedMs += (now - last)
                last = now
                checkPeriodAlarms()
            }
        }
    }

    private fun pauseMatchTimer() {
        state.running = false
        timerJob?.cancel()
    }

    private fun startUiTicker() {
        lifecycleScope.launch {
            while (isActive) {
                try {
                    val stat = StatFs(filesDir.absolutePath)
                    val freeMb = stat.availableBytes / (1024 * 1024)
                    val recElapsed = if (recRunning && !recPaused) recBaseMs + (SystemClock.elapsedRealtime() - recStartMs) else recBaseMs
                    b.tvRecTime.text = if (recRunning) "REC ${TimeFmt.mmss(recPrev + recElapsed)}" else "REC 00:00"
                    b.tvStorage.text = "Libre: ${freeMb} MB"
                } catch (_: Exception) {}
                delay(1000)
            }
        }
    }

    private fun startRecording() {
        val vc = videoCapture ?: return Toast.makeText(this, "Cámara no lista", Toast.LENGTH_SHORT).show()
        if (recording != null) return Toast.makeText(this, "Ya hay una grabación activa", Toast.LENGTH_SHORT).show()
        val name = "match_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/FutbolProRecorder")
            }
        }
        val out = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(values).build()
        try {
            var pending = vc.output.prepareRecording(this, out)
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                pending = pending.withAudioEnabled()
            }
            recording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
                when (event) {
                    is VideoRecordEvent.Start -> {
                        recRunning = true; recPaused = false; recBaseMs = 0; recStartMs = SystemClock.elapsedRealtime()
                    }
                    is VideoRecordEvent.Pause -> {
                        if (recRunning && !recPaused) { recBaseMs += SystemClock.elapsedRealtime() - recStartMs; recPaused = true }
                    }
                    is VideoRecordEvent.Resume -> {
                        if (recRunning && recPaused) { recStartMs = SystemClock.elapsedRealtime(); recPaused = false }
                    }
                    is VideoRecordEvent.Finalize -> {
                        if (recRunning && !recPaused) recBaseMs += SystemClock.elapsedRealtime() - recStartMs
                        recRunning = false; recPaused = false
                        recording = null
                        if (!event.hasError()) {
                            val seg = event.outputResults.outputUri?.toString()
                            if (seg != null) segments.add(seg)
                            recPrev += recBaseMs; recBaseMs = 0
                            if (varRestart && seg != null) {
                                varRestart = false
                                startRecording()
                                showVar(seg)
                            } else {
                                varRestart = false
                                finishRecording()
                            }
                        } else {
                            varRestart = false
                            Toast.makeText(this, "Error en grabación (${event.error})", Toast.LENGTH_LONG).show()
                        }
                        updateRecUi()
                    }
                }
                updateRecUi()
            }
            sfx.whistle()
            Toast.makeText(this, "Grabando...", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo iniciar grabación: ${e.message}", Toast.LENGTH_LONG).show()
        }
        updateRecUi()
    }

    private fun togglePauseRecording() {
        val r = recording ?: return
        try {
            if (recPaused) r.resume() else r.pause()
        } catch (e: Exception) {
            Toast.makeText(this, "Pausa/reanudar no soportado: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun stopRecording() {
        val r = recording
        if (r == null) { finish(); return }
        try { r.stop() } catch (_: Exception) {}
    }

    private fun updateRecUi() {
        val rec = recording != null
        b.btnRecStart.isEnabled = !rec
        b.btnRecStart.alpha = if (rec) 0.4f else 1f
        b.btnRecPause.isEnabled = rec
        b.btnRecPause.alpha = if (rec) 1f else 0.4f
        b.btnRecPause.setImageResource(if (recPaused) R.drawable.ic_play else R.drawable.ic_pause)
        b.btnRecStop.setImageResource(if (rec) R.drawable.ic_stop else R.drawable.ic_close)
        b.dotRec.visibility = if (recRunning && !recPaused) View.VISIBLE else View.INVISIBLE
    }

    private fun saveMatchToDb(durationSec: Long) {
        val db = (application as App).db
        val summary = mapOf(
            "events" to events,
            "final" to "${state.homeScore}-${state.awayScore}",
            "competition" to state.competition
        )
        val m = MatchEntity(
            homeTeamId = null, awayTeamId = null,
            homeName = state.homeName, awayName = state.awayName,
            homeShort = state.homeShort, awayShort = state.awayShort,
            homeBadge = state.homeBadge, awayBadge = state.awayBadge,
            homeColor = state.homeColor, awayColor = state.awayColor,
            homeScore = state.homeScore, awayScore = state.awayScore,
            durationSec = durationSec,
            videoPath = outputUriString,
            competition = state.competition,
            summaryJson = gson.toJson(summary)
        )
        bgScope.launch {
            try {
                val id = db.matches().insert(m)
                events.forEach { ev ->
                    db.events().insert(
                        MatchEventEntity(
                            matchId = id, type = ev.type, minute = ev.minute,
                            team = ev.team, player = ev.player, note = ev.note, timestampMs = ev.ts
                        )
                    )
                }
            } catch (_: Exception) {}
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        timerJob?.cancel()
        try { recording?.stop() } catch (_: Exception) {}
        releaseVar()
        cameraProvider?.unbindAll()
        try { overlayEffect?.close() } catch (_: Exception) {}
        effectThread.quitSafely()
        sfx.release()
    }
}
