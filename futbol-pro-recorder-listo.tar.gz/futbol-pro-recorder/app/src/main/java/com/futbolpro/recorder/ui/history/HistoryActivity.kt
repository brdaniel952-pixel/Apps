package com.futbolpro.recorder.ui.history

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.futbolpro.recorder.App
import com.futbolpro.recorder.data.MatchEntity
import com.futbolpro.recorder.databinding.ActivityHistoryBinding
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class HistoryActivity : AppCompatActivity() {
    private lateinit var b: ActivityHistoryBinding
    private var items: List<MatchEntity> = emptyList()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(b.root)
        refresh()
        b.listMatches.setOnItemClickListener { _, _, pos, _ -> showActions(items[pos]) }
    }
    private fun refresh() {
        val db = (application as App).db
        lifecycleScope.launch {
            items = db.matches().getAll()
            val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
            b.listMatches.adapter = ArrayAdapter(this@HistoryActivity, android.R.layout.simple_list_item_1,
                items.map { "${it.homeName} ${it.homeScore}-${it.awayScore} ${it.awayName}\n${fmt.format(Date(it.dateMillis))} · ${it.durationSec/60}m" })
        }
    }
    private fun showActions(m: MatchEntity) {
        val opts = arrayOf("Reproducir", "Compartir", "Eliminar")
        AlertDialog.Builder(this).setTitle("${m.homeName} vs ${m.awayName}").setItems(opts) { _, which ->
            when (which) {
                0 -> play(m)
                1 -> share(m)
                2 -> delete(m)
            }
        }.show()
    }
    private fun play(m: MatchEntity) {
        val path = m.videoPath ?: return
        val f = File(path)
        if (!f.exists()) { Toast.makeText(this, "Vídeo no encontrado", Toast.LENGTH_SHORT).show(); return }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
    }
    private fun share(m: MatchEntity) {
        val path = m.videoPath ?: return
        val f = File(path)
        if (!f.exists()) return
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Compartir"))
    }
    private fun delete(m: MatchEntity) {
        val db = (application as App).db
        lifecycleScope.launch {
            m.videoPath?.let { File(it).delete() }
            db.events().deleteForMatch(m.id)
            db.matches().delete(m)
            refresh()
        }
    }
}
