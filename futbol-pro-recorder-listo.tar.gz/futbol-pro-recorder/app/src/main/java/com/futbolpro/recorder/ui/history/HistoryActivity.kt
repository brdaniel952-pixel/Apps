package com.futbolpro.recorder.ui.history

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Size
import android.view.Gravity
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.futbolpro.recorder.App
import com.futbolpro.recorder.R
import com.futbolpro.recorder.data.MatchEntity
import com.futbolpro.recorder.databinding.ActivityHistoryBinding
import com.futbolpro.recorder.ui.cup.CupUi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Todas las grabaciones de partidos: ver, compartir o borrar. */
class HistoryActivity : AppCompatActivity() {
    private lateinit var b: ActivityHistoryBinding
    private lateinit var ui: CupUi

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(b.root)
        ui = CupUi(this)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun videoUri(m: MatchEntity): Uri? {
        val p = m.videoPath ?: return null
        if (p.startsWith("content:") || p.startsWith("file:")) return Uri.parse(p)
        val f = File(p)
        return if (f.exists()) FileProvider.getUriForFile(this, "$packageName.fileprovider", f) else null
    }

    private fun render() {
        lifecycleScope.launch {
            val items = (application as App).db.matches().getAll()
            val fmt = SimpleDateFormat("EEE d MMM yyyy · HH:mm", Locale("es"))
            b.tvCount.text = if (items.isEmpty()) "Todavía no has grabado ningún partido" else "${items.size} partido${if (items.size == 1) "" else "s"} grabado${if (items.size == 1) "" else "s"}"
            b.recContainer.removeAllViews()
            for (m in items) {
                val card = ui.row(true)
                val top = LinearLayout(this@HistoryActivity).apply { gravity = Gravity.CENTER_VERTICAL }
                val thumb = ImageView(this@HistoryActivity).apply {
                    layoutParams = LinearLayout.LayoutParams(ui.dp(124), ui.dp(70))
                    setBackgroundResource(R.drawable.bg_input)
                    outlineProvider = ViewOutlineProvider.BACKGROUND; clipToOutline = true
                    scaleType = ImageView.ScaleType.CENTER
                    setImageResource(R.drawable.ic_play)
                    imageTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#0A84FF"))
                }
                loadThumb(m, thumb)
                top.addView(thumb)
                val col = LinearLayout(this@HistoryActivity).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = ui.dp(12) } }
                col.addView(ui.tv("${m.homeShort}  ${m.homeScore} - ${m.awayScore}  ${m.awayShort}", 17f, Color.WHITE, true, 0f, Gravity.START))
                col.addView(ui.tv("${m.homeName} vs ${m.awayName}", 12f, Color.parseColor("#8E8E93"), false, 0f, Gravity.START))
                col.addView(ui.tv(fmt.format(Date(m.dateMillis)) + " · ${m.durationSec / 60} min", 11f, Color.parseColor("#8E8E93"), false, 0f, Gravity.START).apply { setPadding(0, ui.dp(4), 0, 0) })
                if (!m.competition.isNullOrBlank()) col.addView(ui.tv(m.competition!!.uppercase(), 10f, Color.parseColor("#0A84FF"), true, 0f, Gravity.START))
                top.addView(col)
                card.addView(top)
                val acts = LinearLayout(this@HistoryActivity)
                acts.addView(ui.btn("Ver", null, 1f) { play(m) })
                acts.addView(ui.btn("Compartir", Color.parseColor("#2C2C2E"), 1f) { share(m) })
                acts.addView(ui.btn("Borrar", Color.parseColor("#3A1C1F"), 1f) { confirmDelete(m) })
                card.addView(acts)
                b.recContainer.addView(card)
            }
            if (items.isEmpty()) b.recContainer.addView(ui.tv("Cuando grabes un partido aparecerá aquí.", 14f, Color.parseColor("#8E8E93")).apply { setPadding(0, ui.dp(30), 0, 0) })
        }
    }

    private fun loadThumb(m: MatchEntity, img: ImageView) {
        val p = m.videoPath ?: return
        if (Build.VERSION.SDK_INT < 29 || !p.startsWith("content:")) return
        lifecycleScope.launch(Dispatchers.IO) {
            val bmp = try { contentResolver.loadThumbnail(Uri.parse(p), Size(480, 270), null) } catch (_: Exception) { null }
            if (bmp != null) withContext(Dispatchers.Main) { img.imageTintList = null; img.scaleType = ImageView.ScaleType.CENTER_CROP; img.setImageBitmap(bmp) }
        }
    }

    private fun play(m: MatchEntity) {
        val uri = videoUri(m)
        if (uri == null) { Toast.makeText(this, "No se encontró el video", Toast.LENGTH_SHORT).show(); return }
        try { startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
        catch (_: Exception) { Toast.makeText(this, "No hay una app para reproducir el video", Toast.LENGTH_SHORT).show() }
    }

    private fun share(m: MatchEntity) {
        val uri = videoUri(m)
        if (uri == null) { Toast.makeText(this, "No se encontró el video", Toast.LENGTH_SHORT).show(); return }
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Compartir video"))
    }

    private fun confirmDelete(m: MatchEntity) {
        AlertDialog.Builder(this).setTitle("Borrar grabación").setMessage("Se borra el video de ${m.homeName} vs ${m.awayName} del teléfono. ¿Seguro?")
            .setPositiveButton("Borrar") { _, _ ->
                lifecycleScope.launch {
                    val db = (application as App).db
                    withContext(Dispatchers.IO) {
                        try {
                            val p = m.videoPath
                            if (p != null) { if (p.startsWith("content:")) contentResolver.delete(Uri.parse(p), null, null) else File(p).delete() }
                        } catch (_: Exception) {}
                        db.events().deleteForMatch(m.id)
                        db.matches().delete(m)
                    }
                    render()
                }
            }.setNegativeButton("Cancelar", null).show()
    }
}
