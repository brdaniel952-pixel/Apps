package com.futbolpro.recorder.ui.history

import android.content.ContentUris
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Size
import android.view.Gravity
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.futbolpro.recorder.App
import com.futbolpro.recorder.R
import com.futbolpro.recorder.data.MatchEntity
import com.futbolpro.recorder.databinding.ActivityHistoryBinding
import com.futbolpro.recorder.ui.cup.CupUi
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Todas las grabaciones: las del historial del partido y cualquier video que esté en la carpeta FutbolProRecorder. */
class HistoryActivity : AppCompatActivity() {
    private lateinit var b: ActivityHistoryBinding
    private lateinit var ui: CupUi

    private class Row(
        val date: Long, val title: String, val sub: String, val detail: String, val tag: String,
        val uri: Uri?, val onDelete: () -> Unit
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(b.root)
        ui = CupUi(this)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun matchUri(m: MatchEntity): Uri? {
        val p = m.videoPath ?: return null
        if (p.startsWith("content:") || p.startsWith("file:")) return Uri.parse(p)
        val f = File(p)
        return if (f.exists()) FileProvider.getUriForFile(this, "$packageName.fileprovider", f) else null
    }

    private fun partLabel(m: MatchEntity): String = try {
        when ((Gson().fromJson(m.summaryJson, Map::class.java)?.get("part") as? String) ?: "") {
            "1T" -> "PRIMER TIEMPO"; "2T" -> "SEGUNDO TIEMPO"; else -> ""
        }
    } catch (_: Exception) { "" }

    /** Videos de la carpeta de la app que no están en el historial (por ejemplo si se cortó la grabación). */
    private fun scanFolder(knownIds: Set<String>): List<Row> {
        val out = mutableListOf<Row>()
        val proj = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.DATE_ADDED, MediaStore.Video.Media.DURATION)
        val sel = if (Build.VERSION.SDK_INT >= 29) "${MediaStore.Video.Media.RELATIVE_PATH} LIKE ?" else "${MediaStore.Video.Media.DATA} LIKE ?"
        try {
            contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, proj, sel, arrayOf("%FutbolProRecorder%"), "${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    if (id.toString() in knownIds) continue
                    val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                    val date = c.getLong(2) * 1000
                    out.add(Row(date, "Video grabado", c.getString(1) ?: "", "${c.getLong(3) / 60000} min", "", uri) {
                        try { contentResolver.delete(uri, null, null) } catch (_: Exception) {}
                    })
                }
            }
        } catch (_: Exception) {}
        return out
    }

    private fun render() {
        lifecycleScope.launch {
            val db = (application as App).db
            val matches = db.matches().getAll()
            val fmt = SimpleDateFormat("EEE d MMM yyyy · HH:mm", Locale("es"))
            val known = matches.mapNotNull { it.videoPath?.let { p -> Uri.parse(p).lastPathSegment } }.toSet()
            val rows = mutableListOf<Row>()
            for (m in matches) {
                rows.add(Row(m.dateMillis, "${m.homeShort}  ${m.homeScore} - ${m.awayScore}  ${m.awayShort}", "${m.homeName} vs ${m.awayName}",
                    "${m.durationSec / 60} min", listOf(partLabel(m), m.competition.orEmpty().uppercase()).filter { it.isNotBlank() }.joinToString(" · "), matchUri(m)) { deleteMatch(m) })
            }
            rows.addAll(withContext(Dispatchers.IO) { scanFolder(known) })
            rows.sortByDescending { it.date }

            b.tvCount.text = if (rows.isEmpty()) "Todavía no has grabado ningún partido" else "${rows.size} grabación${if (rows.size == 1) "" else "es"}"
            b.recContainer.removeAllViews()
            if (rows.isEmpty()) {
                b.recContainer.addView(ui.tv("Cuando grabes un partido aparecerá aquí. También se guarda en la galería, carpeta Movies/FutbolProRecorder.", 14f, Color.parseColor("#8E8E93")).apply { setPadding(0, ui.dp(30), 0, 0) })
                return@launch
            }
            for (r in rows) {
                val card = ui.row(true)
                val top = LinearLayout(this@HistoryActivity).apply { gravity = Gravity.CENTER_VERTICAL }
                val thumb = ImageView(this@HistoryActivity).apply {
                    layoutParams = LinearLayout.LayoutParams(ui.dp(124), ui.dp(70))
                    setBackgroundResource(R.drawable.bg_input)
                    outlineProvider = ViewOutlineProvider.BACKGROUND; clipToOutline = true
                    scaleType = ImageView.ScaleType.CENTER
                    setImageResource(R.drawable.ic_play)
                    imageTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#0A84FF"))
                }
                loadThumb(r.uri, thumb)
                top.addView(thumb)
                val col = LinearLayout(this@HistoryActivity).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = ui.dp(12) } }
                col.addView(ui.tv(r.title, 17f, Color.WHITE, true, 0f, Gravity.START))
                col.addView(ui.tv(r.sub, 12f, Color.parseColor("#8E8E93"), false, 0f, Gravity.START))
                col.addView(ui.tv(fmt.format(Date(r.date)) + " · " + r.detail, 11f, Color.parseColor("#8E8E93"), false, 0f, Gravity.START).apply { setPadding(0, ui.dp(4), 0, 0) })
                if (r.tag.isNotBlank()) col.addView(ui.tv(r.tag, 10f, Color.parseColor("#0A84FF"), true, 0f, Gravity.START))
                top.addView(col)
                card.addView(top)
                val acts = LinearLayout(this@HistoryActivity)
                acts.addView(ui.btn("Ver", null, 1f) { play(r.uri) })
                acts.addView(ui.btn("Compartir", Color.parseColor("#2C2C2E"), 1f) { share(r.uri) })
                acts.addView(ui.btn("Borrar", Color.parseColor("#3A1C1F"), 1f) { confirmDelete(r) })
                card.addView(acts)
                b.recContainer.addView(card)
            }
        }
    }

    private fun loadThumb(uri: Uri?, img: ImageView) {
        if (uri == null || Build.VERSION.SDK_INT < 29 || uri.scheme != "content") return
        lifecycleScope.launch(Dispatchers.IO) {
            val bmp = try { contentResolver.loadThumbnail(uri, Size(480, 270), null) } catch (_: Exception) { null }
            if (bmp != null) withContext(Dispatchers.Main) { img.imageTintList = null; img.scaleType = ImageView.ScaleType.CENTER_CROP; img.setImageBitmap(bmp) }
        }
    }

    private fun play(uri: Uri?) {
        if (uri == null) { Toast.makeText(this, "No se encontró el video", Toast.LENGTH_SHORT).show(); return }
        try { startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
        catch (_: Exception) { Toast.makeText(this, "No hay una app para reproducir el video", Toast.LENGTH_SHORT).show() }
    }

    private fun share(uri: Uri?) {
        if (uri == null) { Toast.makeText(this, "No se encontró el video", Toast.LENGTH_SHORT).show(); return }
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Compartir video"))
    }

    private fun confirmDelete(r: Row) {
        AlertDialog.Builder(this).setTitle("Borrar grabación").setMessage("Se borra el video del teléfono. ¿Seguro?")
            .setPositiveButton("Borrar") { _, _ -> lifecycleScope.launch { withContext(Dispatchers.IO) { r.onDelete() }; render() } }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun deleteMatch(m: MatchEntity) {
        try {
            val p = m.videoPath
            if (p != null) { if (p.startsWith("content:")) contentResolver.delete(Uri.parse(p), null, null) else File(p).delete() }
        } catch (_: Exception) {}
        val db = (application as App).db
        kotlinx.coroutines.runBlocking { db.events().deleteForMatch(m.id); db.matches().delete(m) }
    }
}
