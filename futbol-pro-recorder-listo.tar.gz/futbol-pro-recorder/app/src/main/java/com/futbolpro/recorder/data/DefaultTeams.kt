package com.futbolpro.recorder.data

object DefaultTeams {
    fun list(pkg: String): List<TeamEntity> {
        fun badge(n: String) = "android.resource://$pkg/drawable/$n"
        return listOf(
            TeamEntity(name = "Deportivo Maracaibo", shortName = "DEM", badgeUri = badge("badge_dm"), primaryColor = "#1E3A8A"),
            TeamEntity(name = "Atlético Zuliano", shortName = "ATZ", badgeUri = badge("badge_az"), primaryColor = "#B8860B"),
            TeamEntity(name = "Deportivo AD", shortName = "DAD", badgeUri = badge("badge_ad"), primaryColor = "#1C1C1E"),
            TeamEntity(name = "Estudiantes de Trujillo", shortName = "EDT", badgeUri = badge("badge_et"), primaryColor = "#C62828")
        )
    }
}
