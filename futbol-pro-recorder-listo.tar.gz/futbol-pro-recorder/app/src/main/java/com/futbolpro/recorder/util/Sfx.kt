package com.futbolpro.recorder.util

import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper

class Sfx {
    var enabled = true
    private val tone: ToneGenerator? = try { ToneGenerator(AudioManager.STREAM_MUSIC, 70) } catch (_: Exception) { null }
    private val h = Handler(Looper.getMainLooper())

    fun click() { if (enabled) tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 70) }

    fun goal() {
        if (!enabled) return
        tone?.startTone(ToneGenerator.TONE_DTMF_3, 150)
        h.postDelayed({ tone?.startTone(ToneGenerator.TONE_DTMF_6, 150) }, 170)
        h.postDelayed({ tone?.startTone(ToneGenerator.TONE_DTMF_9, 600) }, 340)
    }

    fun whistle() { if (enabled) tone?.startTone(ToneGenerator.TONE_CDMA_PIP, 600) }

    fun release() { h.removeCallbacksAndMessages(null); tone?.release() }
}
