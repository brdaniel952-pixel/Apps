package com.futbolpro.recorder.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.SoundPool
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import com.futbolpro.recorder.R

/** Sonidos de la app (sintetizados, no tonos de teléfono) y alarma fuerte para avisos del partido. */
class Sfx(private val ctx: Context) {
    var enabled = true
    private val h = Handler(Looper.getMainLooper())
    private val pool: SoundPool = SoundPool.Builder().setMaxStreams(4).setAudioAttributes(
        AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
    ).build()
    private val ids = HashMap<Int, Int>()
    private var alarm: MediaPlayer? = null
    private var prevAlarmVol = -1

    private fun load(res: Int) { ids[res] = pool.load(ctx, res, 1) }
    init { listOf(R.raw.sfx_click, R.raw.sfx_chime, R.raw.sfx_whistle, R.raw.sfx_goal, R.raw.sfx_card, R.raw.sfx_pen_goal, R.raw.sfx_pen_miss).forEach { load(it) } }

    private fun play(res: Int, vol: Float = 1f) {
        if (!enabled) return
        val id = ids[res] ?: return
        pool.play(id, vol, vol, 1, 0, 1f)
    }

    fun click() = play(R.raw.sfx_click, 0.7f)
    fun chime() = play(R.raw.sfx_chime)
    fun whistle() = play(R.raw.sfx_whistle)
    fun goal() = play(R.raw.sfx_goal)
    fun card() = play(R.raw.sfx_card)
    fun penGoal() = play(R.raw.sfx_pen_goal)
    fun penMiss() = play(R.raw.sfx_pen_miss)

    /** Alarma fuerte: suena por el canal de alarma, al máximo, aunque los sonidos estén apagados. */
    fun alarmStart(seconds: Int = 10) {
        alarmStop()
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            prevAlarmVol = am.getStreamVolume(AudioManager.STREAM_ALARM)
            try { am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0) } catch (_: Exception) {}
            val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            val mp = MediaPlayer.create(ctx, R.raw.sfx_alarm, attrs, AudioManager.AUDIO_SESSION_ID_GENERATE)
            mp.isLooping = true
            mp.start()
            alarm = mp
            h.postDelayed({ alarmStop() }, seconds * 1000L)
        } catch (_: Exception) {}
        vibrate(longArrayOf(0, 600, 200, 600, 200, 900, 300, 600, 200, 900))
    }

    fun alarmStop() {
        h.removeCallbacksAndMessages(null)
        try { alarm?.stop() } catch (_: Exception) {}
        try { alarm?.release() } catch (_: Exception) {}
        alarm = null
        if (prevAlarmVol >= 0) {
            try { (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).setStreamVolume(AudioManager.STREAM_ALARM, prevAlarmVol, 0) } catch (_: Exception) {}
            prevAlarmVol = -1
        }
    }

    fun vibrate(pattern: LongArray) {
        try {
            val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(pattern, -1)) else @Suppress("DEPRECATION") v.vibrate(pattern, -1)
        } catch (_: Exception) {}
    }

    fun release() { alarmStop(); try { pool.release() } catch (_: Exception) {} }
}
