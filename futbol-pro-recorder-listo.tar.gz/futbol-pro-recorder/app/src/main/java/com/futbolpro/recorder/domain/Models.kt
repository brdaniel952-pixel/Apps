package com.futbolpro.recorder.domain

import android.graphics.Color

enum class Period(val label: String) { FIRST("1T"), HALF("DESC"), SECOND("2T"), EXTRA("ET"), FULL("FIN") }

object ScoreboardTemplates {
    val list = listOf(
        "mundial" to "Mundial", "clasico" to "Clásico", "brasil" to "Brasil", "copa" to "Copa",
        "fifa" to "Blanco FIFA", "azul" to "Azul TV", "guinda" to "Guinda", "naranja" to "Naranja 2010",
        "champions" to "Champions", "cocacola" to "Copa Coca-Cola"
    )
    val positions = listOf("left" to "Arriba izquierda", "center" to "Arriba centro", "right" to "Arriba derecha")
}

data class ScoreboardStyle(
    val id: String = "classic",
    val name: String = "Clásico TV",
    val template: String = "mundial", // mundial, clasico, brasil, copa
    val pos: String = "left", // left, center, right
    val x: Float = 0.5f,
    val y: Float = 0.06f,
    val scale: Float = 1.0f,
    val alpha: Float = 0.95f,
    val showBadges: Boolean = true,
    val homeColor: String = "#1565C0",
    val awayColor: String = "#C62828",
    val textColor: String = "#FFFFFF",
    val bgColor: String = "#CC0B1D3A"
)

data class MatchState(
    var matchId: Long = 0,
    var homeName: String = "LOCAL",
    var awayName: String = "VISITA",
    var homeShort: String = "LOC",
    var awayShort: String = "VIS",
    var homeBadge: String? = null,
    var awayBadge: String? = null,
    var homeColor: String = "#1565C0",
    var awayColor: String = "#C62828",
    var homeScore: Int = 0,
    var awayScore: Int = 0,
    var period: Period = Period.FIRST,
    var elapsedMs: Long = 0L,
    var running: Boolean = false,
    var addedMinutes: Int = 0,
    var halfDurationMin: Int = 45,
    var competition: String = "",
    var resolution: String = "1080p",
    var fps: Int = 30,
    @Volatile var flashText: String = "",
    @Volatile var flashColor: String = "#C62828",
    @Volatile var flashUntil: Long = 0L,
    @Volatile var flashStart: Long = 0L,
    @Volatile var flashIcon: String = "",
    // Tanda de penales
    @Volatile var penActive: Boolean = false,
    var penRounds: Int = 3,
    val penHome: java.util.concurrent.CopyOnWriteArrayList<Int> = java.util.concurrent.CopyOnWriteArrayList(),
    val penAway: java.util.concurrent.CopyOnWriteArrayList<Int> = java.util.concurrent.CopyOnWriteArrayList(),
    @Volatile var penWinner: String = ""
)

data class PlayerInfo(val number: String = "", val name: String = "")
data class MatchEvent(val type: String, val minute: String, val team: String?, val player: String?, val note: String? = null, val ts: Long = System.currentTimeMillis())

object TimeFmt {
    fun mmss(ms: Long): String {
        val totalSec = (ms / 1000).coerceAtLeast(0)
        val m = totalSec / 60
        val s = totalSec % 60
        return "%02d:%02d".format(m, s)
    }
    fun matchMinute(ms: Long, added: Int): String {
        val m = (ms / 60000).toInt()
        return if (added > 0) "$m+$added'" else "$m'"
    }
    fun parseColor(hex: String, fallback: Int = Color.WHITE): Int = try { Color.parseColor(hex) } catch (_: Exception) { fallback }
}
