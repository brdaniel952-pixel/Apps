package com.futbolpro.recorder.data

import android.content.Context
import java.security.MessageDigest

/** Acceso por equipo (local en este teléfono): contraseña por equipo, sesión guardada y equipos admin. */
object Auth {
    private fun sp(c: Context) = c.getSharedPreferences("auth", Context.MODE_PRIVATE)

    // Contraseñas iniciales (cada equipo la puede cambiar luego)
    private val defaults = mapOf(
        "Deportivo AD" to "AD-2026",
        "Deportivo Maracaibo" to "DM-2026",
        "Atlético Zuliano" to "AZ-2026",
        "Estudiantes de Trujillo" to "ET-2026"
    )

    private fun hash(gid: String, pass: String): String =
        MessageDigest.getInstance("SHA-256").digest("futpro:$gid:$pass".toByteArray()).joinToString("") { "%02x".format(it) }

    /** Asigna contraseña inicial a los equipos que aún no tienen y deja a Deportivo AD como admin. */
    fun ensureDefaults(c: Context, teams: List<TeamEntity>) {
        val p = sp(c)
        val e = p.edit()
        for (t in teams) {
            val g = CloudSync.gidOf(c, t)
            if (!p.contains("g_$g")) e.putString("g_$g", hash(g, defaults[t.name] ?: "1234"))
        }
        if (!p.contains("admins_g") && teams.any { it.name == "Deportivo AD" }) {
            e.putStringSet("admins_g", teams.filter { it.name == "Deportivo AD" }.map { CloudSync.gidOf(c, it) }.toSet())
        }
        e.apply()
    }

    fun check(c: Context, id: Long, pass: String): Boolean { val g = CloudSync.gidFor(c, id); return sp(c).getString("g_$g", null) == hash(g, pass) }
    fun setPassword(c: Context, id: Long, pass: String) { val g = CloudSync.gidFor(c, id); sp(c).edit().putString("g_$g", hash(g, pass)).apply() }
    fun passHash(c: Context, id: Long): String? = sp(c).getString("g_${CloudSync.gidFor(c, id)}", null)
    fun setHash(c: Context, gid: String, h: String) { sp(c).edit().putString("g_$gid", h).apply() }

    fun login(c: Context, id: Long) { sp(c).edit().putLong("session", id).apply() }
    fun logout(c: Context) { sp(c).edit().remove("session").apply() }
    fun currentTeamId(c: Context): Long = sp(c).getLong("session", -1L)

    fun admins(c: Context): Set<Long> = (sp(c).getStringSet("admins_g", emptySet()) ?: emptySet()).mapNotNull { CloudSync.localIdOf(c, it) }.toSet()
    fun setAdmins(c: Context, ids: Set<Long>) { sp(c).edit().putStringSet("admins_g", ids.map { CloudSync.gidFor(c, it) }.toSet()).apply() }
    fun isAdmin(c: Context): Boolean = currentTeamId(c) in admins(c)
    fun canEdit(c: Context, teamId: Long): Boolean = isAdmin(c) || currentTeamId(c) == teamId

    fun forget(c: Context, id: Long) {
        val g = CloudSync.gidFor(c, id)
        sp(c).edit().remove("g_$g").apply()
        setAdmins(c, admins(c).filter { it != id }.toSet())
        if (currentTeamId(c) == id) logout(c)
    }
}
