package com.futbolpro.recorder.data

import android.content.Context
import java.security.MessageDigest

/** Acceso por equipo (local en este teléfono): contraseña por equipo, sesión guardada y equipos admin. */
object Auth {
    private fun sp(c: Context) = c.getSharedPreferences("auth", Context.MODE_PRIVATE)

    // Contraseñas iniciales (cada equipo la puede cambiar luego)
    private val defaults = mapOf(
        "Deportivo AD" to "AD-2026",
        "Deportivo Maracaibo" to "DM-2026",
        "Atlético Zuliano" to "AZ-2026",
        "Estudiantes de Trujillo" to "ET-2026"
    )

    private fun hash(id: Long, pass: String): String =
        MessageDigest.getInstance("SHA-256").digest("futpro:$id:$pass".toByteArray()).joinToString("") { "%02x".format(it) }

    /** Asigna contraseña inicial a los equipos que aún no tienen y deja a Deportivo AD como admin. */
    fun ensureDefaults(c: Context, teams: List<TeamEntity>) {
        val p = sp(c)
        val e = p.edit()
        for (t in teams) if (!p.contains("h_${t.id}")) e.putString("h_${t.id}", hash(t.id, defaults[t.name] ?: "1234"))
        if (!p.contains("admins")) {
            e.putStringSet("admins", teams.filter { it.name == "Deportivo AD" }.map { it.id.toString() }.toSet())
        }
        e.apply()
    }

    fun check(c: Context, id: Long, pass: String): Boolean = sp(c).getString("h_$id", null) == hash(id, pass)
    fun setPassword(c: Context, id: Long, pass: String) { sp(c).edit().putString("h_$id", hash(id, pass)).apply() }

    fun login(c: Context, id: Long) { sp(c).edit().putLong("session", id).apply() }
    fun logout(c: Context) { sp(c).edit().remove("session").apply() }
    fun currentTeamId(c: Context): Long = sp(c).getLong("session", -1L)

    fun admins(c: Context): Set<Long> = (sp(c).getStringSet("admins", emptySet()) ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet()
    fun setAdmins(c: Context, ids: Set<Long>) { sp(c).edit().putStringSet("admins", ids.map { it.toString() }.toSet()).apply() }
    fun isAdmin(c: Context): Boolean = currentTeamId(c) in admins(c)
    fun canEdit(c: Context, teamId: Long): Boolean = isAdmin(c) || currentTeamId(c) == teamId

    fun forget(c: Context, id: Long) {
        sp(c).edit().remove("h_$id").putStringSet("admins", admins(c).filter { it != id }.map { it.toString() }.toSet()).apply()
        if (currentTeamId(c) == id) logout(c)
    }
}
