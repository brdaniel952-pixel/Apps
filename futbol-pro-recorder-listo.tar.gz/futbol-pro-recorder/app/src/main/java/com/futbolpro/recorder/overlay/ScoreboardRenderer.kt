package com.futbolpro.recorder.overlay

import android.content.Context
import android.graphics.*
import android.net.Uri
import com.futbolpro.recorder.domain.MatchState
import com.futbolpro.recorder.domain.ScoreboardStyle
import com.futbolpro.recorder.domain.TimeFmt

/** Dibuja el marcador estilo TV (arriba a la izquierda). Se usa en vista previa y en el video grabado. */
class ScoreboardRenderer(private val ctx: Context) {
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()
    private val clip = Path()
    @Volatile private var homeBmp: Bitmap? = null
    @Volatile private var awayBmp: Bitmap? = null

    private val timeBg = Color.parseColor("#E6101820")
    private val yellow = Color.parseColor("#FFD600")
    private val red = Color.parseColor("#FF1744")

    fun setBadges(home: String?, away: String?) {
        homeBmp = load(home)
        awayBmp = load(away)
    }

    private fun load(uri: String?): Bitmap? {
        if (uri == null) return null
        return try {
            val u = Uri.parse(uri)
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / (s * 2) >= 256 && o.outHeight / (s * 2) >= 256) s *= 2
            val o2 = BitmapFactory.Options().apply { inSampleSize = s }
            ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) }
        } catch (_: Exception) { null }
    }

    private fun text(c: Canvas, t: String, cx: Float, cy: Float, size: Float, maxW: Float, color: Int = Color.WHITE) {
        txt.color = color
        txt.textSize = size
        val tw = txt.measureText(t)
        if (tw > maxW && tw > 0f) txt.textSize = size * maxW / tw
        c.drawText(t, cx, cy - (txt.ascent() + txt.descent()) / 2f, txt)
    }

    fun draw(c: Canvas, w: Float, h: Float, s: MatchState, st: ScoreboardStyle) {
        val k = w / 1920f
        val u = k * st.scale * (if (st.template == "minimal") 0.88f else 1f)
        val left = 36f * k
        val top = (h * st.y).coerceAtLeast(24f * k)
        val barH = 76f * u
        val tab = 10f * u
        val pad = 12f * u
        val badgeSz = 56f * u
        val nameW = 112f * u
        val scoreW = 66f * u
        val hb = if (st.showBadges) homeBmp else null
        val ab = if (st.showBadges) awayBmp else null
        val homeW = tab + pad + (if (hb != null) badgeSz + pad else 0f) + nameW
        val awayW = nameW + (if (ab != null) pad + badgeSz else 0f) + pad + tab
        val barW = homeW + scoreW * 2 + awayW
        val r = (when (st.template) { "bold" -> 6f; "minimal" -> 20f; else -> 12f }) * u
        val cy = top + barH / 2f

        // Fondo
        bg.color = TimeFmt.parseColor(st.bgColor, Color.parseColor("#CC0B1D3A"))
        bg.alpha = (st.alpha * 255).toInt().coerceIn(60, 255)
        rect.set(left, top, left + barW, top + barH)
        c.drawRoundRect(rect, r, r, bg)

        // Colores de equipo + cajas de goles (recortado a las esquinas redondeadas)
        c.save()
        clip.reset(); clip.addRoundRect(rect, r, r, Path.Direction.CW)
        c.clipPath(clip)
        fill.color = TimeFmt.parseColor(s.homeColor, Color.BLUE)
        rect.set(left, top, left + (if (st.template == "bold") homeW else tab), top + barH)
        c.drawRect(rect, fill)
        fill.color = TimeFmt.parseColor(s.awayColor, Color.RED)
        val awayX = left + homeW + scoreW * 2
        rect.set(if (st.template == "bold") awayX else left + barW - tab, top, left + barW, top + barH)
        c.drawRect(rect, fill)
        if (st.template != "minimal") {
            fill.color = Color.parseColor("#33FFFFFF")
            rect.set(left + homeW, top, awayX, top + barH)
            c.drawRect(rect, fill)
        }
        c.restore()

        // Escudos
        if (hb != null) {
            val bx = left + tab + pad
            rect.set(bx, cy - badgeSz / 2f, bx + badgeSz, cy + badgeSz / 2f)
            c.drawBitmap(hb, null, rect, null)
        }
        if (ab != null) {
            val bx = awayX + nameW + pad
            rect.set(bx, cy - badgeSz / 2f, bx + badgeSz, cy + badgeSz / 2f)
            c.drawBitmap(ab, null, rect, null)
        }

        // Nombres y goles
        val hn = s.homeShort.ifBlank { s.homeName.take(3).uppercase() }
        val an = s.awayShort.ifBlank { s.awayName.take(3).uppercase() }
        val hx0 = left + tab + pad + (if (hb != null) badgeSz + pad else 0f)
        text(c, hn, hx0 + nameW / 2f, cy, 38f * u, nameW - 8f * u)
        text(c, an, awayX + nameW / 2f, cy, 38f * u, nameW - 8f * u)
        text(c, s.homeScore.toString(), left + homeW + scoreW / 2f, cy, 48f * u, scoreW)
        text(c, s.awayScore.toString(), left + homeW + scoreW * 1.5f, cy, 48f * u, scoreW)

        // Cronómetro y periodo
        val tx = left + barW + 6f * u
        val tw = 190f * u
        fill.color = timeBg
        rect.set(tx, top, tx + tw, top + barH)
        c.drawRoundRect(rect, r, r, fill)
        text(c, TimeFmt.mmss(s.elapsedMs), tx + tw / 2f, top + barH * 0.38f, 36f * u, tw - 20f * u)
        val per = s.period.label + if (s.addedMinutes > 0) "  +${s.addedMinutes}'" else ""
        text(c, per, tx + tw / 2f, top + barH * 0.76f, 21f * u, tw - 20f * u, yellow)
        if (s.running) {
            fill.color = red
            c.drawCircle(tx + 16f * u, top + barH * 0.38f, 6f * u, fill)
        }

        // Competición
        var y = top + barH + 8f * u
        if (s.competition.isNotBlank()) {
            txt.textSize = 22f * u
            val cw = txt.measureText(s.competition) + 32f * u
            fill.color = timeBg
            rect.set(left, y, left + cw, y + 34f * u)
            c.drawRoundRect(rect, 8f * u, 8f * u, fill)
            text(c, s.competition, left + cw / 2f, y + 17f * u, 22f * u, cw)
            y += 42f * u
        }

        // Aviso (gol, tarjeta, cambio, periodo)
        if (s.flashUntil > System.currentTimeMillis() && s.flashText.isNotBlank()) {
            txt.textSize = 40f * u
            val fw = txt.measureText(s.flashText) + 70f * u
            fill.color = TimeFmt.parseColor(s.flashColor, Color.RED)
            rect.set(left, y, left + fw, y + 62f * u)
            c.drawRoundRect(rect, 10f * u, 10f * u, fill)
            text(c, s.flashText, left + fw / 2f, y + 31f * u, 40f * u, fw)
        }
    }
}
