package com.futbolpro.recorder.overlay

import android.content.Context
import android.graphics.*
import android.net.Uri
import com.futbolpro.recorder.domain.MatchState
import com.futbolpro.recorder.domain.ScoreboardStyle
import com.futbolpro.recorder.domain.TimeFmt

/** Marcadores estilo TV: mundial, clasico, brasil, copa. Se dibuja igual en la vista previa y en el video. */
class ScoreboardRenderer(private val ctx: Context) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val cond = Typeface.create("sans-serif-condensed", Typeface.BOLD)
    private val bold = Typeface.create("sans-serif-black", Typeface.NORMAL)
    private val rect = RectF()
    private val clip = Path()
    @Volatile private var homeBmp: Bitmap? = null
    @Volatile private var awayBmp: Bitmap? = null

    private val navyTop = Color.parseColor("#1B2438")
    private val navyBot = Color.parseColor("#0A101C")
    private val yellow = Color.parseColor("#FFD600")
    private val red = Color.parseColor("#FF1744")

    // Estado de la pasada actual
    private var u = 1f
    private var k = 1f
    private var sb = true
    private var a = 255
    private var hn = ""
    private var an = ""
    private var hc = Color.BLUE
    private var ac = Color.RED
    private var time = ""
    private var per = ""
    private var outX = 0f
    private var outW = 0f
    private var outBottom = 0f

    fun setBadges(home: String?, away: String?) {
        homeBmp = load(home)
        awayBmp = load(away)
    }

    private fun load(uri: String?): Bitmap? {
        if (uri == null) return null
        return try {
            val u = Uri.parse(uri)
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / (s * 2) >= 256 && o.outHeight / (s * 2) >= 256) s *= 2
            val o2 = BitmapFactory.Options().apply { inSampleSize = s }
            ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) }
        } catch (_: Exception) { null }
    }

    // ---------- utilidades de dibujo ----------
    private fun shade(color: Int, f: Float): Int = Color.rgb(
        (Color.red(color) * f).toInt().coerceIn(0, 255),
        (Color.green(color) * f).toInt().coerceIn(0, 255),
        (Color.blue(color) * f).toInt().coerceIn(0, 255)
    )

    private fun panel(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, top: Int, bot: Int, alpha: Int = 255, gloss: Boolean = true) {
        rect.set(l, t, r, b)
        fill.shader = LinearGradient(0f, t, 0f, b, top, bot, Shader.TileMode.CLAMP)
        fill.alpha = alpha
        c.drawRoundRect(rect, rad, rad, fill)
        fill.shader = null
        if (gloss) {
            c.save()
            clip.reset(); clip.addRoundRect(rect, rad, rad, Path.Direction.CW)
            c.clipPath(clip)
            fill.color = Color.WHITE; fill.alpha = 22
            c.drawRect(l, t, r, t + (b - t) * 0.5f, fill)
            c.restore()
        }
        fill.alpha = 255
    }

    private fun team(c: Canvas, l: Float, t: Float, r: Float, b: Float, color: Int) =
        panel(c, l, t, r, b, 0f, shade(color, 1.2f), shade(color, 0.72f), 255, true)

    private fun text(c: Canvas, t: String, cx: Float, cy: Float, size: Float, maxW: Float, color: Int = Color.WHITE, tf: Typeface = cond) {
        tp.typeface = tf; tp.color = color; tp.textSize = size; tp.letterSpacing = if (tf === bold) 0f else 0.03f
        val w = tp.measureText(t)
        if (w > maxW && w > 0f) tp.textSize = size * maxW / w
        c.drawText(t, cx, cy - (tp.ascent() + tp.descent()) / 2f, tp)
    }

    private fun badge(c: Canvas, bmp: Bitmap?, cx: Float, cy: Float, size: Float, color: Int) {
        if (bmp == null) {
            fill.color = Color.WHITE; c.drawCircle(cx, cy, size * 0.42f, fill)
            fill.color = color; c.drawCircle(cx, cy, size * 0.34f, fill)
            return
        }
        val s = minOf(size / bmp.width, size / bmp.height)
        val w = bmp.width * s
        val h = bmp.height * s
        rect.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
        c.drawBitmap(bmp, null, rect, bmpPaint)
    }

    private fun originX(w: Float, total: Float, pos: String): Float = when (pos) {
        "center" -> (w - total) / 2f
        "right" -> w - 36f * k - total
        else -> 36f * k
    }

    private fun alignX(pos: String, x0: Float, total: Float, item: Float): Float = when (pos) {
        "center" -> x0 + (total - item) / 2f
        "right" -> x0 + total - item
        else -> x0
    }

    private fun timeStrip(c: Canvas, cx: Float, y: Float) {
        panel(c, cx - 125f * u, y, cx + 125f * u, y + 30f * u, 8f * u, Color.parseColor("#141C30"), Color.parseColor("#070B14"), 245)
        text(c, time, cx - 42f * u, y + 15f * u, 22f * u, 100f * u)
        text(c, per, cx + 60f * u, y + 15f * u, 17f * u, 100f * u, yellow)
    }

    // ---------- entrada principal ----------
    fun draw(c: Canvas, w: Float, h: Float, s: MatchState, st: ScoreboardStyle) {
        k = w / 1920f
        u = k * st.scale * 1.35f
        sb = st.showBadges
        a = (st.alpha * 255).toInt().coerceIn(90, 255)
        hn = s.homeShort.ifBlank { s.homeName.take(3).uppercase() }
        an = s.awayShort.ifBlank { s.awayName.take(3).uppercase() }
        hc = TimeFmt.parseColor(s.homeColor, Color.BLUE)
        ac = TimeFmt.parseColor(s.awayColor, Color.RED)
        time = TimeFmt.mmss(s.elapsedMs)
        per = s.period.label + if (s.addedMinutes > 0) "  +${s.addedMinutes}'" else ""
        val top = (h * st.y).coerceAtLeast(24f * k)

        when (st.template) {
            "clasico" -> clasico(c, w, top, st, s)
            "brasil" -> brasil(c, w, top, st, s)
            "copa" -> copa(c, w, top, st, s)
            "fifa" -> fifa(c, w, top, st, s)
            "azul" -> azul(c, w, top, st, s)
            "guinda" -> guinda(c, w, top, st, s)
            "naranja" -> naranja(c, w, top, st, s)
            "champions" -> champ(c, w, top, st, s, Color.parseColor("#18A8FF"), Color.parseColor("#241A6B"), Color.parseColor("#0B0730"), "Champions")
            "cocacola" -> champ(c, w, top, st, s, Color.parseColor("#E4002B"), Color.parseColor("#2A0A14"), Color.parseColor("#0C0509"), "Copa Coca-Cola")
            else -> mundial(c, w, top, st, s)
        }

        var y = outBottom + 8f * u
        if (s.penActive) {
            val bottom = penalties(c, st, y, s)
            y = bottom + 8f * u
        }
        if (s.competition.isNotBlank() && st.template != "copa" && st.template != "champions" && st.template != "cocacola") {
            tp.typeface = cond; tp.textSize = 22f * u
            val cw = tp.measureText(s.competition) + 34f * u
            val cx = alignX(st.pos, outX, outW, cw)
            panel(c, cx, y, cx + cw, y + 34f * u, 8f * u, Color.parseColor("#1B2438"), Color.parseColor("#0A101C"), 235)
            text(c, s.competition, cx + cw / 2f, y + 17f * u, 22f * u, cw)
            y += 42f * u
        }
        if (s.flashUntil > System.currentTimeMillis() && s.flashText.isNotBlank()) {
            tp.typeface = cond; tp.textSize = 38f * u
            val fw = tp.measureText(s.flashText) + 70f * u
            val fx = alignX(st.pos, outX, outW, fw)
            val fc = TimeFmt.parseColor(s.flashColor, Color.RED)
            panel(c, fx, y, fx + fw, y + 60f * u, 12f * u, shade(fc, 1.25f), shade(fc, 0.75f), 255)
            text(c, s.flashText, fx + fw / 2f, y + 30f * u, 38f * u, fw)
        }
    }

    // ---------- Mundial: cronómetro a la izquierda, barra oscura con subrayado de color ----------
    private fun mundial(c: Canvas, w: Float, top: Float, st: ScoreboardStyle, s: MatchState) {
        val hh = 64f * u; val pad = 10f * u; val bd = 44f * u
        val nameW = 104f * u; val scW = 56f * u; val tW = 132f * u; val gap = 6f * u
        val bdW = if (sb) bd + 6f * u else 0f
        val mainW = pad + bdW + nameW + scW * 2 + 8f * u + nameW + bdW + pad
        val total = tW + gap + mainW
        val x0 = originX(w, total, st.pos)
        val cy = top + hh / 2f
        panel(c, x0, top, x0 + tW, top + hh, 14f * u, Color.parseColor("#3B4150"), Color.parseColor("#232731"))
        text(c, time, x0 + tW / 2f + 6f * u, top + hh * 0.40f, 34f * u, tW - 36f * u)
        text(c, per, x0 + tW / 2f, top + hh * 0.80f, 15f * u, tW - 16f * u, yellow)
        if (s.running) { fill.color = red; c.drawCircle(x0 + 17f * u, top + hh * 0.40f, 5f * u, fill) }
        val mx = x0 + tW + gap
        panel(c, mx, top, mx + mainW, top + hh, 14f * u, navyTop, navyBot, a)
        var x = mx + pad
        if (sb) badge(c, homeBmp, x + bd / 2f, cy, bd, hc)
        x += bdW
        text(c, hn, x + nameW / 2f, cy - 4f * u, 34f * u, nameW - 6f * u)
        fill.color = hc; rect.set(x + nameW * 0.12f, top + hh * 0.80f, x + nameW * 0.88f, top + hh * 0.80f + 4f * u)
        c.drawRoundRect(rect, 2f * u, 2f * u, fill)
        x += nameW
        fill.color = Color.parseColor("#080C14"); fill.alpha = 210
        rect.set(x, cy - 25f * u, x + scW * 2 + 8f * u, cy + 25f * u)
        c.drawRoundRect(rect, 9f * u, 9f * u, fill); fill.alpha = 255
        text(c, s.homeScore.toString(), x + scW / 2f, cy, 40f * u, scW - 8f * u, tf = bold)
        text(c, s.awayScore.toString(), x + scW * 1.5f + 8f * u, cy, 40f * u, scW - 8f * u, tf = bold)
        fill.color = Color.parseColor("#44FFFFFF"); rect.set(x + scW + 3.5f * u, cy - 14f * u, x + scW + 4.5f * u, cy + 14f * u)
        c.drawRect(rect, fill)
        x += scW * 2 + 8f * u
        text(c, an, x + nameW / 2f, cy - 4f * u, 34f * u, nameW - 6f * u)
        fill.color = ac; rect.set(x + nameW * 0.12f, top + hh * 0.80f, x + nameW * 0.88f, top + hh * 0.80f + 4f * u)
        c.drawRoundRect(rect, 2f * u, 2f * u, fill)
        x += nameW
        if (sb) badge(c, awayBmp, x + 6f * u + bd / 2f, cy, bd, ac)
        outX = x0; outW = total; outBottom = top + hh
    }

    // ---------- Clásico: bloques de color por equipo, goles al centro, cronómetro azul a la derecha ----------
    private fun clasico(c: Canvas, w: Float, top: Float, st: ScoreboardStyle, s: MatchState) {
        val hh = 58f * u; val pad = 10f * u; val bd = 40f * u
        val nameW = 96f * u; val scW = 60f * u; val tW = 150f * u
        val bdW = if (sb) bd + 8f * u else 0f
        val blockW = pad + bdW + nameW + pad
        val total = blockW * 2 + scW * 2 + tW
        val x0 = originX(w, total, st.pos)
        val cy = top + hh / 2f
        val r = 8f * u
        rect.set(x0, top, x0 + total, top + hh)
        c.save()
        clip.reset(); clip.addRoundRect(rect, r, r, Path.Direction.CW); c.clipPath(clip)
        team(c, x0, top, x0 + blockW, top + hh, hc)
        panel(c, x0 + blockW, top, x0 + blockW + scW * 2, top + hh, 0f, Color.parseColor("#14203A"), Color.parseColor("#08101F"), 255, false)
        val ax = x0 + blockW + scW * 2
        team(c, ax, top, ax + blockW, top + hh, ac)
        panel(c, ax + blockW, top, x0 + total, top + hh, 0f, Color.parseColor("#2A6BF0"), Color.parseColor("#123C9C"), 255, true)
        c.restore()
        if (sb) badge(c, homeBmp, x0 + pad + bd / 2f, cy, bd, hc)
        text(c, hn, x0 + pad + bdW + nameW / 2f, cy, 34f * u, nameW - 6f * u)
        text(c, s.homeScore.toString(), x0 + blockW + scW / 2f, cy, 40f * u, scW - 8f * u, tf = bold)
        text(c, s.awayScore.toString(), x0 + blockW + scW * 1.5f, cy, 40f * u, scW - 8f * u, tf = bold)
        fill.color = Color.parseColor("#66FFFFFF"); c.drawCircle(x0 + blockW + scW, cy, 3f * u, fill)
        text(c, an, ax + pad + nameW / 2f, cy, 34f * u, nameW - 6f * u)
        if (sb) badge(c, awayBmp, ax + pad + nameW + 8f * u + bd / 2f, cy, bd, ac)
        val tx = ax + blockW
        text(c, time, tx + tW / 2f, top + hh * 0.38f, 32f * u, tW - 20f * u)
        text(c, per, tx + tW / 2f, top + hh * 0.78f, 15f * u, tW - 16f * u, yellow)
        if (s.running) { fill.color = red; c.drawCircle(tx + 14f * u, top + hh * 0.38f, 4.5f * u, fill) }
        outX = x0; outW = total; outBottom = top + hh
    }

    // ---------- Brasil: bloques de color, caja blanca de goles y tira de tiempo debajo ----------
    private fun brasil(c: Canvas, w: Float, top: Float, st: ScoreboardStyle, s: MatchState) {
        val hh = 60f * u; val pad = 10f * u; val bd = 46f * u
        val nameW = 96f * u; val boxW = 150f * u
        val bdW = if (sb) bd + 8f * u else 0f
        val blockW = pad + bdW + nameW + pad
        val total = blockW * 2 + boxW
        val x0 = originX(w, total, st.pos)
        val cy = top + hh / 2f
        val r = 9f * u
        // tira de tiempo (detrás de la barra)
        timeStrip(c, x0 + total / 2f, top + hh - 4f * u)
        rect.set(x0, top, x0 + total, top + hh)
        c.save()
        clip.reset(); clip.addRoundRect(rect, r, r, Path.Direction.CW); c.clipPath(clip)
        team(c, x0, top, x0 + blockW, top + hh, hc)
        team(c, x0 + blockW + boxW, top, x0 + total, top + hh, ac)
        panel(c, x0 + blockW, top, x0 + blockW + boxW, top + hh, 0f, Color.WHITE, Color.parseColor("#D9E0EC"), 255, false)
        c.restore()
        if (sb) badge(c, homeBmp, x0 + pad + bd / 2f, cy, bd, hc)
        text(c, hn, x0 + pad + bdW + nameW / 2f, cy, 34f * u, nameW - 6f * u)
        text(c, "${s.homeScore}  -  ${s.awayScore}", x0 + total / 2f, cy, 40f * u, boxW - 16f * u, Color.parseColor("#0B1630"), bold)
        val ax = x0 + blockW + boxW
        text(c, an, ax + pad + nameW / 2f, cy, 34f * u, nameW - 6f * u)
        if (sb) badge(c, awayBmp, ax + pad + nameW + 8f * u + bd / 2f, cy, bd, ac)
        outX = x0; outW = total; outBottom = top + hh + 26f * u
    }

    // ---------- Copa: barra central con goles en los colores de cada equipo ----------
    private fun copa(c: Canvas, w: Float, top: Float, st: ScoreboardStyle, s: MatchState) {
        val hh = 62f * u; val pad = 12f * u; val bd = 44f * u
        val nameW = 150f * u; val scW = 58f * u
        val bdW = if (sb) bd + 8f * u else 0f
        val total = pad + bdW + nameW + scW * 2 + nameW + bdW + pad
        val x0 = originX(w, total, st.pos)
        val r = 16f * u
        var my = top
        if (s.competition.isNotBlank()) {
            panel(c, x0 + total * 0.2f, top, x0 + total * 0.8f, top + 30f * u, 10f * u, Color.parseColor("#2A3248"), Color.parseColor("#141A2A"), 245)
            text(c, s.competition, x0 + total / 2f, top + 15f * u, 18f * u, total * 0.58f)
            my = top + 26f * u
        }
        val cy = my + hh / 2f
        timeStrip(c, x0 + total / 2f, my + hh - 4f * u)
        panel(c, x0, my, x0 + total, my + hh, r, navyTop, navyBot, a)
        var x = x0 + pad
        if (sb) badge(c, homeBmp, x + bd / 2f, cy, bd, hc)
        x += bdW
        text(c, hn, x + nameW / 2f, cy, 38f * u, nameW - 8f * u)
        x += nameW
        rect.set(x, cy - 28f * u, x + scW * 2, cy + 28f * u)
        c.save()
        clip.reset(); clip.addRoundRect(rect, 10f * u, 10f * u, Path.Direction.CW); c.clipPath(clip)
        team(c, x, cy - 28f * u, x + scW, cy + 28f * u, hc)
        team(c, x + scW, cy - 28f * u, x + scW * 2, cy + 28f * u, ac)
        c.restore()
        text(c, s.homeScore.toString(), x + scW / 2f, cy, 40f * u, scW - 8f * u, tf = bold)
        text(c, s.awayScore.toString(), x + scW * 1.5f, cy, 40f * u, scW - 8f * u, tf = bold)
        x += scW * 2
        text(c, an, x + nameW / 2f, cy, 38f * u, nameW - 8f * u)
        x += nameW
        if (sb) badge(c, awayBmp, x + 8f * u + bd / 2f, cy, bd, ac)
        outX = x0; outW = total; outBottom = my + hh + 26f * u
    }

    private val ink = Color.parseColor("#0B1630")
    private val gray = Color.parseColor("#6B7690")

    // ---------- Blanco FIFA: píldora blanca, cronómetro a la izquierda, goles en caja oscura ----------
    private fun fifa(c: Canvas, w: Float, top: Float, st: ScoreboardStyle, s: MatchState) {
        val hh = 66f * u; val pad = 18f * u; val bd = 46f * u
        val nameW = 100f * u; val scW = 54f * u; val tW = 118f * u
        val bdW = if (sb) bd + 8f * u else 0f
        val total = pad + tW + 10f * u + bdW + nameW + scW * 2 + 6f * u + nameW + bdW + pad
        val x0 = originX(w, total, st.pos)
        val cy = top + hh / 2f
        panel(c, x0, top, x0 + total, top + hh, hh / 2f, Color.WHITE, Color.parseColor("#DCE2EE"), a, false)
        var x = x0 + pad
        text(c, time, x + tW / 2f, cy - 6f * u, 32f * u, tW, ink, cond)
        text(c, per, x + tW / 2f, cy + 17f * u, 14f * u, tW, gray, cond)
        if (s.running) { fill.color = red; c.drawCircle(x - 7f * u, cy - 6f * u, 4.5f * u, fill) }
        x += tW + 10f * u
        fill.color = Color.parseColor("#CBD2E0"); rect.set(x - 5f * u, cy - 20f * u, x - 4f * u, cy + 20f * u); c.drawRect(rect, fill)
        if (sb) badge(c, homeBmp, x + bd / 2f, cy, bd, hc)
        x += bdW
        text(c, hn, x + nameW / 2f, cy - 3f * u, 34f * u, nameW - 6f * u, ink)
        fill.color = hc; rect.set(x + nameW * 0.15f, cy + 16f * u, x + nameW * 0.85f, cy + 20f * u); c.drawRoundRect(rect, 2f * u, 2f * u, fill)
        x += nameW
        panel(c, x, cy - 26f * u, x + scW * 2 + 6f * u, cy + 26f * u, 13f * u, navyTop, navyBot, 255, true)
        text(c, s.homeScore.toString(), x + scW / 2f, cy, 38f * u, scW - 8f * u, tf = bold)
        text(c, s.awayScore.toString(), x + scW * 1.5f + 6f * u, cy, 38f * u, scW - 8f * u, tf = bold)
        x += scW * 2 + 6f * u
        text(c, an, x + nameW / 2f, cy - 3f * u, 34f * u, nameW - 6f * u, ink)
        fill.color = ac; rect.set(x + nameW * 0.15f, cy + 16f * u, x + nameW * 0.85f, cy + 20f * u); c.drawRoundRect(rect, 2f * u, 2f * u, fill)
        x += nameW
        if (sb) badge(c, awayBmp, x + 4f * u + bd / 2f, cy, bd, ac)
        outX = x0; outW = total; outBottom = top + hh
    }

    // ---------- Azul TV: barra azul, goles en cajas oscuras y cronómetro a la derecha ----------
    private fun azul(c: Canvas, w: Float, top: Float, st: ScoreboardStyle, s: MatchState) {
        val hh = 60f * u; val pad = 12f * u; val bd = 42f * u
        val nameW = 92f * u; val sc = 52f * u; val tW = 130f * u; val gap = 8f * u; val gT = 4f * u
        val bdW = if (sb) bd + 8f * u else 0f
        val mainW = pad + bdW + nameW + sc + gap + sc + nameW + bdW + pad
        val total = mainW + gT + tW
        val x0 = originX(w, total, st.pos)
        val cy = top + hh / 2f
        val r = 9f * u
        panel(c, x0, top, x0 + mainW, top + hh, r, Color.parseColor("#2C63F2"), Color.parseColor("#1236A6"), a)
        var x = x0 + pad
        if (sb) badge(c, homeBmp, x + bd / 2f, cy, bd, hc)
        x += bdW
        text(c, hn, x + nameW / 2f, cy, 34f * u, nameW - 6f * u)
        x += nameW
        panel(c, x, cy - 25f * u, x + sc, cy + 25f * u, 9f * u, Color.parseColor("#141E48"), Color.parseColor("#080D24"), 255, true)
        text(c, s.homeScore.toString(), x + sc / 2f, cy, 38f * u, sc - 8f * u, tf = bold)
        x += sc + gap
        panel(c, x, cy - 25f * u, x + sc, cy + 25f * u, 9f * u, Color.parseColor("#141E48"), Color.parseColor("#080D24"), 255, true)
        text(c, s.awayScore.toString(), x + sc / 2f, cy, 38f * u, sc - 8f * u, tf = bold)
        x += sc
        text(c, an, x + nameW / 2f, cy, 34f * u, nameW - 6f * u)
        x += nameW
        if (sb) badge(c, awayBmp, x + 4f * u + bd / 2f, cy, bd, ac)
        val tx = x0 + mainW + gT
        panel(c, tx, top, tx + tW, top + hh, r, Color.parseColor("#5C8BFF"), Color.parseColor("#2F5BD8"))
        text(c, time, tx + tW / 2f + 4f * u, top + hh * 0.38f, 32f * u, tW - 28f * u)
        text(c, per, tx + tW / 2f, top + hh * 0.78f, 15f * u, tW - 16f * u, yellow)
        if (s.running) { fill.color = red; c.drawCircle(tx + 14f * u, top + hh * 0.38f, 4.5f * u, fill) }
        outX = x0; outW = total; outBottom = top + hh
    }

    // ---------- Guinda: barra guinda con cronómetro oscuro a la izquierda, rombo entre los goles y línea dorada ----------
    private fun guinda(c: Canvas, w: Float, top: Float, st: ScoreboardStyle, s: MatchState) {
        val hh = 58f * u; val pad = 12f * u; val bd = 40f * u
        val nameW = 92f * u; val sc = 48f * u; val dia = 28f * u; val tW = 126f * u
        val bdW = if (sb) bd + 8f * u else 0f
        val total = tW + pad + bdW + nameW + sc + dia + sc + nameW + bdW + pad
        val x0 = originX(w, total, st.pos)
        val cy = top + hh / 2f
        val r = 7f * u
        panel(c, x0, top, x0 + total, top + hh, r, Color.parseColor("#A12C40"), Color.parseColor("#5A1322"), a)
        panel(c, x0, top, x0 + tW, top + hh, r, Color.parseColor("#4A0E1B"), Color.parseColor("#2A0710"), 255, false)
        text(c, time, x0 + tW / 2f, top + hh * 0.40f, 32f * u, tW - 18f * u)
        text(c, per, x0 + tW / 2f, top + hh * 0.80f, 14f * u, tW - 16f * u, yellow)
        if (s.running) { fill.color = red; c.drawCircle(x0 + 13f * u, top + hh * 0.40f, 4.5f * u, fill) }
        var x = x0 + tW + pad
        if (sb) badge(c, homeBmp, x + bd / 2f, cy, bd, hc)
        x += bdW
        text(c, hn, x + nameW / 2f, cy, 34f * u, nameW - 6f * u)
        x += nameW
        text(c, s.homeScore.toString(), x + sc / 2f, cy, 40f * u, sc - 6f * u, tf = bold)
        x += sc
        val dx = x + dia / 2f
        val d = 7f * u
        clip.reset(); clip.moveTo(dx, cy - d); clip.lineTo(dx + d, cy); clip.lineTo(dx, cy + d); clip.lineTo(dx - d, cy); clip.close()
        fill.color = Color.parseColor("#E6B84D"); c.drawPath(clip, fill)
        x += dia
        text(c, s.awayScore.toString(), x + sc / 2f, cy, 40f * u, sc - 6f * u, tf = bold)
        x += sc
        text(c, an, x + nameW / 2f, cy, 34f * u, nameW - 6f * u)
        x += nameW
        if (sb) badge(c, awayBmp, x + 4f * u + bd / 2f, cy, bd, ac)
        fill.color = Color.parseColor("#E6B84D"); rect.set(x0, top + hh, x0 + total, top + hh + 3f * u); c.drawRect(rect, fill)
        outX = x0; outW = total; outBottom = top + hh + 3f * u
    }

    // ---------- Naranja 2010: barra blanca redonda con el cronómetro en una píldora naranja arriba ----------
    private fun naranja(c: Canvas, w: Float, top: Float, st: ScoreboardStyle, s: MatchState) {
        val hh = 64f * u; val pad = 18f * u; val bd = 44f * u
        val nameW = 100f * u; val sc = 50f * u; val colon = 24f * u
        val bdW = if (sb) bd + 8f * u else 0f
        val total = pad + bdW + nameW + sc + colon + sc + nameW + bdW + pad
        val x0 = originX(w, total, st.pos)
        val pillH = 38f * u; val pillW = 210f * u
        val my = top + 22f * u
        val cy = my + hh / 2f + 4f * u
        panel(c, x0, my, x0 + total, my + hh, hh / 2f, Color.WHITE, Color.parseColor("#DFE4EE"), a, false)
        var x = x0 + pad
        if (sb) badge(c, homeBmp, x + bd / 2f, cy, bd, hc)
        x += bdW
        text(c, hn, x + nameW / 2f, cy, 36f * u, nameW - 6f * u, ink)
        x += nameW
        text(c, s.homeScore.toString(), x + sc / 2f, cy, 40f * u, sc - 6f * u, ink, bold)
        x += sc
        text(c, ":", x + colon / 2f, cy - 2f * u, 34f * u, colon, gray, bold)
        x += colon
        text(c, s.awayScore.toString(), x + sc / 2f, cy, 40f * u, sc - 6f * u, ink, bold)
        x += sc
        text(c, an, x + nameW / 2f, cy, 36f * u, nameW - 6f * u, ink)
        x += nameW
        if (sb) badge(c, awayBmp, x + 4f * u + bd / 2f, cy, bd, ac)
        val pcx = x0 + total / 2f
        panel(c, pcx - pillW / 2f, top, pcx + pillW / 2f, top + pillH, 15f * u, Color.parseColor("#FFA21F"), Color.parseColor("#D4480A"), 255, true)
        text(c, time, pcx - 22f * u, top + pillH / 2f, 28f * u, 110f * u)
        text(c, per, pcx + 68f * u, top + pillH / 2f, 16f * u, 62f * u, Color.WHITE)
        if (s.running) { fill.color = Color.WHITE; c.drawCircle(pcx - pillW / 2f + 16f * u, top + pillH / 2f, 4.5f * u, fill) }
        outX = x0; outW = total; outBottom = my + hh
    }

    // ---------- Champions / Copa Coca-Cola: barra azul noche con línea de color, cronómetro de color y etiqueta de torneo ----------
    private fun champ(c: Canvas, w: Float, top: Float, st: ScoreboardStyle, s: MatchState, acc: Int, barTop: Int, barBot: Int, defLabel: String) {
        val hh = 68f * u; val pad = 14f * u; val bd = 48f * u
        val nameW = 100f * u; val sc = 52f * u; val tW = 128f * u; val gap = 6f * u
        val bdW = if (sb) bd + 8f * u else 0f
        val total = tW + gap + pad + bdW + nameW + sc + 8f * u + sc + nameW + bdW + pad
        val x0 = originX(w, total, st.pos)
        val cy = top + hh / 2f
        val r = 12f * u
        panel(c, x0, top, x0 + total, top + hh, r, barTop, barBot, a)
        c.save()
        rect.set(x0, top, x0 + total, top + hh)
        clip.reset(); clip.addRoundRect(rect, r, r, Path.Direction.CW); c.clipPath(clip)
        fill.color = acc; c.drawRect(x0, top, x0 + total, top + 3.5f * u, fill)
        c.restore()
        panel(c, x0, top, x0 + tW, top + hh, r, shade(acc, 1.15f), shade(acc, 0.7f))
        text(c, time, x0 + tW / 2f + 4f * u, top + hh * 0.40f, 36f * u, tW - 30f * u)
        text(c, per, x0 + tW / 2f, top + hh * 0.80f, 15f * u, tW - 16f * u, Color.WHITE)
        if (s.running) { fill.color = Color.WHITE; c.drawCircle(x0 + 16f * u, top + hh * 0.40f, 4.8f * u, fill) }
        var x = x0 + tW + gap + pad
        if (sb) badge(c, homeBmp, x + bd / 2f, cy, bd, hc)
        x += bdW
        text(c, hn, x + nameW / 2f, cy - 3f * u, 36f * u, nameW - 6f * u)
        fill.color = hc; rect.set(x + nameW * 0.12f, cy + 17f * u, x + nameW * 0.88f, cy + 21f * u); c.drawRoundRect(rect, 2f * u, 2f * u, fill)
        x += nameW
        panel(c, x, cy - 27f * u, x + sc, cy + 27f * u, 10f * u, Color.WHITE, Color.parseColor("#CDD3E2"), 255, false)
        text(c, s.homeScore.toString(), x + sc / 2f, cy, 42f * u, sc - 8f * u, Color.parseColor("#0B1230"), bold)
        x += sc + 8f * u
        panel(c, x, cy - 27f * u, x + sc, cy + 27f * u, 10f * u, Color.WHITE, Color.parseColor("#CDD3E2"), 255, false)
        text(c, s.awayScore.toString(), x + sc / 2f, cy, 42f * u, sc - 8f * u, Color.parseColor("#0B1230"), bold)
        x += sc
        text(c, an, x + nameW / 2f, cy - 3f * u, 36f * u, nameW - 6f * u)
        fill.color = ac; rect.set(x + nameW * 0.12f, cy + 17f * u, x + nameW * 0.88f, cy + 21f * u); c.drawRoundRect(rect, 2f * u, 2f * u, fill)
        x += nameW
        if (sb) badge(c, awayBmp, x + 4f * u + bd / 2f, cy, bd, ac)
        val label = (if (s.competition.isNotBlank()) s.competition else defLabel).uppercase()
        tp.typeface = cond; tp.textSize = 21f * u; tp.letterSpacing = 0.06f
        val lw = tp.measureText(label) + 36f * u
        val lx = x0 + tW + gap
        panel(c, lx, top + hh - 2f * u, lx + lw, top + hh + 30f * u, 8f * u, shade(acc, 1.15f), shade(acc, 0.7f), 255, false)
        text(c, label, lx + lw / 2f, top + hh + 15f * u, 21f * u, lw)
        outX = x0; outW = total; outBottom = top + hh + 30f * u
    }

    // ---------- Tanda de penales: puntos verdes (gol), rojos (fallo) y anillos (pendiente) ----------
    private fun penalties(c: Canvas, st: ScoreboardStyle, y: Float, s: MatchState): Float {
        val n = maxOf(s.penRounds, s.penHome.size, s.penAway.size)
        val d = 30f * u; val g = 9f * u
        val labelW = 104f * u; val scoreW = 64f * u
        val rowH = 44f * u
        val width = labelW + n * (d + g) + scoreW + 22f * u
        val h = rowH * 2 + 16f * u
        val x = alignX(st.pos, outX, outW, width)
        panel(c, x, y, x + width, y + h, 14f * u, Color.parseColor("#141C30"), Color.parseColor("#070B14"), 240)
        for (row in 0..1) {
            val list = if (row == 0) s.penHome else s.penAway
            val cy = y + 8f * u + rowH * row + rowH / 2f
            text(c, if (row == 0) hn else an, x + 14f * u + labelW / 2f, cy, 28f * u, labelW - 10f * u)
            for (i in 0 until n) {
                val cx = x + 14f * u + labelW + i * (d + g) + d / 2f
                when {
                    i < list.size && list[i] == 1 -> { fill.color = Color.parseColor("#00D084"); c.drawCircle(cx, cy, d / 2f, fill) }
                    i < list.size -> {
                        fill.color = red; c.drawCircle(cx, cy, d / 2f, fill)
                        tp.color = Color.WHITE; tp.typeface = bold; tp.textSize = d * 0.7f; tp.letterSpacing = 0f
                        c.drawText("X", cx, cy - (tp.ascent() + tp.descent()) / 2f, tp)
                    }
                    else -> {
                        fill.color = Color.parseColor("#4A5675"); c.drawCircle(cx, cy, d / 2f, fill)
                        fill.color = Color.parseColor("#141C30"); c.drawCircle(cx, cy, d / 2f - 3f * u, fill)
                    }
                }
            }
            text(c, list.sum().toString(), x + width - 14f * u - scoreW / 2f, cy, 34f * u, scoreW, Color.WHITE, bold)
        }
        return y + h
    }
}
