package com.futbolpro.recorder.overlay

import android.content.Context
import android.graphics.*
import android.net.Uri
import com.futbolpro.recorder.domain.MatchState
import com.futbolpro.recorder.domain.ScoreboardStyle
import com.futbolpro.recorder.domain.TimeFmt

/** Marcadores estilo TV: mundial, clasico, brasil, copa. Se dibuja igual en la vista previa y en el video. */
class ScoreboardRenderer(private val ctx: Context) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val cond = Typeface.create("sans-serif-condensed", Typeface.BOLD)
    private val bold = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    private val rect = RectF()
    private val clip = Path()
    @Volatile private var homeBmp: Bitmap? = null
    @Volatile private var awayBmp: Bitmap? = null

    private val navyTop = Color.parseColor("#1B2438")
    private val navyBot = Color.parseColor("#0A101C")
    private val yellow = Color.parseColor("#FFD600")
    private val red = Color.parseColor("#FF1744")

    // Estado de la pasada actual
    private var u = 1f
    private var k = 1f
    private var sb = true
    private var a = 255
    private var hn = ""
    private var an = ""
    private var hc = Color.BLUE
    private var ac = Color.RED
    private var time = ""
    private var per = ""
    private var outX = 0f
    private var outW = 0f
    private var outBottom = 0f

    fun setBadges(home: String?, away: String?) {
        homeBmp = load(home)
        awayBmp = load(away)
    }

    private fun load(uri: String?): Bitmap? {
        if (uri == null) return null
        return try {
            val u = Uri.parse(uri)
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / (s * 2) >= 256 && o.outHeight / (s * 2) >= 256) s *= 2
            val o2 = BitmapFactory.Options().apply { inSampleSize = s }
            ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) }
        } catch (_: Exception) { null }
    }

    // ---------- utilidades de dibujo ----------
    private fun shade(color: Int, f: Float): Int = Color.rgb(
        (Color.red(color) * f).toInt().coerceIn(0, 255),
        (Color.green(color) * f).toInt().coerceIn(0, 255),
        (Color.blue(color) * f).toInt().coerceIn(0, 255)
    )

    private fun panel(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, top: Int, bot: Int, alpha: Int = 255, gloss: Boolean = true) {
        rect.set(l, t, r, b)
        fill.shader = LinearGradient(0f, t, 0f, b, top, bot, Shader.TileMode.CLAMP)
        fill.alpha = alpha
        c.drawRoundRect(rect, rad, rad, fill)
        fill.shader = null
        if (gloss) {
            c.save()
            clip.reset(); clip.addRoundRect(rect, rad, rad, Path.Direction.CW)
            c.clipPath(clip)
            fill.color = Color.WHITE; fill.alpha = 22
            c.drawRect(l, t, r, t + (b - t) * 0.5f, fill)
            c.restore()
        }
        fill.alpha = 255
    }

    private fun team(c: Canvas, l: Float, t: Float, r: Float, b: Float, color: Int) =
        panel(c, l, t, r, b, 0f, shade(color, 1.2f), shade(color, 0.72f), 255, true)

    private fun text(c: Canvas, t: String, cx: Float, cy: Float, size: Float, maxW: Float, color: Int = Color.WHITE, tf: Typeface = cond) {
        tp.typeface = tf; tp.color = color; tp.textSize = size
        val w = tp.measureText(t)
        if (w > maxW && w > 0f) tp.textSize = size * maxW / w
        c.drawText(t, cx, cy - (tp.ascent() + tp.descent()) / 2f, tp)
    }

    private fun badge(c: Canvas, bmp: Bitmap?, cx: Float, cy: Float, size: Float, color: Int) {
        if (bmp == null) {
            fill.color = Color.WHITE; c.drawCircle(cx, cy, size * 0.42f, fill)
            fill.color = color; c.drawCircle(cx, cy, size * 0.34f, fill)
            return
        }
        val s = minOf(size / bmp.width, size / bmp.height)
        val w = bmp.width * s
        val h = bmp.height * s
        rect.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
        c.drawBitmap(bmp, null, rect, bmpPaint)
    }

    private fun originX(w: Float, total: Float, pos: String): Float = when (pos) {
        "center" -> (w - total) / 2f
        "right" -> w - 36f * k - total
        else -> 36f * k
    }

    private fun alignX(pos: String, x0: Float, total: Float, item: Float): Float = when (pos) {
        "center" -> x0 + (total - item) / 2f
        "right" -> x0 + total - item
        else -> x0
    }

    private fun timeStrip(c: Canvas, cx: Float, y: Float) {
        panel(c, cx - 125f * u, y, cx + 125f * u, y + 30f * u, 8f * u, Color.parseColor("#141C30"), Color.parseColor("#070B14"), 245)
        text(c, time, cx - 42f * u, y + 15f * u, 22f * u, 100f * u)
        text(c, per, cx + 60f * u, y + 15f * u, 17f * u, 100f * u, yellow)
    }

    // ---------- entrada principal ----------
    fun draw(c: Canvas, w: Float, h: Float, s: MatchState, st: ScoreboardStyle) {
        k = w / 1920f
        u = k * st.scale
        sb = st.showBadges
        a = (st.alpha * 255).toInt().coerceIn(90, 255)
        hn = s.homeShort.ifBlank { s.homeName.take(3).uppercase() }
        an = s.awayShort.ifBlank { s.awayName.take(3).uppercase() }
        hc = TimeFmt.parseColor(s.homeColor, Color.BLUE)
        ac = TimeFmt.parseColor(s.awayColor, Color.RED)
        time = TimeFmt.mmss(s.elapsedMs)
        per = s.period.label + if (s.addedMinutes > 0) "  +${s.addedMinutes}'" else ""
        val top = (h * st.y).coerceAtLeast(24f * k)

        when (st.template) {
            "clasico" -> clasico(c, w, top, st, s)
            "brasil" -> brasil(c, w, top, st, s)
            "copa" -> copa(c, w, top, st, s)
            else -> mundial(c, w, top, st, s)
        }

        var y = outBottom + 8f * u
        if (s.competition.isNotBlank() && st.template != "copa") {
            tp.typeface = cond; tp.textSize = 22f * u
            val cw = tp.measureText(s.competition) + 34f * u
            val cx = alignX(st.pos, outX, outW, cw)
            panel(c, cx, y, cx + cw, y + 34f * u, 8f * u, Color.parseColor("#1B2438"), Color.parseColor("#0A101C"), 235)
            text(c, s.competition, cx + cw / 2f, y + 17f * u, 22f * u, cw)
            y += 42f * u
        }
        if (s.flashUntil > System.currentTimeMillis() && s.flashText.isNotBlank()) {
            tp.typeface = cond; tp.textSize = 38f * u
            val fw = tp.measureText(s.flashText) + 70f * u
            val fx = alignX(st.pos, outX, outW, fw)
            val fc = TimeFmt.parseColor(s.flashColor, Color.RED)
            panel(c, fx, y, fx + fw, y + 60f * u, 12f * u, shade(fc, 1.25f), shade(fc, 0.75f), 255)
            text(c, s.flashText, fx + fw / 2f, y + 30f * u, 38f * u, fw)
        }
    }

    // ---------- Mundial: cronómetro a la izquierda, barra oscura con subrayado de color ----------
    private fun mundial(c: Canvas, w: Float, top: Float, st: ScoreboardStyle, s: MatchState) {
        val hh = 64f * u; val pad = 10f * u; val bd = 44f * u
        val nameW = 104f * u; val scW = 56f * u; val tW = 132f * u; val gap = 6f * u
        val bdW = if (sb) bd + 6f * u else 0f
        val mainW = pad + bdW + nameW + scW * 2 + 8f * u + nameW + bdW + pad
        val total = tW + gap + mainW
        val x0 = originX(w, total, st.pos)
        val cy = top + hh / 2f
        panel(c, x0, top, x0 + tW, top + hh, 14f * u, Color.parseColor("#3B4150"), Color.parseColor("#232731"))
        text(c, time, x0 + tW / 2f + 6f * u, top + hh * 0.40f, 34f * u, tW - 36f * u)
        text(c, per, x0 + tW / 2f, top + hh * 0.80f, 15f * u, tW - 16f * u, yellow)
        if (s.running) { fill.color = red; c.drawCircle(x0 + 17f * u, top + hh * 0.40f, 5f * u, fill) }
        val mx = x0 + tW + gap
        panel(c, mx, top, mx + mainW, top + hh, 14f * u, navyTop, navyBot, a)
        var x = mx + pad
        if (sb) badge(c, homeBmp, x + bd / 2f, cy, bd, hc)
        x += bdW
        text(c, hn, x + nameW / 2f, cy - 4f * u, 34f * u, nameW - 6f * u)
        fill.color = hc; rect.set(x + nameW * 0.12f, top + hh * 0.80f, x + nameW * 0.88f, top + hh * 0.80f + 4f * u)
        c.drawRoundRect(rect, 2f * u, 2f * u, fill)
        x += nameW
        fill.color = Color.parseColor("#080C14"); fill.alpha = 210
        rect.set(x, cy - 25f * u, x + scW * 2 + 8f * u, cy + 25f * u)
        c.drawRoundRect(rect, 9f * u, 9f * u, fill); fill.alpha = 255
        text(c, s.homeScore.toString(), x + scW / 2f, cy, 40f * u, scW - 8f * u, tf = bold)
        text(c, s.awayScore.toString(), x + scW * 1.5f + 8f * u, cy, 40f * u, scW - 8f * u, tf = bold)
        fill.color = Color.parseColor("#44FFFFFF"); rect.set(x + scW + 3.5f * u, cy - 14f * u, x + scW + 4.5f * u, cy + 14f * u)
        c.drawRect(rect, fill)
        x += scW * 2 + 8f * u
        text(c, an, x + nameW / 2f, cy - 4f * u, 34f * u, nameW - 6f * u)
        fill.color = ac; rect.set(x + nameW * 0.12f, top + hh * 0.80f, x + nameW * 0.88f, top + hh * 0.80f + 4f * u)
        c.drawRoundRect(rect, 2f * u, 2f * u, fill)
        x += nameW
        if (sb) badge(c, awayBmp, x + 6f * u + bd / 2f, cy, bd, ac)
        outX = x0; outW = total; outBottom = top + hh
    }

    // ---------- Clásico: bloques de color por equipo, goles al centro, cronómetro azul a la derecha ----------
    private fun clasico(c: Canvas, w: Float, top: Float, st: ScoreboardStyle, s: MatchState) {
        val hh = 58f * u; val pad = 10f * u; val bd = 40f * u
        val nameW = 96f * u; val scW = 60f * u; val tW = 150f * u
        val bdW = if (sb) bd + 8f * u else 0f
        val blockW = pad + bdW + nameW + pad
        val total = blockW * 2 + scW * 2 + tW
        val x0 = originX(w, total, st.pos)
        val cy = top + hh / 2f
        val r = 8f * u
        rect.set(x0, top, x0 + total, top + hh)
        c.save()
        clip.reset(); clip.addRoundRect(rect, r, r, Path.Direction.CW); c.clipPath(clip)
        team(c, x0, top, x0 + blockW, top + hh, hc)
        panel(c, x0 + blockW, top, x0 + blockW + scW * 2, top + hh, 0f, Color.parseColor("#14203A"), Color.parseColor("#08101F"), 255, false)
        val ax = x0 + blockW + scW * 2
        team(c, ax, top, ax + blockW, top + hh, ac)
        panel(c, ax + blockW, top, x0 + total, top + hh, 0f, Color.parseColor("#2A6BF0"), Color.parseColor("#123C9C"), 255, true)
        c.restore()
        if (sb) badge(c, homeBmp, x0 + pad + bd / 2f, cy, bd, hc)
        text(c, hn, x0 + pad + bdW + nameW / 2f, cy, 34f * u, nameW - 6f * u)
        text(c, s.homeScore.toString(), x0 + blockW + scW / 2f, cy, 40f * u, scW - 8f * u, tf = bold)
        text(c, s.awayScore.toString(), x0 + blockW + scW * 1.5f, cy, 40f * u, scW - 8f * u, tf = bold)
        fill.color = Color.parseColor("#66FFFFFF"); c.drawCircle(x0 + blockW + scW, cy, 3f * u, fill)
        text(c, an, ax + pad + nameW / 2f, cy, 34f * u, nameW - 6f * u)
        if (sb) badge(c, awayBmp, ax + pad + nameW + 8f * u + bd / 2f, cy, bd, ac)
        val tx = ax + blockW
        text(c, time, tx + tW / 2f, top + hh * 0.38f, 32f * u, tW - 20f * u)
        text(c, per, tx + tW / 2f, top + hh * 0.78f, 15f * u, tW - 16f * u, yellow)
        if (s.running) { fill.color = red; c.drawCircle(tx + 14f * u, top + hh * 0.38f, 4.5f * u, fill) }
        outX = x0; outW = total; outBottom = top + hh
    }

    // ---------- Brasil: bloques de color, caja blanca de goles y tira de tiempo debajo ----------
    private fun brasil(c: Canvas, w: Float, top: Float, st: ScoreboardStyle, s: MatchState) {
        val hh = 60f * u; val pad = 10f * u; val bd = 46f * u
        val nameW = 96f * u; val boxW = 150f * u
        val bdW = if (sb) bd + 8f * u else 0f
        val blockW = pad + bdW + nameW + pad
        val total = blockW * 2 + boxW
        val x0 = originX(w, total, st.pos)
        val cy = top + hh / 2f
        val r = 9f * u
        // tira de tiempo (detrás de la barra)
        timeStrip(c, x0 + total / 2f, top + hh - 4f * u)
        rect.set(x0, top, x0 + total, top + hh)
        c.save()
        clip.reset(); clip.addRoundRect(rect, r, r, Path.Direction.CW); c.clipPath(clip)
        team(c, x0, top, x0 + blockW, top + hh, hc)
        team(c, x0 + blockW + boxW, top, x0 + total, top + hh, ac)
        panel(c, x0 + blockW, top, x0 + blockW + boxW, top + hh, 0f, Color.WHITE, Color.parseColor("#D9E0EC"), 255, false)
        c.restore()
        if (sb) badge(c, homeBmp, x0 + pad + bd / 2f, cy, bd, hc)
        text(c, hn, x0 + pad + bdW + nameW / 2f, cy, 34f * u, nameW - 6f * u)
        text(c, "${s.homeScore}  -  ${s.awayScore}", x0 + total / 2f, cy, 40f * u, boxW - 16f * u, Color.parseColor("#0B1630"), bold)
        val ax = x0 + blockW + boxW
        text(c, an, ax + pad + nameW / 2f, cy, 34f * u, nameW - 6f * u)
        if (sb) badge(c, awayBmp, ax + pad + nameW + 8f * u + bd / 2f, cy, bd, ac)
        outX = x0; outW = total; outBottom = top + hh + 26f * u
    }

    // ---------- Copa: barra central con goles en los colores de cada equipo ----------
    private fun copa(c: Canvas, w: Float, top: Float, st: ScoreboardStyle, s: MatchState) {
        val hh = 62f * u; val pad = 12f * u; val bd = 44f * u
        val nameW = 150f * u; val scW = 58f * u
        val bdW = if (sb) bd + 8f * u else 0f
        val total = pad + bdW + nameW + scW * 2 + nameW + bdW + pad
        val x0 = originX(w, total, st.pos)
        val r = 16f * u
        var my = top
        if (s.competition.isNotBlank()) {
            panel(c, x0 + total * 0.2f, top, x0 + total * 0.8f, top + 30f * u, 10f * u, Color.parseColor("#2A3248"), Color.parseColor("#141A2A"), 245)
            text(c, s.competition, x0 + total / 2f, top + 15f * u, 18f * u, total * 0.58f)
            my = top + 26f * u
        }
        val cy = my + hh / 2f
        timeStrip(c, x0 + total / 2f, my + hh - 4f * u)
        panel(c, x0, my, x0 + total, my + hh, r, navyTop, navyBot, a)
        var x = x0 + pad
        if (sb) badge(c, homeBmp, x + bd / 2f, cy, bd, hc)
        x += bdW
        text(c, hn, x + nameW / 2f, cy, 38f * u, nameW - 8f * u)
        x += nameW
        rect.set(x, cy - 28f * u, x + scW * 2, cy + 28f * u)
        c.save()
        clip.reset(); clip.addRoundRect(rect, 10f * u, 10f * u, Path.Direction.CW); c.clipPath(clip)
        team(c, x, cy - 28f * u, x + scW, cy + 28f * u, hc)
        team(c, x + scW, cy - 28f * u, x + scW * 2, cy + 28f * u, ac)
        c.restore()
        text(c, s.homeScore.toString(), x + scW / 2f, cy, 40f * u, scW - 8f * u, tf = bold)
        text(c, s.awayScore.toString(), x + scW * 1.5f, cy, 40f * u, scW - 8f * u, tf = bold)
        x += scW * 2
        text(c, an, x + nameW / 2f, cy, 38f * u, nameW - 8f * u)
        x += nameW
        if (sb) badge(c, awayBmp, x + 8f * u + bd / 2f, cy, bd, ac)
        outX = x0; outW = total; outBottom = my + hh + 26f * u
    }
}
