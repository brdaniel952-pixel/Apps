package com.futbolpro.recorder.data

import androidx.room.*

@Dao
interface TeamDao {
    @Query("SELECT * FROM teams ORDER BY name")
    suspend fun getAll(): List<TeamEntity>
    @Query("SELECT * FROM teams WHERE id = :id")
    suspend fun getById(id: Long): TeamEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(team: TeamEntity): Long
    @Update suspend fun update(team: TeamEntity)
    @Delete suspend fun delete(team: TeamEntity)
}

@Dao
interface CompetitionDao {
    @Query("SELECT * FROM competitions ORDER BY name")
    suspend fun getAll(): List<CompetitionEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(c: CompetitionEntity): Long
    @Delete suspend fun delete(c: CompetitionEntity)
}

@Dao
interface MatchDao {
    @Query("SELECT * FROM matches ORDER BY dateMillis DESC")
    suspend fun getAll(): List<MatchEntity>
    @Query("SELECT * FROM matches WHERE id = :id")
    suspend fun getById(id: Long): MatchEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(m: MatchEntity): Long
    @Update suspend fun update(m: MatchEntity)
    @Delete suspend fun delete(m: MatchEntity)
}

@Dao
interface EventDao {
    @Query("SELECT * FROM events WHERE matchId = :matchId ORDER BY timestampMs")
    suspend fun forMatch(matchId: Long): List<MatchEventEntity>
    @Insert suspend fun insert(e: MatchEventEntity): Long
    @Query("DELETE FROM events WHERE matchId = :matchId")
    suspend fun deleteForMatch(matchId: Long)
}
