package com.futbolpro.recorder.ui.scoreboard

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.futbolpro.recorder.data.Prefs
import com.futbolpro.recorder.databinding.ActivityScoreboardConfigBinding
import com.futbolpro.recorder.domain.ScoreboardStyle

class ScoreboardConfigActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val b = ActivityScoreboardConfigBinding.inflate(layoutInflater)
        setContentView(b.root)
        val prefs = Prefs(this)
        val style = prefs.loadStyle()
        val templates = listOf("classic", "minimal", "bold")
        b.spTemplate.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, templates)
        b.spTemplate.setSelection(templates.indexOf(style.template).coerceAtLeast(0))
        b.seekScale.progress = (style.scale * 100).toInt().coerceIn(50, 200)
        b.seekAlpha.progress = (style.alpha * 100).toInt().coerceIn(20, 100)
        b.seekY.progress = (style.y * 100).toInt().coerceIn(0, 50)
        b.cbBadges.isChecked = style.showBadges
        b.btnSaveStyle.setOnClickListener {
            val s = ScoreboardStyle(
                template = b.spTemplate.selectedItem.toString(),
                scale = b.seekScale.progress / 100f,
                alpha = b.seekAlpha.progress / 100f,
                y = b.seekY.progress / 100f,
                showBadges = b.cbBadges.isChecked
            )
            prefs.saveStyle(s)
            Toast.makeText(this, "Estilo guardado", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
