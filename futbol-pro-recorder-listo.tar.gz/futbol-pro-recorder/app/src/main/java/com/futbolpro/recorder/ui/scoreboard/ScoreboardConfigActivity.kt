package com.futbolpro.recorder.ui.scoreboard

import android.graphics.*
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.futbolpro.recorder.data.Prefs
import com.futbolpro.recorder.databinding.ActivityScoreboardConfigBinding
import com.futbolpro.recorder.domain.MatchState
import com.futbolpro.recorder.domain.Period
import com.futbolpro.recorder.domain.ScoreboardStyle
import com.futbolpro.recorder.overlay.ScoreboardRenderer

class ScoreboardConfigActivity : AppCompatActivity() {
    private lateinit var b: ActivityScoreboardConfigBinding
    private lateinit var renderer: ScoreboardRenderer
    private val templates = com.futbolpro.recorder.domain.ScoreboardTemplates.list
    private val positions = com.futbolpro.recorder.domain.ScoreboardTemplates.positions
    private val bmp: Bitmap = Bitmap.createBitmap(1280, 720, Bitmap.Config.ARGB_8888)

    private fun style() = ScoreboardStyle(
        template = templates[b.spTemplate.selectedItemPosition].first,
        pos = positions[b.spPos.selectedItemPosition].first,
        scale = b.seekScale.progress.coerceAtLeast(50) / 100f,
        alpha = b.seekAlpha.progress.coerceAtLeast(30) / 100f,
        y = b.seekY.progress / 100f,
        showBadges = b.cbBadges.isChecked
    )

    private fun redraw() {
        val c = Canvas(bmp)
        val p = Paint().apply { shader = LinearGradient(0f, 0f, 0f, 720f, Color.parseColor("#3B8F4A"), Color.parseColor("#1D5E2A"), Shader.TileMode.CLAMP) }
        c.drawRect(0f, 0f, 1280f, 720f, p)
        val l = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#55FFFFFF"); style = Paint.Style.STROKE; strokeWidth = 4f }
        c.drawCircle(640f, 400f, 120f, l); c.drawLine(0f, 400f, 1280f, 400f, l)
        val pkg = packageName
        val sample = MatchState(
            homeName = "Deportivo Maracaibo", homeShort = "DEM", homeBadge = "android.resource://$pkg/drawable/badge_dm", homeColor = "#1E3A8A",
            awayName = "Atlético Zuliano", awayShort = "ATZ", awayBadge = "android.resource://$pkg/drawable/badge_az", awayColor = "#B8860B",
            homeScore = 2, awayScore = 1, period = Period.FIRST, elapsedMs = 23 * 60_000L + 14_000L,
            running = true, competition = "Torneo Apertura"
        )
        renderer.draw(c, 1280f, 720f, sample, style())
        b.ivPreview.setImageBitmap(bmp)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityScoreboardConfigBinding.inflate(layoutInflater)
        setContentView(b.root)
        renderer = ScoreboardRenderer(this)
        renderer.setBadges("android.resource://$packageName/drawable/badge_dm", "android.resource://$packageName/drawable/badge_az")
        val prefs = Prefs(this)
        val st = prefs.loadStyle()
        b.spTemplate.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, templates.map { it.second })
        b.spPos.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, positions.map { it.second })
        b.spTemplate.setSelection(templates.indexOfFirst { it.first == st.template }.coerceAtLeast(0))
        b.spPos.setSelection(positions.indexOfFirst { it.first == st.pos }.coerceAtLeast(0))
        b.seekScale.progress = (st.scale * 100).toInt().coerceIn(50, 250)
        b.seekAlpha.progress = (st.alpha * 100).toInt().coerceIn(30, 100)
        b.seekY.progress = (st.y * 100).toInt().coerceIn(0, 50)
        b.cbBadges.isChecked = st.showBadges

        val spinListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = redraw()
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        b.spTemplate.onItemSelectedListener = spinListener
        b.spPos.onItemSelectedListener = spinListener
        val seekListener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) = redraw()
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        }
        b.seekScale.setOnSeekBarChangeListener(seekListener)
        b.seekAlpha.setOnSeekBarChangeListener(seekListener)
        b.seekY.setOnSeekBarChangeListener(seekListener)
        b.cbBadges.setOnCheckedChangeListener { _, _ -> redraw() }
        b.btnSaveStyle.setOnClickListener {
            prefs.saveStyle(style())
            Toast.makeText(this, "Estilo guardado", Toast.LENGTH_SHORT).show()
            finish()
        }
        redraw()
    }
}
