package com.futbolpro.recorder

import android.app.Application
import com.futbolpro.recorder.data.AppDatabase

class App : Application() {
    val db: AppDatabase by lazy { AppDatabase.get(this) }
}
