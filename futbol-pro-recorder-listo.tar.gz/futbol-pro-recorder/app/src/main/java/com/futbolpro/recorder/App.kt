package com.futbolpro.recorder

import android.app.Application
import com.futbolpro.recorder.data.AppDatabase
import com.futbolpro.recorder.data.DefaultTeams
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class App : Application() {
    val db: AppDatabase by lazy { AppDatabase.get(this) }

    override fun onCreate() {
        super.onCreate()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val p = getSharedPreferences("futbolpro_prefs", MODE_PRIVATE)
                if (!p.getBoolean("seed_teams_v1", false)) {
                    val existing = db.teams().getAll().map { it.name }
                    DefaultTeams.list(packageName).filter { it.name !in existing }.forEach { db.teams().insert(it) }
                    p.edit().putBoolean("seed_teams_v1", true).apply()
                }
            } catch (_: Exception) {}
        }
    }
}
