package com.futbolpro.recorder.data

import androidx.room.*

@Entity(tableName = "teams")
data class TeamEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val shortName: String,
    val badgeUri: String? = null,
    val primaryColor: String = "#1E88E5",
    val secondaryColor: String = "#FFFFFF",
    val playersJson: String = "[]"
)

@Entity(tableName = "competitions")
data class CompetitionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String
)

@Entity(tableName = "matches")
data class MatchEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val homeTeamId: Long?,
    val awayTeamId: Long?,
    val homeName: String,
    val awayName: String,
    val homeShort: String,
    val awayShort: String,
    val homeBadge: String?,
    val awayBadge: String?,
    val homeColor: String,
    val awayColor: String,
    val homeScore: Int = 0,
    val awayScore: Int = 0,
    val dateMillis: Long = System.currentTimeMillis(),
    val durationSec: Long = 0,
    val videoPath: String? = null,
    val competition: String? = null,
    val summaryJson: String = "{}"
)

@Entity(tableName = "events")
data class MatchEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val matchId: Long,
    val type: String, // GOAL_HOME, GOAL_AWAY, YELLOW, RED, SUB, PERIOD
    val minute: String,
    val team: String?,
    val player: String?,
    val note: String?,
    val timestampMs: Long
)
