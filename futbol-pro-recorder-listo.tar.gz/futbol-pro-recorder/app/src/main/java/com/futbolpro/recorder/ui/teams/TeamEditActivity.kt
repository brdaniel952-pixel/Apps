package com.futbolpro.recorder.ui.teams

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.futbolpro.recorder.App
import com.futbolpro.recorder.R
import com.futbolpro.recorder.data.Auth
import com.futbolpro.recorder.data.TeamEntity
import com.futbolpro.recorder.databinding.ActivityTeamEditBinding
import com.futbolpro.recorder.ui.login.LoginActivity
import com.futbolpro.recorder.ui.players.PlayersActivity
import kotlinx.coroutines.launch
import java.io.File

/** Crear o editar un equipo (nombre, siglas, color, escudo, contraseña). */
class TeamEditActivity : AppCompatActivity() {
    private lateinit var b: ActivityTeamEditBinding
    private var teamId = -1L
    private var team: TeamEntity? = null
    private var badge: String? = null
    private var selColor = 0
    private val colors = listOf("#1565C0", "#C62828", "#2E7D32", "#F9A825", "#EF6C00", "#6A1B9A", "#0288D1", "#880E4F", "#212121", "#78909C")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun copyBadge(src: Uri): Uri? = try {
        val dir = File(filesDir, "badges").apply { mkdirs() }
        val f = File(dir, "badge_${System.currentTimeMillis()}.img")
        contentResolver.openInputStream(src)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        Uri.fromFile(f)
    } catch (_: Exception) { null }

    private val pickBadge = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val c = uri?.let { copyBadge(it) } ?: return@registerForActivityResult
        badge = c.toString(); showBadge()
    }

    private fun showBadge() {
        if (badge != null) {
            b.imgBadge.imageTintList = null; b.imgBadge.setPadding(dp(6), dp(6), dp(6), dp(6))
            try { b.imgBadge.setImageURI(Uri.parse(badge)) } catch (_: Exception) {}
        } else {
            b.imgBadge.setImageResource(R.drawable.ic_shield); b.imgBadge.setPadding(dp(22), dp(22), dp(22), dp(22))
            b.imgBadge.imageTintList = ColorStateList.valueOf(Color.parseColor("#5C6B8A"))
        }
    }

    private fun buildColors() {
        b.colorRow.removeAllViews()
        colors.forEachIndexed { i, hex ->
            val v = View(this)
            v.layoutParams = ViewGroup.MarginLayoutParams(dp(34), dp(34)).apply { marginEnd = dp(10) }
            v.setBackgroundResource(R.drawable.bg_dot)
            v.backgroundTintList = ColorStateList.valueOf(Color.parseColor(hex))
            v.alpha = if (i == selColor) 1f else 0.45f
            v.scaleX = if (i == selColor) 1.2f else 1f; v.scaleY = v.scaleX
            v.setOnClickListener { selColor = i; buildColors() }
            b.colorRow.addView(v)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityTeamEditBinding.inflate(layoutInflater)
        setContentView(b.root)
        teamId = intent.getLongExtra("teamId", -1L)
        val db = (application as App).db
        b.imgBadge.setOnClickListener { pickBadge.launch("image/*") }
        buildColors()
        if (teamId < 0) {
            b.tvEditTitle.text = "Nuevo equipo"
            b.groupPassword.visibility = View.VISIBLE
        } else {
            b.tvEditTitle.text = "Editar equipo"
            b.groupEdit.visibility = View.VISIBLE
            lifecycleScope.launch {
                val t = db.teams().getById(teamId) ?: run { finish(); return@launch }
                team = t
                b.etName.setText(t.name); b.etShort.setText(t.shortName)
                badge = t.badgeUri
                val i = colors.indexOfFirst { it.equals(t.primaryColor, true) }
                if (i >= 0) selColor = i
                buildColors(); showBadge()
            }
        }

        b.btnSave.setOnClickListener {
            val name = b.etName.text.toString().trim()
            if (name.isEmpty()) { Toast.makeText(this, "Escribe el nombre del equipo", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val short = b.etShort.text.toString().trim().ifBlank { name.take(3) }.uppercase()
            if (teamId < 0) {
                val pass = b.etPassword.text.toString()
                if (pass.length < 4) { Toast.makeText(this, "La contraseña debe tener mínimo 4 caracteres", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                lifecycleScope.launch {
                    val id = db.teams().insert(TeamEntity(name = name, shortName = short, badgeUri = badge, primaryColor = colors[selColor]))
                    Auth.setPassword(this@TeamEditActivity, id, pass)
                    Toast.makeText(this@TeamEditActivity, "Equipo creado", Toast.LENGTH_SHORT).show()
                    finish()
                }
            } else {
                val t = team ?: return@setOnClickListener
                lifecycleScope.launch {
                    db.teams().update(t.copy(name = name, shortName = short, badgeUri = badge, primaryColor = colors[selColor]))
                    Toast.makeText(this@TeamEditActivity, "Cambios guardados", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
        }
        b.btnPlayers.setOnClickListener { startActivity(Intent(this, PlayersActivity::class.java).putExtra("teamId", teamId)) }
        b.btnChangePass.setOnClickListener { changePassword() }
        b.btnDeleteTeam.setOnClickListener {
            val t = team ?: return@setOnClickListener
            AlertDialog.Builder(this).setTitle("Borrar ${t.name}").setMessage("Se borra el equipo y su plantilla. ¿Seguro?")
                .setPositiveButton("Borrar") { _, _ ->
                    lifecycleScope.launch {
                        val wasMine = Auth.currentTeamId(this@TeamEditActivity) == t.id
                        db.teams().delete(t); Auth.forget(this@TeamEditActivity, t.id)
                        if (wasMine) startActivity(Intent(this@TeamEditActivity, LoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
                        finish()
                    }
                }.setNegativeButton("Cancelar", null).show()
        }
    }

    private fun pwBox(vararg hints: String): Pair<LinearLayout, List<EditText>> {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val ets = hints.map { h -> EditText(this).apply { hint = h; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }.also { box.addView(it) } }
        return box to ets
    }

    private fun changePassword() {
        val own = Auth.currentTeamId(this) == teamId
        val (box, ets) = if (own) pwBox("Contraseña actual", "Contraseña nueva") else pwBox("Contraseña nueva")
        AlertDialog.Builder(this).setTitle("Cambiar contraseña").setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                val nw = ets.last().text.toString()
                if (own && !Auth.check(this, teamId, ets.first().text.toString())) { Toast.makeText(this, "La contraseña actual no coincide", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                if (nw.length < 4) { Toast.makeText(this, "Mínimo 4 caracteres", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                Auth.setPassword(this, teamId, nw)
                Toast.makeText(this, "Contraseña cambiada", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancelar", null).show()
    }
}
