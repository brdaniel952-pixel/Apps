package com.futbolpro.recorder.data

import android.content.Context
import com.futbolpro.recorder.domain.ScoreboardStyle
import com.google.gson.Gson

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("futbolpro_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    var defaultResolution: String
        get() = sp.getString("resolution", "1080p") ?: "1080p"
        set(v) = sp.edit().putString("resolution", v).apply()

    var defaultFps: Int
        get() = sp.getInt("fps", 30)
        set(v) = sp.edit().putInt("fps", v).apply()

    var defaultHalfMinutes: Int
        get() = sp.getInt("halfMin", 45)
        set(v) = sp.edit().putInt("halfMin", v).apply()

    fun saveStyle(style: ScoreboardStyle) {
        sp.edit().putString("scoreboard_style", gson.toJson(style)).apply()
    }
    fun loadStyle(): ScoreboardStyle {
        val json = sp.getString("scoreboard_style", null) ?: return ScoreboardStyle()
        return try { gson.fromJson(json, ScoreboardStyle::class.java) ?: ScoreboardStyle() } catch (_: Exception) { ScoreboardStyle() }
    }
}
