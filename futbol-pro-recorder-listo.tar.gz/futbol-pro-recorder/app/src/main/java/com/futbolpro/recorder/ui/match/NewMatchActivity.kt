package com.futbolpro.recorder.ui.match

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.futbolpro.recorder.App
import com.futbolpro.recorder.R
import com.futbolpro.recorder.data.Prefs
import com.futbolpro.recorder.data.TeamEntity
import com.futbolpro.recorder.databinding.ActivityNewMatchBinding
import com.futbolpro.recorder.ui.recording.RecordingActivity
import com.futbolpro.recorder.ui.teams.TeamsActivity
import kotlinx.coroutines.launch

class NewMatchActivity : AppCompatActivity() {
    private lateinit var b: ActivityNewMatchBinding
    private var teams: List<TeamEntity> = emptyList()
    private var homeId: Long = -1
    private var awayId: Long = -1

    private fun home() = teams.firstOrNull { it.id == homeId }
    private fun away() = teams.firstOrNull { it.id == awayId }

    private fun show(img: ImageView, name: android.widget.TextView, t: TeamEntity?) {
        name.text = t?.name ?: "Elegir equipo"
        if (t?.badgeUri != null) {
            img.imageTintList = null
            try { img.setImageURI(Uri.parse(t.badgeUri)) } catch (_: Exception) { img.setImageResource(R.drawable.ic_shield) }
        } else {
            img.setImageResource(R.drawable.ic_shield)
            img.imageTintList = ColorStateList.valueOf(Color.parseColor("#636366"))
        }
    }

    private fun refreshCards() {
        show(b.imgHome, b.tvHomeName, home())
        show(b.imgAway, b.tvAwayName, away())
    }

    private fun choose(forHome: Boolean) {
        if (teams.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle(if (forHome) "Equipo local" else "Equipo visitante")
            .setItems(teams.map { it.name }.toTypedArray()) { _, i ->
                if (forHome) homeId = teams[i].id else awayId = teams[i].id
                refreshCards()
            }.show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityNewMatchBinding.inflate(layoutInflater)
        setContentView(b.root)
        val prefs = Prefs(this)
        b.spResolution.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("720p", "1080p", "4K"))
        b.spFps.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("30", "60"))
        b.spResolution.setSelection(listOf("720p", "1080p", "4K").indexOf(prefs.defaultResolution).coerceAtLeast(0))
        b.spFps.setSelection(if (prefs.defaultFps == 60) 1 else 0)
        b.spAspect.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Pantalla completa (recomendado)", "16:9 estándar", "4:3"))
        b.etHalfMin.setText(prefs.defaultHalfMinutes.toString())

        b.cardHome.setOnClickListener { choose(true) }
        b.cardAway.setOnClickListener { choose(false) }
        b.btnGoTeams.setOnClickListener { startActivity(Intent(this, TeamsActivity::class.java)) }
        b.btnStart.setOnClickListener {
            val h = home()
            val a = away()
            if (teams.size < 2 || h == null || a == null) { Toast.makeText(this, "Elige los dos equipos", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            if (h.id == a.id) { Toast.makeText(this, "Elige dos equipos distintos", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val i = Intent(this, RecordingActivity::class.java).apply {
                putExtra("homeName", h.name); putExtra("homeShort", h.shortName)
                putExtra("homeBadge", h.badgeUri); putExtra("homeColor", h.primaryColor)
                putExtra("awayName", a.name); putExtra("awayShort", a.shortName)
                putExtra("awayBadge", a.badgeUri); putExtra("awayColor", a.primaryColor)
                putExtra("competition", b.etCompetition.text.toString())
                putExtra("resolution", b.spResolution.selectedItem.toString())
                putExtra("fps", b.spFps.selectedItem.toString().toInt())
                putExtra("aspect", when (b.spAspect.selectedItemPosition) { 1 -> "16:9"; 2 -> "4:3"; else -> "full" })
                putExtra("halfMin", b.etHalfMin.text.toString().toIntOrNull() ?: 45)
            }
            startActivity(i)
        }
    }

    override fun onResume() {
        super.onResume()
        lifecycleScope.launch {
            teams = (application as App).db.teams().getAll()
            if (home() == null) homeId = teams.getOrNull(0)?.id ?: -1
            if (away() == null || awayId == homeId) awayId = teams.firstOrNull { it.id != homeId }?.id ?: -1
            b.tvHint.visibility = if (teams.size < 2) View.VISIBLE else View.GONE
            refreshCards()
        }
    }
}
