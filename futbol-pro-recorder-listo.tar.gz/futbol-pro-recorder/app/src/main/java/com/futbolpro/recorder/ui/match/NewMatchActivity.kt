package com.futbolpro.recorder.ui.match

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.futbolpro.recorder.App
import com.futbolpro.recorder.data.Prefs
import com.futbolpro.recorder.data.TeamEntity
import com.futbolpro.recorder.databinding.ActivityNewMatchBinding
import com.futbolpro.recorder.ui.recording.RecordingActivity
import com.futbolpro.recorder.ui.teams.TeamsActivity
import kotlinx.coroutines.launch

class NewMatchActivity : AppCompatActivity() {
    private lateinit var b: ActivityNewMatchBinding
    private var teams: List<TeamEntity> = emptyList()
    private var firstLoad = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityNewMatchBinding.inflate(layoutInflater)
        setContentView(b.root)
        val prefs = Prefs(this)
        b.spResolution.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("720p", "1080p", "4K"))
        b.spFps.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("30", "60"))
        b.spResolution.setSelection(listOf("720p", "1080p", "4K").indexOf(prefs.defaultResolution).coerceAtLeast(0))
        b.spFps.setSelection(if (prefs.defaultFps == 60) 1 else 0)
        b.etHalfMin.setText(prefs.defaultHalfMinutes.toString())

        b.btnGoTeams.setOnClickListener { startActivity(Intent(this, TeamsActivity::class.java)) }
        b.btnStart.setOnClickListener {
            if (teams.size < 2) { Toast.makeText(this, "Agrega al menos 2 equipos", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val hi = b.spHome.selectedItemPosition
            val ai = b.spAway.selectedItemPosition
            if (hi == ai) { Toast.makeText(this, "Elige dos equipos distintos", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val h = teams[hi]
            val a = teams[ai]
            val i = Intent(this, RecordingActivity::class.java).apply {
                putExtra("homeName", h.name); putExtra("homeShort", h.shortName)
                putExtra("homeBadge", h.badgeUri); putExtra("homeColor", h.primaryColor)
                putExtra("awayName", a.name); putExtra("awayShort", a.shortName)
                putExtra("awayBadge", a.badgeUri); putExtra("awayColor", a.primaryColor)
                putExtra("competition", b.etCompetition.text.toString())
                putExtra("resolution", b.spResolution.selectedItem.toString())
                putExtra("fps", b.spFps.selectedItem.toString().toInt())
                putExtra("halfMin", b.etHalfMin.text.toString().toIntOrNull() ?: 45)
            }
            startActivity(i)
        }
    }

    override fun onResume() {
        super.onResume()
        lifecycleScope.launch {
            teams = (application as App).db.teams().getAll()
            val names = teams.map { "${it.name} (${it.shortName})" }
            val ph = b.spHome.selectedItemPosition
            val pa = b.spAway.selectedItemPosition
            b.spHome.adapter = ArrayAdapter(this@NewMatchActivity, android.R.layout.simple_spinner_dropdown_item, names)
            b.spAway.adapter = ArrayAdapter(this@NewMatchActivity, android.R.layout.simple_spinner_dropdown_item, names)
            if (names.isNotEmpty()) {
                b.spHome.setSelection(if (firstLoad) 0 else ph.coerceIn(0, names.size - 1))
                b.spAway.setSelection(if (firstLoad) (if (names.size > 1) 1 else 0) else pa.coerceIn(0, names.size - 1))
            }
            firstLoad = false
            b.tvHint.visibility = if (teams.size < 2) View.VISIBLE else View.GONE
        }
    }
}
