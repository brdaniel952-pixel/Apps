package com.futbolpro.recorder.ui.match

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.futbolpro.recorder.data.Prefs
import com.futbolpro.recorder.databinding.ActivityNewMatchBinding
import com.futbolpro.recorder.ui.recording.RecordingActivity

class NewMatchActivity : AppCompatActivity() {
    private lateinit var b: ActivityNewMatchBinding
    private var homeBadge: Uri? = null
    private var awayBadge: Uri? = null
    private val pickHome = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { try { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}; homeBadge = it }
    }
    private val pickAway = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { try { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}; awayBadge = it }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityNewMatchBinding.inflate(layoutInflater)
        setContentView(b.root)
        val prefs = Prefs(this)
        b.spResolution.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("720p", "1080p", "4K"))
        b.spFps.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("30", "60"))
        b.spResolution.setSelection(listOf("720p","1080p","4K").indexOf(prefs.defaultResolution).coerceAtLeast(0))
        b.spFps.setSelection(if (prefs.defaultFps == 60) 1 else 0)
        b.etHalfMin.setText(prefs.defaultHalfMinutes.toString())

        b.btnHomeBadge.setOnClickListener { pickHome.launch("image/*") }
        b.btnAwayBadge.setOnClickListener { pickAway.launch("image/*") }
        b.btnStart.setOnClickListener {
            val i = Intent(this, RecordingActivity::class.java).apply {
                putExtra("homeName", b.etHomeName.text.toString().ifBlank { "LOCAL" })
                putExtra("awayName", b.etAwayName.text.toString().ifBlank { "VISITA" })
                putExtra("homeShort", b.etHomeShort.text.toString().ifBlank { "LOC" })
                putExtra("awayShort", b.etAwayShort.text.toString().ifBlank { "VIS" })
                putExtra("competition", b.etCompetition.text.toString())
                putExtra("resolution", b.spResolution.selectedItem.toString())
                putExtra("fps", b.spFps.selectedItem.toString().toInt())
                putExtra("halfMin", b.etHalfMin.text.toString().toIntOrNull() ?: 45)
                putExtra("homeBadge", homeBadge?.toString())
                putExtra("awayBadge", awayBadge?.toString())
            }
            startActivity(i)
        }
    }
}
