package com.futbolpro.recorder.ui.cup

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.futbolpro.recorder.R
import com.futbolpro.recorder.data.TeamEntity
import com.google.android.material.button.MaterialButton

/** Utilidades para armar las pantallas de la copa por código. */
class CupUi(private val a: Activity) {
    private var n = 0
    fun dp(v: Int) = (v * a.resources.displayMetrics.density).toInt()

    fun tv(text: String, size: Float = 13f, color: Int = Color.WHITE, bold: Boolean = false, weight: Float = 0f, gravity: Int = Gravity.CENTER): TextView =
        TextView(a).apply {
            this.text = text; textSize = size; setTextColor(color); this.gravity = gravity
            if (bold) typeface = Typeface.DEFAULT_BOLD
            layoutParams = if (weight > 0f) LinearLayout.LayoutParams(0, -2, weight) else LinearLayout.LayoutParams(-2, -2)
        }

    fun badge(t: TeamEntity?, sizeDp: Int): ImageView = ImageView(a).apply {
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        scaleType = ImageView.ScaleType.FIT_CENTER
        val u = t?.badgeUri
        if (u != null) { try { setImageURI(Uri.parse(u)) } catch (_: Exception) {} }
        else { setImageResource(R.drawable.ic_shield); imageTintList = ColorStateList.valueOf(Color.parseColor("#636366")) }
    }

    fun photo(uri: String?, sizeDp: Int): ImageView = ImageView(a).apply {
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        setBackgroundResource(R.drawable.bg_dot); backgroundTintList = ColorStateList.valueOf(Color.parseColor("#2C2C2E"))
        outlineProvider = ViewOutlineProvider.BACKGROUND; clipToOutline = true
        if (uri != null) { scaleType = ImageView.ScaleType.CENTER_CROP; try { setImageURI(Uri.parse(uri)) } catch (_: Exception) {} }
        else { scaleType = ImageView.ScaleType.CENTER; setImageResource(R.drawable.ic_camera); imageTintList = ColorStateList.valueOf(Color.parseColor("#636366")) }
    }

    fun row(vertical: Boolean = false): LinearLayout = LinearLayout(a).apply {
        orientation = if (vertical) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setBackgroundResource(R.drawable.bg_card)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
        com.futbolpro.recorder.util.Fx.enter(this, n++ % 10)
    }

    fun btn(text: String, tint: Int? = null, weight: Float = 0f, onClick: () -> Unit): MaterialButton = MaterialButton(a).apply {
        this.text = text
        if (tint != null) backgroundTintList = ColorStateList.valueOf(tint)
        layoutParams = (if (weight > 0f) LinearLayout.LayoutParams(0, dp(48), weight) else LinearLayout.LayoutParams(-1, dp(48))).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
        setOnClickListener { onClick() }
    }

    fun header(text: String): TextView = tv(text, 14f, Color.parseColor("#0A84FF"), true, 0f, Gravity.START).apply {
        letterSpacing = 0.08f
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(10); bottomMargin = dp(6) }
    }

    fun spacer(h: Int) = View(a).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(h)) }
}
