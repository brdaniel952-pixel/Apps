package com.futbolpro.recorder.ui.teams

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.futbolpro.recorder.App
import com.futbolpro.recorder.R
import com.futbolpro.recorder.data.Auth
import com.futbolpro.recorder.data.TeamEntity
import com.futbolpro.recorder.databinding.ActivityTeamsBinding
import kotlinx.coroutines.launch

class TeamsActivity : AppCompatActivity() {
    private lateinit var b: ActivityTeamsBinding
    private var teams: List<TeamEntity> = emptyList()

    private inner class TeamAdapter(list: List<TeamEntity>) : ArrayAdapter<TeamEntity>(this@TeamsActivity, 0, list) {
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_team, parent, false)
            val t = getItem(position)!!
            v.findViewById<TextView>(R.id.tvName).text = t.name
            v.findViewById<TextView>(R.id.tvShort).text = if (t.id in Auth.admins(context)) "${t.shortName} · Admin" else t.shortName
            val img = v.findViewById<ImageView>(R.id.imgBadge)
            if (t.badgeUri == null) { img.setImageResource(R.drawable.ic_shield); img.imageTintList = ColorStateList.valueOf(Color.parseColor("#636366")) }
            else { img.imageTintList = null; try { img.setImageURI(Uri.parse(t.badgeUri)) } catch (_: Exception) {} }
            v.findViewById<View>(R.id.dotColor).backgroundTintList = ColorStateList.valueOf(try { Color.parseColor(t.primaryColor) } catch (_: Exception) { Color.GRAY })
            return v
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityTeamsBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnNewTeam.setOnClickListener { startActivity(Intent(this, TeamEditActivity::class.java)) }
        b.listTeams.setOnItemClickListener { _, _, pos, _ ->
            val t = teams[pos]
            if (Auth.canEdit(this, t.id)) startActivity(Intent(this, TeamEditActivity::class.java).putExtra("teamId", t.id))
            else Toast.makeText(this, "Solo ${t.name} o un admin pueden editar este equipo", Toast.LENGTH_LONG).show()
        }
    }

    override fun onResume() {
        super.onResume()
        lifecycleScope.launch {
            teams = (application as App).db.teams().getAll()
            b.listTeams.adapter = TeamAdapter(teams)
        }
    }
}
