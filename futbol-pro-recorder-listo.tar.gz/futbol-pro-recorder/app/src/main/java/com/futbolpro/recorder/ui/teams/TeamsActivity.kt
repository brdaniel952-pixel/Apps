package com.futbolpro.recorder.ui.teams

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.futbolpro.recorder.App
import com.futbolpro.recorder.data.TeamEntity
import com.futbolpro.recorder.databinding.ActivityTeamsBinding
import kotlinx.coroutines.launch

class TeamsActivity : AppCompatActivity() {
    private lateinit var b: ActivityTeamsBinding
    private var badgeUri: Uri? = null
    private var teams: List<TeamEntity> = emptyList()
    private val pickBadge = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { try { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}; badgeUri = it; Toast.makeText(this, "Escudo seleccionado", Toast.LENGTH_SHORT).show() }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityTeamsBinding.inflate(layoutInflater)
        setContentView(b.root)
        val db = (application as App).db
        fun refresh() {
            lifecycleScope.launch {
                teams = db.teams().getAll()
                b.listTeams.adapter = ArrayAdapter(this@TeamsActivity, android.R.layout.simple_list_item_1, teams.map { "${it.name} (${it.shortName})" })
            }
        }
        refresh()
        b.btnPickBadge.setOnClickListener { pickBadge.launch("image/*") }
        b.btnSaveTeam.setOnClickListener {
            val name = b.etTeamName.text.toString().trim()
            if (name.isEmpty()) { Toast.makeText(this, "Nombre requerido", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val short = b.etTeamShort.text.toString().ifBlank { name.take(3).uppercase() }
            lifecycleScope.launch {
                db.teams().insert(TeamEntity(name = name, shortName = short, badgeUri = badgeUri?.toString()))
                b.etTeamName.setText(""); b.etTeamShort.setText(""); badgeUri = null
                refresh()
            }
        }
        b.listTeams.setOnItemLongClickListener { _, _, pos, _ ->
            val t = teams[pos]
            lifecycleScope.launch { db.teams().delete(t); refresh() }
            true
        }
    }
}
