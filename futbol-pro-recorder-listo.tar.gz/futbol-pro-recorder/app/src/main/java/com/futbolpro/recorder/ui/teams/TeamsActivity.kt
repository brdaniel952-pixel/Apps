package com.futbolpro.recorder.ui.teams

import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.futbolpro.recorder.App
import com.futbolpro.recorder.data.TeamEntity
import com.futbolpro.recorder.databinding.ActivityTeamsBinding
import kotlinx.coroutines.launch
import java.io.File

class TeamsActivity : AppCompatActivity() {
    private lateinit var b: ActivityTeamsBinding
    private var badgeUri: Uri? = null
    private var teams: List<TeamEntity> = emptyList()
    private val colors = listOf(
        "Azul" to "#1565C0", "Rojo" to "#C62828", "Verde" to "#2E7D32", "Amarillo" to "#F9A825",
        "Naranja" to "#EF6C00", "Morado" to "#6A1B9A", "Celeste" to "#0288D1", "Guinda" to "#880E4F",
        "Negro" to "#212121", "Gris" to "#78909C"
    )

    // Copia el escudo a la carpeta de la app para que siempre esté disponible
    private fun copyBadge(src: Uri): Uri? = try {
        val dir = File(filesDir, "badges").apply { mkdirs() }
        val f = File(dir, "badge_${System.currentTimeMillis()}.img")
        contentResolver.openInputStream(src)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        Uri.fromFile(f)
    } catch (_: Exception) { null }

    private val pickBadge = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            badgeUri = copyBadge(it)
            Toast.makeText(this, if (badgeUri != null) "Escudo seleccionado" else "No se pudo leer la imagen", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityTeamsBinding.inflate(layoutInflater)
        setContentView(b.root)
        val db = (application as App).db
        b.spColor.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, colors.map { it.first })
        fun refresh() {
            lifecycleScope.launch {
                teams = db.teams().getAll()
                b.listTeams.adapter = ArrayAdapter(this@TeamsActivity, android.R.layout.simple_list_item_1,
                    teams.map { t -> "${t.name} (${t.shortName})" + if (t.badgeUri != null) "  🛡️" else "" })
            }
        }
        refresh()
        b.btnPickBadge.setOnClickListener { pickBadge.launch("image/*") }
        b.btnSaveTeam.setOnClickListener {
            val name = b.etTeamName.text.toString().trim()
            if (name.isEmpty()) { Toast.makeText(this, "Nombre requerido", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val short = b.etTeamShort.text.toString().trim().ifBlank { name.take(3) }.uppercase()
            val color = colors[b.spColor.selectedItemPosition].second
            lifecycleScope.launch {
                db.teams().insert(TeamEntity(name = name, shortName = short, badgeUri = badgeUri?.toString(), primaryColor = color))
                b.etTeamName.setText(""); b.etTeamShort.setText(""); badgeUri = null
                refresh()
            }
        }
        b.listTeams.setOnItemLongClickListener { _, _, pos, _ ->
            val t = teams[pos]
            lifecycleScope.launch { db.teams().delete(t); refresh() }
            true
        }
    }
}
