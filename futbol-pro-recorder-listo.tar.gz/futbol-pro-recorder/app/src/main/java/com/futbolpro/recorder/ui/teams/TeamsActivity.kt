package com.futbolpro.recorder.ui.teams

import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.futbolpro.recorder.App
import com.futbolpro.recorder.R
import com.futbolpro.recorder.data.TeamEntity
import com.futbolpro.recorder.databinding.ActivityTeamsBinding
import kotlinx.coroutines.launch
import java.io.File

class TeamsActivity : AppCompatActivity() {
    private lateinit var b: ActivityTeamsBinding
    private var badgeUri: Uri? = null
    private var teams: List<TeamEntity> = emptyList()
    private var selColor = 0
    private val colors = listOf(
        "#1565C0", "#C62828", "#2E7D32", "#F9A825", "#EF6C00",
        "#6A1B9A", "#0288D1", "#880E4F", "#212121", "#78909C"
    )

    // Copia el escudo a la carpeta de la app para que siempre esté disponible
    private fun copyBadge(src: Uri): Uri? = try {
        val dir = File(filesDir, "badges").apply { mkdirs() }
        val f = File(dir, "badge_${System.currentTimeMillis()}.img")
        contentResolver.openInputStream(src)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        Uri.fromFile(f)
    } catch (_: Exception) { null }

    private val pickBadge = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            badgeUri = copyBadge(it)
            if (badgeUri != null) {
                b.imgNewBadge.imageTintList = null
                b.imgNewBadge.setPadding(6, 6, 6, 6)
                b.imgNewBadge.setImageURI(badgeUri)
            } else Toast.makeText(this, "No se pudo leer la imagen", Toast.LENGTH_SHORT).show()
        }
    }

    private fun buildColors() {
        b.colorRow.removeAllViews()
        val d = resources.displayMetrics.density
        colors.forEachIndexed { i, hex ->
            val v = View(this)
            val size = (34 * d).toInt()
            val lp = ViewGroup.MarginLayoutParams(size, size).apply { marginEnd = (10 * d).toInt() }
            v.layoutParams = lp
            v.setBackgroundResource(R.drawable.bg_dot)
            v.backgroundTintList = ColorStateList.valueOf(Color.parseColor(hex))
            v.alpha = if (i == selColor) 1f else 0.45f
            v.scaleX = if (i == selColor) 1.2f else 1f
            v.scaleY = v.scaleX
            v.setOnClickListener { selColor = i; buildColors() }
            b.colorRow.addView(v)
        }
    }

    private inner class TeamAdapter(list: List<TeamEntity>) : ArrayAdapter<TeamEntity>(this@TeamsActivity, 0, list) {
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_team, parent, false)
            val t = getItem(position)!!
            v.findViewById<TextView>(R.id.tvName).text = t.name
            v.findViewById<TextView>(R.id.tvShort).text = t.shortName
            val img = v.findViewById<ImageView>(R.id.imgBadge)
            try { img.setImageURI(t.badgeUri?.let { Uri.parse(it) }) } catch (_: Exception) {}
            if (t.badgeUri == null) { img.setImageResource(R.drawable.ic_shield); img.imageTintList = ColorStateList.valueOf(Color.parseColor("#5C6B8A")) } else img.imageTintList = null
            v.findViewById<View>(R.id.dotColor).backgroundTintList = ColorStateList.valueOf(try { Color.parseColor(t.primaryColor) } catch (_: Exception) { Color.GRAY })
            return v
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityTeamsBinding.inflate(layoutInflater)
        setContentView(b.root)
        val db = (application as App).db
        buildColors()
        fun refresh() {
            lifecycleScope.launch {
                teams = db.teams().getAll()
                b.listTeams.adapter = TeamAdapter(teams)
            }
        }
        refresh()
        b.imgNewBadge.setOnClickListener { pickBadge.launch("image/*") }
        b.btnSaveTeam.setOnClickListener {
            val name = b.etTeamName.text.toString().trim()
            if (name.isEmpty()) { Toast.makeText(this, "Escribe el nombre del equipo", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val short = b.etTeamShort.text.toString().trim().ifBlank { name.take(3) }.uppercase()
            lifecycleScope.launch {
                db.teams().insert(TeamEntity(name = name, shortName = short, badgeUri = badgeUri?.toString(), primaryColor = colors[selColor]))
                b.etTeamName.setText(""); b.etTeamShort.setText(""); badgeUri = null
                b.imgNewBadge.setImageResource(R.drawable.ic_shield)
                b.imgNewBadge.imageTintList = ColorStateList.valueOf(Color.parseColor("#5C6B8A"))
                b.imgNewBadge.setPadding(54, 54, 54, 54)
                refresh()
            }
        }
        b.listTeams.setOnItemClickListener { _, _, pos, _ ->
            startActivity(android.content.Intent(this, com.futbolpro.recorder.ui.players.PlayersActivity::class.java).putExtra("teamId", teams[pos].id))
        }
        b.listTeams.setOnItemLongClickListener { _, _, pos, _ ->
            val t = teams[pos]
            AlertDialog.Builder(this).setTitle("Borrar ${t.name}").setMessage("¿Seguro?")
                .setPositiveButton("Borrar") { _, _ -> lifecycleScope.launch { db.teams().delete(t); refresh() } }
                .setNegativeButton("Cancelar", null).show()
            true
        }
    }
}
