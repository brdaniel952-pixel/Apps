# Fútbol Pro Recorder (Android, offline)

App Android nativa (Kotlin) para grabar partidos de fútbol amateur con marcador/overlay profesional en pantalla, controles en vivo, cronómetro, estadísticas básicas e historial local. **Sin streaming, sin internet, sin servidores**.

## Qué incluye este proyecto

- **Grabación (CameraX/Recorder):** vista previa, grabación horizontal (activity landscape), inicio/pausa/reanudación/finalizar, guardado en `Movies/FutbolProRecorder` vía MediaStore (MP4), selección de calidad 720p/1080p/4K (según soporte del dispositivo) y FPS objetivo configurables.
- **Marcador/overlay personalizable:** nombres cortos, goles, cronómetro, periodo (1T/DESC/2T/ET/FIN), colores, plantillas (classic/minimal/bold), escala/transparencia/posición, escudos desde galería. Superposición dibujada sobre la vista previa en tiempo real y **actualizable sin detener la grabación**.
- **Controles rápidos durante el partido:** ±1 gol local/visita, iniciar/pausar/reiniciar cronómetro, ±1 min, cambio de periodo, tiempo añadido (campo en estado), tarjetas amarilla/roja y sustituciones (registro de evento por equipo), reflejados al instante en el overlay.
- **Cronómetro profesional:** configurable por minutos de tiempo, inicio/pausa/reanudación, ajuste manual, independiente de la grabación.
- **Equipos y competiciones:** alta de equipos (nombre, corto, escudo, colores/campos base) guardados en Room para reutilizar; campo de competición por partido.
- **Estadísticas y resumen:** registro local de eventos (goles, tarjetas, sustituciones, cambios de periodo) con minuto, almacenado por partido (Room + JSON de resumen).
- **Historial offline:** listado de partidos (equipos, resultado, fecha, duración), reproducir/compartir/eliminar vídeos desde almacenamiento local.
- **Ajustes:** resolución/FPS/duración por defecto.
- **100% offline:** datos en Room/SharedPreferences/archivos locales, sin cuentas, sin red ni dependencias de servidor.

## Estructura

- `app/src/main/java/com/futbolpro/recorder/` — `ui/` (pantallas), `overlay/` (ScoreboardOverlayView), `domain/` (modelos/tiempo), `data/` (Room, prefs), `util/`.
- Recursos en `app/src/main/res/`, manifiesto con permisos de cámara/audio/almacenamiento.

## Requisitos de compilación

- JDK 17
- Android SDK (platform 35, build-tools) y Gradle compatible
- Máquina/entorno con toolchain Android estándar (p.ej. x86_64 o ARM64 con `aapt2` compatible con AGP). Recomendado: **Android Studio** o línea de comandos en un host con SDK completo.

```bash
# desde la raíz del proyecto
export ANDROID_HOME=/ruta/al/android-sdk
# opcional: echo "sdk.dir=/ruta/al/android-sdk" > local.properties
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

## Notas importantes / limitaciones del prototipo

- **Integración permanente del marcador en el archivo de vídeo ("burn-in"):** el overlay se renderiza en tiempo real sobre la preview y todos los cambios quedan sincronizados durante la sesión, pero la composición directa dentro del stream/archivo MP4 grabado requiere un pipeline de efectos/renderizado (p.ej. CameraX `OverlayEffect`/OpenGL + encoder) cuya disponibilidad y API varían según versión de CameraX y dispositivo. En este proyecto base el marcador se muestra en pantalla durante la grabación; para quemarlo en el vídeo final en todos los dispositivos puede extenderse con un `CameraEffect`/pipeline OpenGL compatible con la versión de CameraX del dispositivo o un post-procesado offline con MediaCodec/MediaMuxer.
- **4K/60fps, pausa de grabación:** dependen del hardware/soporte del dispositivo (CameraX usa la mejor calidad disponible con fallback).
- **Recuperación ante cierre inesperado:** el guardado se realiza al finalizar y los metadatos/eventos se persisten; una estrategia robusta ante cierres abruptos requeriría grabación segmentada/archivo pendiente adicional según dispositivo.
- Probado a nivel de código/proyecto; compilar y validar en dispositivo físico Android real (cámara, permisos, rendimiento térmico/batería).

## Permisos
Cámara, audio, lectura de imágenes (escudos) y almacenamiento acorde a la versión de Android. Todo local/offline.
