package com.example.launcher

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {

    private class AppItem(val label: String, val icon: Drawable, val component: ComponentName)

    private var apps = listOf<AppItem>()
    private lateinit var grid: GridView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        grid = GridView(this).apply {
            numColumns = 6
            setBackgroundColor(Color.BLACK)
            val p = dp(32)
            setPadding(p, p, p, p)
            horizontalSpacing = dp(16)
            verticalSpacing = dp(16)
            selector = ColorDrawable(0x44FFFFFF)
            setOnItemClickListener { _, _, pos, _ -> launch(apps[pos]) }
        }
        setContentView(grid)
    }

    override fun onResume() {
        super.onResume()
        loadApps()
    }

    private fun loadApps() {
        val pm = packageManager
        var list = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory("android.intent.category.LEANBACK_LAUNCHER"), 0
        )
        if (list.isEmpty()) {
            list = pm.queryIntentActivities(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
            )
        }
        apps = list
            .filter { it.activityInfo.packageName != packageName }
            .map {
                AppItem(
                    it.loadLabel(pm).toString(),
                    it.loadIcon(pm),
                    ComponentName(it.activityInfo.packageName, it.activityInfo.name)
                )
            }
            .sortedBy { it.label.lowercase() }
        grid.adapter = Adapter()
    }

    private fun launch(item: AppItem) {
        val i = Intent(Intent.ACTION_MAIN).apply {
            component = item.component
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(i)
    }

    private inner class Adapter : BaseAdapter() {
        override fun getCount() = apps.size
        override fun getItem(position: Int) = apps[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val item = apps[position]
            val row = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = android.view.Gravity.CENTER
                setPadding(dp(8), dp(12), dp(8), dp(12))
                addView(ImageView(context).apply { layoutParams = LinearLayout.LayoutParams(dp(72), dp(72)) })
                addView(TextView(context).apply {
                    setTextColor(Color.WHITE)
                    textSize = 14f
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    gravity = android.view.Gravity.CENTER
                })
            }
            (row.getChildAt(0) as ImageView).setImageDrawable(item.icon)
            (row.getChildAt(1) as TextView).text = item.label
            return row
        }
    }

    override fun onBackPressed() { /* el launcher no se cierra */ }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
